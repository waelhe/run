# 🔄 استعادة السياق من الإنقاذ

## 🚨 إذا بدأت جلسة جديدة بدون سياق

### الخطوة 1: ابحث عن ملفات الإنقاذ

```bash
# عرض قائمة الإنقاذات
cat /tmp/context-rescue-list.txt

# أو البحث عنها
find /tmp -name "context-rescue-*.tar.gz" 2>/dev/null
```

### الخطوة 2: استخرج الإنقاذ

```bash
# استخراج
tar -xzvf /tmp/context-rescue-XXXXXX.tar.gz -C /tmp/

# ستجد:
# /tmp/context-rescue-XXXXXX/
# ├── .context/
# ├── worklog.md
# ├── RESCUE.md
# ├── git-history.txt
# ├── git-backup.bundle
# └── stats.txt
```

### الخطوة 3: استعد الملفات

```bash
# نسخ السياق
cp -r /tmp/context-rescue-XXXXXX/.context /home/z/my-project/

# نسخ worklog
cp /tmp/context-rescue-XXXXXX/worklog.md /home/z/my-project/

# نسخ RESCUE.md
cp /tmp/context-rescue-XXXXXX/RESCUE.md /home/z/my-project/
```

### الخطوة 4: اقرأ السياق

```bash
# اقرأ الحالة
cat .context/STATUS.md

# اقرأ المهام
cat .context/TODO.md

# اقرأ worklog
cat worklog.md

# اقرأ تاريخ Git
cat .context/git-history.txt
```

---

## 📋 قائمة فحص للاستعادة

- [ ] تم العثور على ملفات الإنقاذ
- [ ] تم استخراج الأرشيف
- [ ] تم نسخ .context/
- [ ] تم نسخ worklog.md
- [ ] تم قراءة STATUS.md
- [ ] تم قراءة TODO.md
- [ ] تم فهم أين توقفت الجلسة السابقة

---

## 🎯 بعد الاستعادة

1. اقرأ `.context/QUICKSTART.md`
2. تحقق من الخادم: `curl http://localhost:3000`
3. أكمل من حيث توقفت

---

**آخر تحديث:** 2026-03-17
