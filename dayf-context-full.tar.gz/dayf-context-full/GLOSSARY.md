# 📚 قاموس المصطلحات (GLOSSARY)

## 🔄 آخر تحديث: 2026-03-17

---

## 🎯 الهدف

هذا الملف يوحد المصطلحات والمفاهيم المستخدمة في المشروع لتجنب الارتباك.

---

## 📋 المصطلحات التقنية

### البنية المعمارية (Architecture)

| المصطلح | التعريف | مثال |
|---------|---------|------|
| **DDD** | Domain-Driven Design | تصميم يقوده المجال |
| **Clean Architecture** | بنية نظيفة بـ 5 طبقات | Domain → Application → ... |
| **Modular Monolith** | تطبيق واحد مع وحدات منفصلة | المشروع الحالي |
| **Layer** | طبقة في البنية | Domain Layer, Application Layer |
| **Domain** | مجال العمل | السياحة، الحجوزات، المستخدمين |

### الطبقات (Layers)

| المصطلح | المجلد | المسؤولية |
|---------|--------|----------|
| **Domain Layer** | `src/core/` | الكيانات، الأنواع، القواعد |
| **Application Layer** | `src/application/` | Use Cases، Mappers، DTOs |
| **Infrastructure Layer** | `src/infrastructure/` | Repositories، Services |
| **Presentation Layer** | `src/components/` | مكونات UI |
| **API Layer** | `src/app/api/` | REST API Routes |

### الأنماط (Patterns)

| المصطلح | التعريف | مثال |
|---------|---------|------|
| **Repository Pattern** | تجريد الوصول للبيانات | `ListingRepository` |
| **Result Pattern** | `Result<T, E>` للأخطاء | `Result<User, Error>` |
| **Mapper Pattern** | تحويل بين الأنواع | `ListingMapper.toDomain()` |
| **DTO** | Data Transfer Object | `CreateListingDTO` |
| **Entity** | كيان له هوية فريدة | `User`, `Listing`, `Booking` |
| **Value Object** | كائن بدون هوية | `Email`, `PhoneNumber` |
| **Use Case** | حالة استخدام واحدة | `CreateListingUseCase` |

### قاعدة البيانات (Database)

| المصطلح | التعريف |
|---------|---------|
| **Prisma** | ORM للتعامل مع قاعدة البيانات |
| **SQLite** | قاعدة بيانات ملفات خفيفة |
| **Schema** | تعريف هيكل الجداول |
| **Migration** | تغيير في هيكل قاعدة البيانات |
| **Seed** | بيانات أولية للاختبار |

### Next.js

| المصطلح | التعريف |
|---------|---------|
| **App Router** | نظام التوجيه الجديد في Next.js 13+ |
| **Server Component** | مكون يُنفذ على الخادم |
| **Client Component** | مكون يُنفذ في المتصفح |
| **API Route** | نقطة نهاية REST API |
| **Route Handler** | معالج المسار في App Router |

---

## 📋 المصطلحات العربية

### المشروع (ضيف - Dayf)

| المصطلح | الإنجليزية | المعنى |
|---------|-----------|--------|
| **ضيف** | Dayf | اسم المنصة السياحية |
| **إقامة** | Listing | مكان للإقامة (فندق، شقة، إلخ) |
| **حجز** | Booking | حجز مكان |
| **مزود** | Provider | مالك مكان الإقامة |
| **مسافر** | Traveler | المستخدم الذي يحجز |
| **مراجعة** | Review | تقييم المكان |
| **شركة** | Company | شركة تدير أماكن إقامة |

### الصلاحيات (Permissions)

| المصطلح | الإنجليزية | المعنى |
|---------|-----------|--------|
| **صلاحية** | Permission | حق القيام بفعل |
| **دور** | Role | مجموعة صلاحيات |
| **مدير** | Admin | صلاحيات كاملة |
| **مزود خدمة** | Provider | يدير إقاماته |
| **مسافر** | Traveler | يحجز ويراجع |

---

## 📋 الاختصارات (Abbreviations)

| الاختصار | المعنى |
|----------|--------|
| **TS** | TypeScript |
| **JSX** | JavaScript XML |
| **API** | Application Programming Interface |
| **ORM** | Object-Relational Mapping |
| **DTO** | Data Transfer Object |
| **CRUD** | Create, Read, Update, Delete |
| **UUID** | Universally Unique Identifier |
| **JWT** | JSON Web Token |
| **auth** | Authentication |
| **repo** | Repository |

---

## 📋 أنواع الأخطاء (Error Types)

| الكود | الاسم | المعنى |
|-------|-------|--------|
| **TS2339** | Property does not exist | خاصية غير موجودة |
| **TS2322** | Type not assignable | نوع غير متوافق |
| **TS1205** | Re-exporting type-only | إعادة تصدير نوع بشكل خاطئ |
| **TS2305** | Module has no exported member | عضو غير موجود في الوحدة |
| **TS2345** | Argument type mismatch | نوع الوسيط غير متطابق |
| **TS1361** | Constructor is private | المنشئ خاص |

---

## 📋 الألوان والأولويات

| اللون | الرمز | المعنى |
|-------|-------|--------|
| 🔴 | عالية | حرج - يجب إصلاحه فوراً |
| 🟡 | متوسطة | مهم - يمكن تأجيله قليلاً |
| 🟢 | منخفضة | تحسين - يمكن فعله لاحقاً |

---

## 📋 الرموز التعبيرية المستخدمة

| الرمز | المعنى |
|-------|--------|
| ✅ | مكتمل / يعمل |
| ⏳ | قيد العمل / معلق |
| ❌ | فشل / خطأ |
| ⚠️ | تحذير / يحتاج انتباه |
| 🔴 | أولوية عالية |
| 🟡 | أولوية متوسطة |
| 🟢 | أولوية منخفضة |
| 📁 | ملف / مجلد |
| 📋 | قائمة / تقرير |
| 🔧 | إصلاح |
| 🔄 | تحديث / تحويل |
| 🎯 | هدف / مهمة |
| 🏛️ | معماري |
| 🔖 | نقطة حفظ |
