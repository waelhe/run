# ⚡ دليل البدء السريع للجلسات الجديدة

## 🚀 ابدأ من هنا في كل جلسة جديدة!

---

## ⚠️ القواعد الذهبية (اقرأ أولاً!)

> **1. لا تستخدم Write tool على worklog.md - استخدم append فقط!**
> **2. نفذ `init-session.sh` في بداية كل جلسة**
> **3. وثّق بعد كل إنجاز صغير - لا تنتظر النهاية!**

---

## 🔄 المرحلة 0: تهيئة الجلسة (إلزامي!)

```bash
# نفذ هذا أولاً!
bash .context/init-session.sh
```

هذا السكربت:
- يبحث عن جلسة سابقة
- يفحص وجود worklog.md و .context/
- ينشئ SESSION_ID جديد
- يضيف "بداية الجلسة" لـ worklog.md
- يعمل git commit

---

## 📋 الخطوة 1: اقرأ ملفات السياق

```
اقرأ هذه الملفات بالترتيب:
1. .context/STATUS.md      ← الحالة الحالية
2. .context/TODO.md        ← المهام المعلقة
3. .context/CHECKPOINTS.md ← آخر نقطة حفظ
```

---

## 📋 الخطوة 2: افهم السياق

### أسئلة يجب أن تجيب عليها:

| السؤال | المصدر |
|--------|--------|
| كم عدد أخطاء TypeScript؟ | STATUS.md |
| ما آخر إصلاح تم؟ | CHANGELOG.md |
| ما المهام المعلقة؟ | TODO.md |
| ما آخر checkpoint؟ | CHECKPOINTS.md |
| ما القرارات المعمارية؟ | DECISIONS.md |

---

## 📋 الخطوة 3: تحقق من الخادم

```bash
# تحقق من أن الخادم يعمل
curl -s http://localhost:3000 | head -20

# أو اقرأ الـ log
tail -50 /home/z/my-project/dev.log
```

---

## 📋 الخطوة 4: حدد أولويتك

### إذا كانت هناك مشاكل Runtime:
```
🔴 أصلح Runtime أولاً ← الأولوية القصوى
```

### إذا كان كل شيء يعمل:
```
🟡 راجع TODO.md واختر مهمة
```

---

## 📋 الخطوة 5: قبل أي إصلاح

1. **اكتب Spec** - ماذا ستفعل؟
2. **حدد الملفات** - ماذا ستعدل؟
3. **توقع الأثر** - ماذا سيتغير؟
4. **نفذ** - افعل الإصلاح
5. **اختبر** - تحقق من النتيجة

---

## 📋 الخطوة 6: بعد أي إصلاح

### ⚡ التوثيق المستمر (إلزامي!)

```bash
# بعد كل إنجاز صغير:
bash .context/log-achievement.sh "وصف الإنجاز" "الملفات المعدلة"

# مثال:
bash .context/log-achievement.sh "إصلاح TypeScript errors" "listing.repository.ts"
```

هذا السكربت:
1. يضيف لـ worklog.md (append!)
2. يحدّث SESSION-STATE.md
3. يعمل git commit تلقائياً
4. يحدّث /tmp/last-session-info.txt

### 🔖 عند إنجاز milestone:

```bash
bash .context/checkpoint.sh "اسم الـ checkpoint"
```

هذا السكربت:
1. يجمع الإحصائيات
2. يضيف checkpoint لـ worklog.md
3. يعمل git commit + tag
4. ينشئ أرشيف checkpoint

---

## ⚠️ تحذيرات مهمة

### ❌ لا تفعل:
- لا تصلح أكثر من مشكلة في نفس الوقت
- لا تخفِ الأخطاء بـ `console.warn` أو `any`
- لا تعدل بدون قراءة STATUS.md أولاً

### ✅ افعل:
- اقرأ السياق أولاً
- اكتب Spec قبل الإصلاح
- اختبر بعد كل إصلاح
- حدّث الملفات بعد الإنجاز

---

## 📊 نموذج لبدء جلسة جديدة

```
═══════════════════════════════════════════════════════════
                    🚀 جلسة جديدة
═══════════════════════════════════════════════════════════

[1] قراءة STATUS.md... ✅
    → أخطاء TS: 1158
    → الخادم: يعمل

[2] قراءة TODO.md... ✅
    → المهام المعلقة: 10
    → الأولوية العالية: 4

[3] قراءة CHECKPOINTS.md... ✅
    → آخر checkpoint: #1 (2026-03-17)

[4] تحديد المهمة:
    → سأعمل على: [إصلاح Type Imports]

[5] كتابة Spec...
    → تم تحديد المتوقع

[6] التنفيذ...
    → [الإصلاحات]

[7] التحديث...
    → STATUS.md ✅
    → TODO.md ✅
    → CHANGELOG.md ✅

═══════════════════════════════════════════════════════════
```

---

## 🔐 حفظ Git History و worklog (مهم!)

### ❌ المشكلة الجوهرية:
```
الجلسة القديمة (Context كامل)
    ↓
[ينتهي الـ Context]
    ↓
الجلسة الجديدة ← لا تعرف بوجود سياق سابق!
```

### ✅ حل إنقاذ السياق:

#### قبل انتهاء الجلسة:
```bash
# نفذ هذا فوراً!
bash .context/rescue.sh

# يُنشئ أرشيف كامل في:
# /tmp/context-rescue-YYYYMMDD-HHMMSS.tar.gz
```

#### عند بدء جلسة جديدة:
```bash
# 1. اقرأ RESCUE.md أولاً!
cat RESCUE.md

# 2. إذا لم تجد السياق، ابحث عن الإنقاذات
cat /tmp/context-rescue-list.txt
find /tmp -name "context-rescue-*.tar.gz"

# 3. استعد من الإنقاذ
tar -xzvf /tmp/context-rescue-XXXXXX.tar.gz -C /tmp/
cp -r /tmp/context-rescue-XXXXXX/.context /home/z/my-project/
cp /tmp/context-rescue-XXXXXX/worklog.md /home/z/my-project/
```

📄 راجع: `RESCUE.md` و `.context/RESTORE-CONTEXT.md`

---

### ✅ حل حفظ Git History:
```bash
# حفظ Git History كملفات نصية
bash .context/git-save.sh

# يُنشئ:
# .context/git-history.txt      - التاريخ المختصر
# .context/git-history-full.txt - التاريخ الكامل
# .context/git-history.json     - نسخة JSON
# /tmp/git-backup-*.bundle      - نسخة كاملة
```

### ✅ حل استبدال worklog.md:
```bash
# ❌ خطأ - لا تستخدم Write tool على worklog.md!

# ✅ صحيح - استخدم append فقط:
bash .context/worklog-add.sh "العنوان" "المحتوى"

# أو يدوياً:
cat >> worklog.md << 'EOF'

---
## [2026-03-17] عنوان القسم

المحتوى الجديد...

EOF
```

### 🔄 استعادة Git History:
```bash
# عرض النسخ المتاحة
bash .context/git-restore.sh

# استعادة من bundle
bash .context/git-restore.sh /tmp/git-backup-XXXXXX.bundle
```

📄 راجع التفاصيل في: `.context/GIT-HISTORY-SOLUTION.md`

---

## 💾 النسخ الاحتياطي (مهم!)

### قبل العمليات الكبيرة:
```bash
# حفظ سريع للسياق والملفات المهمة
bash .context/backup.sh
```

### لاستعادة نسخة:
```bash
# عرض النسخ المتاحة
bash .context/restore.sh

# استعادة نسخة محددة
bash .context/restore.sh /tmp/dayf-backup-XXXXXX.tar.gz
```

---

## 🚨 مشكلة: Download workspace failed

### إذا فشلت أرشفة Workspace:
```bash
# الحل السريع: حذف الملفات الكبيرة
rm -rf node_modules .next

# ثم أعد المحاولة
# بعد الأرشفة: bun install
```

### راجع التفاصيل في:
📄 `.context/TROUBLESHOOTING.md`

---

## 🔍 الفحص الشامل (مهم!)

### فحص سريع (2 دقيقة):
```bash
bash .context/check.sh --quick
```

### فحص كامل (10 دقائق):
```bash
bash .context/check.sh --full
```

### فحص يدوي شامل (90 دقيقة):
📄 راجع `.context/CHECKLIST.md` - **152 بند فحص**
📄 راجع `.context/FULL-CHECK-GUIDE.md` - دليل التنفيذ

### متى تطلب الفحص الشامل؟
- عند بدء مشروع جديد
- بعد إصلاحات كبيرة
- قبل الـ Deployment
- عند طلب المستخدم "فحص شامل"

---

## 📁 ملخص ملفات السياق

| الملف | محتواه | متى تقرأه |
|-------|--------|----------|
| `STATUS.md` | الحالة الحالية | بداية كل جلسة |
| `TODO.md` | المهام | بداية كل جلسة |
| `CHANGELOG.md` | التاريخ | عند الحاجة |
| `CHECKPOINTS.md` | نقاط الحفظ | عند الاستعادة |
| `DECISIONS.md` | القرارات | عند تعديل معماري |
| `GLOSSARY.md` | المصطلحات | عند الحاجة |
| `TROUBLESHOOTING.md` | حلول المشاكل | عند فشل الأرشفة |
| `CHECKLIST.md` | قائمة الفحص الشامل | عند الفحص الشامل |
| `FULL-CHECK-GUIDE.md` | دليل الفحص اليدوي | عند الفحص الشامل |
| `GIT-HISTORY-SOLUTION.md` | حلول Git/Worklog | عند فقدان المعلومات |
| `CONTINUOUS-DOC.md` | نظام التوثيق المستمر | للمرجع |
| `SESSION-STATE.md` | حالة الجلسة الحالية | يُحدّث تلقائياً |
| `QUICKSTART.md` | هذا الملف | عند نسيان الإجراءات |

### السكربتات (10 سكربتات):

| الملف | الوظيفة | متى تُنفذ |
|-------|----------|----------|
| `init-session.sh` | 🚀 تهيئة الجلسة | بداية كل جلسة |
| `log-achievement.sh` | 📝 تسجيل إنجاز | بعد كل إنجاز صغير |
| `checkpoint.sh` | 🔖 إنشاء checkpoint | عند milestone |
| `rescue.sh` | 🆘 إنقاذ السياق | قبل انتهاء الجلسة |
| `backup.sh` | 💾 نسخ احتياطي | عند الحاجة |
| `restore.sh` | 🔄 استعادة نسخة | عند الحاجة |
| `check.sh` | 🔍 فحص تلقائي | عند الفحص |
| `git-save.sh` | 📦 حفظ Git History | دورياً |
| `git-restore.sh` | 🔄 استعادة Git | عند الحاجة |
| `worklog-add.sh` | 📝 إضافة لـ worklog | عند الحاجة |

---

## 📋 ملخص سريع

```bash
# ═══════════════════════════════════════════════════════════════
#                    دورة حياة الجلسة
# ═══════════════════════════════════════════════════════════════

# 🚀 بداية الجلسة:
bash .context/init-session.sh

# 📝 بعد كل إنجاز:
bash .context/log-achievement.sh "الإنجاز" "الملفات"

# 🔖 عند milestone:
bash .context/checkpoint.sh "اسم checkpoint"

# 📦 حفظ Git (دورياً):
bash .context/git-save.sh

# 🆘 قبل انتهاء الجلسة:
bash .context/rescue.sh

# ═══════════════════════════════════════════════════════════════
```

---

📄 **للمزيد من التفاصيل راجع:** `.context/MASTER-SYSTEM.md`

---

**آخر تحديث:** 2026-03-17
