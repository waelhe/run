# 🔧 حلول المشاكل الشائعة (TROUBLESHOOTING)

## 🔄 آخر تحديث: 2026-03-17

---

## 🚨 المشكلة: Download workspace failed: Failed to archive workspace files

### الأسباب المحتملة:

| السبب | التوضيح |
|-------|---------|
| **ملفات كبيرة** | ملفات تتجاوز الحجم المسموح |
| **node_modules** | مجلد ضخم يسبب فشل الأرشفة |
| **عدد ملفات كثير** | آلاف الملفات تبطئ/تفشل الأرشفة |
| **ملفات مؤقتة** | `.next/`, `dist/`, `*.log` |
| **صلاحيات** | ملفات بدون صلاحية قراءة |

---

## ✅ الحلول

### الحل 1: تنظيف قبل الأرشفة

```bash
# حذف المجلدات الكبيرة غير الضرورية
rm -rf node_modules
rm -rf .next
rm -rf dist
rm -rf build

# إعادة التثبيت بعد الأرشفة
bun install
```

---

### الحل 2: أرشفة يدوية (انتقائية)

```bash
# إنشاء ملف قائمة الاستبعاد
cat > /tmp/exclude.txt << 'EOF'
node_modules
.next
dist
build
*.log
.db
*.db-journal
prisma/*.db
EOF

# أرشفة يدوية
tar --exclude-from=/tmp/exclude.txt -czvf /tmp/workspace-backup.tar.gz /home/z/my-project
```

---

### الحل 3: حفظ الملفات المهمة فقط

```bash
# إنشاء نسخة احتياطية للملفات المهمة فقط
mkdir -p /tmp/backup

# نسخ الملفات المهمة
cp -r /home/z/my-project/src /tmp/backup/
cp -r /home/z/my-project/prisma /tmp/backup/
cp -r /home/z/my-project/.context /tmp/backup/
cp -r /home/z/my-project/.spec /tmp/backup/
cp /home/z/my-project/package.json /tmp/backup/
cp /home/z/my-project/tsconfig.json /tmp/backup/
cp /home/z/my-project/next.config.ts /tmp/backup/

# أرشفة
cd /tmp && tar -czvf workspace-important.tar.gz backup/
```

---

### الحل 4: استخدام .gitignore للأرشفة

```bash
# الاعتماد على git للملفات المهمة
git add .
git commit -m "checkpoint"

# أرشفة الملفات المتتبعة فقط
git archive --format=tar.gz -o /tmp/workspace-git.tar.gz HEAD
```

---

## 📋 ملفات يجب تضمينها دائماً في الأرشفة

```
✅ الملفات المهمة (أولوية عالية):
├── src/                    # الكود المصدري
├── prisma/                 # قاعدة البيانات
├── .context/               # ملفات السياق ← مهم!
├── .spec/                  # مواصفات Spec
├── package.json            # التبعيات
├── tsconfig.json           # إعدادات TypeScript
├── next.config.ts          # إعدادات Next.js
└── tailwind.config.ts      # إعدادات Tailwind

⚠️ ملفات متوسطة الأهمية:
├── public/                 # الملفات العامة
├── components.json         # إعدادات shadcn
└── .env.example           # مثال البيئة

❌ ملفات لا تحتاج أرشفة:
├── node_modules/          # يمكن إعادة تثبيتها
├── .next/                 # يُبنى تلقائياً
├── dist/                  # يُبنى تلقائياً
├── *.log                  # سجلات مؤقتة
├── .db                    # يمكن إعادة إنشائها
└── .env                   # بيانات حساسة
```

---

## 🔄 آلية الحفظ التلقائي

### قبل كل عملية مهمة، نفذ:

```bash
# حفظ سريع للسياق
save_context() {
    echo "💾 حفظ السياق..."
    tar --exclude='node_modules' \
        --exclude='.next' \
        --exclude='*.db' \
        --exclude='*.log' \
        -czvf /tmp/context-backup.tar.gz \
        /home/z/my-project/.context \
        /home/z/my-project/.spec \
        /home/z/my-project/src \
        /home/z/my-project/prisma
    echo "✅ تم الحفظ في /tmp/context-backup.tar.gz"
}
```

---

## 📊 أحجام المجلدات (للمراقبة)

```bash
# فحص حجم كل مجلد
du -sh /home/z/my-project/* 2>/dev/null | sort -hr | head -20

# فحص node_modules
du -sh /home/z/my-project/node_modules

# فحص العدد الإجمالي للملفات
find /home/z/my-project -type f | wc -l
```

---

## 🎯 التوصيات

| الوضع | الإجراء |
|-------|---------|
| **أرشفة عادية** | استخدم الحل 1 (تنظيف) |
| **أرشفة سريعة** | استخدم الحل 3 (ملفات مهمة فقط) |
| **قبل عملية كبيرة** | استخدم الحل 4 (git archive) |
| **فشل متكرر** | استخدم الحل 2 (انتقائي) |

---

## 📝 سجل المشاكل السابقة

| التاريخ | المشكلة | الحل المُستخدم |
|---------|---------|----------------|
| 2026-03-17 | تم توثيق الآلية | - |

---

**آخر تحديث:** 2026-03-17
