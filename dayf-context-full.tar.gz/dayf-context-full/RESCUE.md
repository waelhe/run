# 🚨 RESCUE.md - ابدأ من هنا!

## ⚠️ تحذير هام!

> **إذا كنت تقرأ هذا الملف، فأنت في جلسة جديدة بعد انتهاء context سابق!**
> **لا تبدأ أي عمل قبل قراءة السياق!**

---

## ⚡ القواعد الذهبية

> **1. لا تستخدم Write tool على worklog.md - استخدم append فقط!**
> **2. نفذ `init-session.sh` في بداية كل جلسة**
> **3. وثّق بعد كل إنجاز صغير - لا تنتظر النهاية!**

---

## 🔄 الخطوة 0: تهيئة الجلسة (إلزامي!)

```bash
# نفذ هذا أولاً!
bash .context/init-session.sh
```

هذا السكربت:
- يبحث عن جلسة سابقة
- يفحص وجود worklog.md و .context/
- ينشئ SESSION_ID جديد
- يضيف "بداية الجلسة" لـ worklog.md (append!)
- يعمل git commit

---

## 📋 الخطوة 1: اقرأ ملفات السياق

```
اقرأ هذه الملفات بالترتيب:
1. .context/STATUS.md      ← الحالة الحالية
2. .context/TODO.md        ← المهام المعلقة
3. worklog.md              ← سجل العمل الكامل
4. .context/git-history.txt ← تاريخ Git (إذا وُجد)
```

---

## 📋 الخطوة 2: افهم أين توقفت الجلسة السابقة

| السؤال | المصدر |
|--------|--------|
| كم عدد أخطاء TypeScript؟ | STATUS.md |
| ما آخر إصلاح تم؟ | worklog.md |
| ما المهام المعلقة؟ | TODO.md |
| ما القرارات المعمارية؟ | DECISIONS.md |

---

## 📋 الخطوة 3: أكمل من حيث توقفت

```
لا تبدأ من الصفر!
استخدم المعلومات من ملفات السياق للاستمرار
```

---

## 🔧 أدوات مساعدة

```bash
# فحص سريع
bash .context/check.sh --quick

# حفظ Git History
bash .context/git-save.sh

# نسخة احتياطية
bash .context/backup.sh
```

---

## 📁 هيكل ملفات السياق

```
.context/
├── STATUS.md           ← الحالة الحالية
├── TODO.md             ← المهام
├── CHANGELOG.md        ← سجل التغييرات
├── CHECKPOINTS.md      ← نقاط الحفظ
├── DECISIONS.md        ← القرارات المعمارية
├── QUICKSTART.md       ← دليل البدء السريع
├── CHECKLIST.md        ← قائمة الفحص الشامل
└── ...                 ← باقي الملفات

worklog.md              ← سجل العمل (append-only)
```

---

## ⏰ قبل انتهاء هذه الجلسة

> **إذا شعرت أن الجلسة قد تنتهي قريباً:**
> 1. نفذ: `bash .context/rescue.sh` ← **الأهم!**
> 2. أضف لـ worklog.md ما أنجزته
> 3. حدّث STATUS.md و TODO.md

---

## 🆘 إذا لم تجد ملفات السياق!

### ابحث عن الإنقاذات السابقة:
```bash
# عرض قائمة الإنقاذات
cat /tmp/context-rescue-list.txt

# البحث عن الملفات
find /tmp -name "context-rescue-*.tar.gz" 2>/dev/null
```

### استعد من الإنقاذ:
```bash
# استخراج
tar -xzvf /tmp/context-rescue-XXXXXX.tar.gz -C /tmp/

# نسخ الملفات
cp -r /tmp/context-rescue-XXXXXX/.context /home/z/my-project/
cp /tmp/context-rescue-XXXXXX/worklog.md /home/z/my-project/
```

📄 راجع: `.context/RESTORE-CONTEXT.md`

---

## 📋 ملخص دورة حياة الجلسة

```bash
# ═══════════════════════════════════════════════════════════════
#                    دورة حياة الجلسة الكاملة
# ═══════════════════════════════════════════════════════════════

# 🚀 بداية الجلسة:
bash .context/init-session.sh

# 📝 بعد كل إنجاز:
bash .context/log-achievement.sh "الإنجاز" "الملفات"

# 🔖 عند milestone:
bash .context/checkpoint.sh "اسم checkpoint"

# 📦 حفظ Git (دورياً):
bash .context/git-save.sh

# 🆘 قبل انتهاء الجلسة:
bash .context/rescue.sh

# ═══════════════════════════════════════════════════════════════
```

📄 **للمزيد من التفاصيل راجع:** `.context/MASTER-SYSTEM.md`

---

**آخر تحديث:** 2026-03-17
