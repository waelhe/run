# 📜 سجل التغييرات (CHANGELOG)

## 🔄 آخر تحديث: 2026-03-17

---

## [2026-03-17] - جلسة الإصلاحات الكبرى

### ✅ مُضاف

#### 1. تثبيت التبعيات
- `bun add bcryptjs` - لحل "Module not found"
- `bun add jose` - لحل "Module not found"

#### 2. إعداد قاعدة البيانات
- `bun run db:push` - إنشاء الجداول
- `bun run db:seed` - ملء البيانات الأولية

#### 3. إصلاحات TypeScript
- `tsconfig.json`: إضافة `"exclude": ["node_modules", "examples/**", "skills/**"]`
- `src/core/types/listing.types.ts`: تغيير `status` و `type` إلى `string`
- `src/core/types/company.types.ts`: تغيير `status` إلى `string`
- `src/core/interfaces/repository.interface.ts`: إضافة `page`, `limit`, `skip`, `take`, `orderBy` إلى `FindOptions`

#### 4. إصلاحات Runtime
- `src/infrastructure/services/permissions.ts`: تغيير `'*'` إلى `'all'`
- `src/infrastructure/repositories/listing.repository.ts`: معالجة `status` كـ `{ in: [...] }`
- `next.config.ts`: إزالة `ignoreBuildErrors`

#### 5. Result Pattern Helpers
- إنشاء `unwrapOrNull<T>(result: Result<T, Error>): T | null`
- إنشاء `unwrapOrThrow<T>(result: Result<T, Error>): T`
- إضافة `findByIdOrNull` إلى ListingRepository و CompanyRepository

#### 6. نظام التوثيق
- إنشاء `.context/` - ملفات حفظ السياق
- إنشاء `.spec/` - ملفات Spec-Driven Development

### ⚠️ تم التراجع عنه

#### Permission.ts (إصلاحات خاطئة)
- ~~توسيع regex لقبول `*`~~ → تم التراجع (يخفي أخطاء)
- ~~تحويل `throw` إلى `console.warn`~~ → تم التراجع (يخفي أخطاء)

### 📊 الإحصائيات

```
أخطاء TypeScript:
  قبل: 1314
  بعد: 1158
  التحسن: -156 (-12%)
```

---

## [قبل 2026-03-17] - التحويل من Firebase إلى Prisma

### 🔄 تم تحويله

| الكود الأصلي | الكود الحالي |
|-------------|--------------|
| Firebase/Firestore | Prisma + SQLite |
| React + Vite | Next.js 16 + App Router |
| Feature-based | Clean Architecture (5 طبقات) |

### 📁 الهيكل المعماري

```
src/
├── core/           # Domain Layer
│   ├── entities/   # الكيانات
│   ├── types/      # الأنواع
│   ├── interfaces/ # الواجهات
│   └── errors/     # الأخطاء
├── application/    # Application Layer
│   ├── use-cases/  # حالات الاستخدام
│   ├── mappers/    # المحولات
│   └── dtos/       # كائنات نقل البيانات
├── infrastructure/ # Infrastructure Layer
│   ├── repositories/ # المستودعات
│   └── services/   # الخدمات
├── components/     # Presentation Layer
└── app/           # Next.js App Router
    ├── api/       # API Routes
    └── (routes)/  # الصفحات
```

---

## 📋 قائمة الملفات المعدلة (تاريخياً)

### ملفات Configuration
- `tsconfig.json` - استبعاد مجلدات
- `next.config.ts` - إزالة ignoreBuildErrors
- `package.json` - إضافة bcryptjs, jose
- `prisma/schema.prisma` - تعريف الجداول

### ملفات Core Layer
- `src/core/types/listing.types.ts` - أنواع string
- `src/core/types/company.types.ts` - أنواع string
- `src/core/interfaces/repository.interface.ts` - إضافة FindOptions

### ملفات Infrastructure Layer
- `src/infrastructure/services/permissions.ts` - `'all'` بدل `'*'`
- `src/infrastructure/repositories/listing.repository.ts` - معالجة مصفوفة status

### ملفات Application Layer
- `src/application/listings/use-cases.ts` - استخدام findByIdOrNull

---

## 🔖 المراجع

- **المرجع المعماري**: `مرجع` - مواصفات البنية
- **الكود الأصلي**: `dayf-17.zip` - React + Vite + Firebase
