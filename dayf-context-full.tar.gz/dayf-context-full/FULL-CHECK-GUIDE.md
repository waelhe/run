# 📚 دليل تنفيذ الفحص الشامل اليدوي

## 🔄 آخر تحديث: 2026-03-17

---

## ⚠️ قبل البدء

```bash
# 1. حفظ نسخة احتياطية
bash .context/backup.sh

# 2. تسجيل وقت البداية
date

# 3. قراءة الحالة الحالية
cat .context/STATUS.md
```

---

## 📋 خطوات الفحص الشامل (152 بند)

### المرحلة 1: البناء والتجميع (5 دقائق)

```bash
# 1.1 فحص ESLint
bun run lint

# 1.2 فحص TypeScript
npx tsc --noEmit 2>&1 | tee /tmp/ts-errors.txt

# 1.3 عدد الأخطاء
npx tsc --noEmit 2>&1 | grep -c "error TS"

# 1.4 فحص Build (اختياري - قد يستغرق وقتاً)
bun run build
```

**سجل النتائج:**
- [ ] ESLint: ________ أخطاء
- [ ] TypeScript: ________ أخطاء
- [ ] Build: ________ (نجح/فشل)

---

### المرحلة 2: TypeScript المتعمق (10 دقائق)

```bash
# 2.1 تصنيف الأخطاء حسب النوع
npx tsc --noEmit 2>&1 | grep "error TS" | cut -d'(' -f2 | cut -d',' -f1 | sort | uniq -c | sort -rn

# 2.2 أخطاء TS2339 (Property does not exist)
npx tsc --noEmit 2>&1 | grep "TS2339" | wc -l

# 2.3 أخطاء TS2322 (Type not assignable)
npx tsc --noEmit 2>&1 | grep "TS2322" | wc -l

# 2.4 أخطاء TS1205 (Type-only exports)
npx tsc --noEmit 2>&1 | grep "TS1205" | wc -l

# 2.5 أخطاء حسب المجلد
npx tsc --noEmit 2>&1 | grep "error TS" | grep -oP 'src/[^/]+' | sort | uniq -c | sort -rn
```

**سجل النتائج:**
| نوع الخطأ | العدد |
|-----------|-------|
| TS2339 | |
| TS2322 | |
| TS1205 | |
| TS2305 | |
| أخرى | |

---

### المرحلة 3: ESLint & Code Style (3 دقائق)

```bash
# 3.1 فحص ESLint
bun run lint 2>&1 | tee /tmp/eslint-output.txt

# 3.2 البحث عن console.log
grep -r "console.log" src/ --include="*.ts" --include="*.tsx" | wc -l

# 3.3 البحث عن any
grep -r ": any" src/ --include="*.ts" --include="*.tsx" | wc -l

# 3.4 البحث عن TODO
grep -r "TODO" src/ --include="*.ts" --include="*.tsx" | head -20
```

---

### المرحلة 4: Runtime & Server (5 دقائق)

```bash
# 4.1 فحص الخادم
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000

# 4.2 فحص Response Time
curl -s -w "\nTime: %{time_total}s\n" http://localhost:3000 > /dev/null

# 4.3 فحص الـ logs الأخيرة
tail -100 /home/z/my-project/dev.log | grep -i "error\|warning\|failed"

# 4.4 فحص العمليات
ps aux | grep "next\|node\|bun" | grep -v grep
```

---

### المرحلة 5: API Routes (10 دقائق)

```bash
# 5.1 قائمة بكل API routes
find src/app -name "route.ts" -type f

# 5.2 اختبار كل endpoint
# Listings
curl -s http://localhost:3000/api/listings | head -100
curl -s -X POST http://localhost:3000/api/listings -H "Content-Type: application/json" -d '{}' 

# Users
curl -s http://localhost:3000/api/users | head -100

# Bookings
curl -s http://localhost:3000/api/bookings | head -100

# 5.3 فحص Status Codes
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/listings
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/users
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/bookings

# 5.4 فحص Error Handling
curl -s http://localhost:3000/api/nonexistent
```

**سجل النتائج:**
| Endpoint | GET | POST | Status |
|----------|-----|------|--------|
| /api/listings | | | |
| /api/users | | | |
| /api/bookings | | | |

---

### المرحلة 6: قاعدة البيانات & Prisma (5 دقائق)

```bash
# 6.1 فحص Schema
cat prisma/schema.prisma | grep -E "^model|^  [a-z]+ .+" | head -50

# 6.2 فحص التزامن
bun run db:push --force-reset 2>&1 | tail -20

# 6.3 فحص البيانات
sqlite3 prisma/dev.db "SELECT name FROM sqlite_master WHERE type='table';"

# 6.4 عدد السجلات في كل جدول
sqlite3 prisma/dev.db "SELECT 'users', COUNT(*) FROM User UNION SELECT 'listings', COUNT(*) FROM Listing UNION SELECT 'bookings', COUNT(*) FROM Booking;"

# 6.5 فحص Relations
sqlite3 prisma/dev.db ".schema" | grep -i "foreign key"
```

**سجل النتائج:**
| الجدول | عدد السجلات |
|--------|-------------|
| User | |
| Listing | |
| Booking | |
| Company | |

---

### المرحلة 7: التبعيات (3 دقائق)

```bash
# 7.1 فحص التبعيات
bun install 2>&1 | tail -10

# 7.2 فحص Vulnerabilities
bun audit 2>/dev/null || npm audit 2>/dev/null

# 7.3 التبعيات غير المستخدمة (يتطلب npx)
npx depcheck --json 2>/dev/null | head -50

# 7.4 حجم node_modules
du -sh node_modules
```

---

### المرحلة 8: الأمان (5 دقائق)

```bash
# 8.1 فحص .gitignore
cat .gitignore | grep -E "\.env|\.db|node_modules"

# 8.2 فحص تسرب Secrets
grep -r "password\|secret\|api_key\|token" src/ --include="*.ts" | grep -v "type\|interface\|//\|/*" | head -20

# 8.3 فحص .env
ls -la .env* 2>/dev/null

# 8.4 فحص Authentication
grep -r "session\|jwt\|token" src/ --include="*.ts" | head -20
```

---

### المرحلة 9: Architecture Compliance (15 دقيقة)

```bash
# 9.1 فحص Imports العكسية (Domain يجب لا يعتمد على شيء)
echo "=== Domain Imports (يجب لا توجد imports من طبقات أخرى) ==="
grep -r "from '@/" src/core/ --include="*.ts" | grep -v "types\|errors\|interfaces" | head -20

# 9.2 فحص Application layer
echo "=== Application Imports (يجب فقط Domain) ==="
grep -r "from '@/infrastructure'" src/application/ --include="*.ts" | head -20

# 9.3 فحص Repository Pattern
echo "=== Repository Pattern ==="
find src/infrastructure/repositories -name "*.ts" -exec basename {} \; | sort

# 9.4 فحص Use Cases
echo "=== Use Cases ==="
find src/application -name "*use-case*" -o -name "*useCase*" | head -20

# 9.5 فحص Result Pattern
echo "=== Result Pattern Usage ==="
grep -r "Result<" src/ --include="*.ts" | wc -l
grep -r "isOk()\|isErr()" src/ --include="*.ts" | wc -l
```

---

### المرحلة 10: جودة الكود (10 دقائق)

```bash
# 10.1 خطوط الكود
find src/ -name "*.ts" -o -name "*.tsx" | xargs wc -l | tail -1

# 10.2 أطول الملفات
find src/ -name "*.ts" -o -name "*.tsx" | xargs wc -l | sort -rn | head -10

# 10.3 دوال طويلة (أكثر من 50 سطر)
# يتطلب تحليل أعمق

# 10.4 ملفات بدون tests
find src/ -name "*.test.ts" -o -name "*.spec.ts" | wc -l

# 10.5 TODO و FIXME
grep -r "TODO\|FIXME" src/ --include="*.ts" --include="*.tsx" | wc -l
```

---

### المرحلة 11: الأداء (5 دقائق)

```bash
# 11.1 حجم Build
ls -la .next/ 2>/dev/null | head -10

# 11.2 Response Time
curl -s -w "Time: %{time_total}s\n" http://localhost:3000/api/listings > /dev/null

# 11.3 Memory Usage
ps aux | grep "next\|node" | awk '{print $6}' | awk '{s+=$1} END {print s/1024 " MB"}'

# 11.4 حجم Bundle
du -sh .next/static 2>/dev/null || echo "Build غير موجود"
```

---

### المرحلة 12: هيكل الملفات (3 دقائق)

```bash
# 12.1 هيكل المجلدات
tree src/ -L 2 -d 2>/dev/null || find src/ -type d | head -30

# 12.2 عدد الملفات
find src/ -type f -name "*.ts" | wc -l
find src/ -type f -name "*.tsx" | wc -l

# 12.3 الملفات الكبيرة
find src/ -type f -size +50k -exec ls -lh {} \;

# 12.4 ملفات فارغة
find src/ -type f -empty
```

---

### المرحلة 13: Imports & Exports (10 دقائق)

```bash
# 13.1 فحص Imports غير المستخدمة
npx ts-unused-exports tsconfig.json --ignoreFiles="*.d.ts" 2>/dev/null | head -50

# 13.2 فحص Barrel Files
find src/ -name "index.ts" | head -20

# 13.3 فحص type exports
grep -r "export type" src/ --include="*.ts" | wc -l
grep -r "export {" src/ --include="*.ts" | grep "type" | wc -l

# 13.4 فحص Absolute Imports
grep -r "from '@/" src/ --include="*.ts" | wc -l
grep -r "from '\.\." src/ --include="*.ts" | wc -l
```

---

### المرحلة 14: Environment Variables (2 دقيقة)

```bash
# 14.1 قائمة المتغيرات المطلوبة
grep -r "process.env" src/ --include="*.ts" | grep -oE "\.[A-Z_]+" | sort | uniq

# 14.2 فحص .env.example
cat .env.example 2>/dev/null || echo "غير موجود"

# 14.3 فحص .gitignore
grep "\.env" .gitignore
```

---

### المرحلة 15: التوثيق (5 دقائق)

```bash
# 15.1 فحص README
cat README.md 2>/dev/null | head -50

# 15.2 فحص .context
ls -la .context/ 2>/dev/null

# 15.3 فحص .spec
ls -la .spec/ 2>/dev/null

# 15.4 فحص Inline Documentation
grep -r "/\*\*" src/ --include="*.ts" | wc -l
grep -r "//" src/ --include="*.ts" | wc -l
```

---

## 📊 إنشاء التقرير النهائي

بعد إكمال كل المراحل، أنشئ تقريراً:

```bash
# إنشاء تقرير
cat > /tmp/check-report-$(date +%Y%m%d).md << 'EOF'
# 🔍 تقرير الفحص الشامل

## 📅 التاريخ: $(date)

## 📊 ملخص النتائج

| الفئة | ✅ | ❌ | ⚠️ |
|-------|----|----|----|
| 1. Build | | | |
| 2. TypeScript | | | |
| ... | | | |

## 🔴 المشاكل الحرجة
- 

## ⚠️ المشاكل المتوسطة
- 

## 🟢 التحسينات المقترحة
- 

## 🎯 التوصيات
- 
EOF
```

---

## ⏱️ الوقت المقدر

| المرحلة | الوقت |
|---------|-------|
| 1-3 (بناء/TypeScript/ESLint) | 18 دقيقة |
| 4-5 (Runtime/API) | 15 دقيقة |
| 6-7 (DB/Dependencies) | 8 دقائق |
| 8-9 (Security/Architecture) | 20 دقيقة |
| 10-11 (Quality/Performance) | 15 دقيقة |
| 12-15 (Structure/Imports/Env/Docs) | 20 دقيقة |
| **المجموع** | **~96 دقيقة** |

---

## 💾 بعد الفحص

```bash
# 1. حدّث STATUS.md
# 2. حدّث TODO.md
# 3. أنشئ Checkpoint في CHECKPOINTS.md
# 4. احفظ النسخة الاحتياطية
bash .context/backup.sh
```

---

**آخر تحديث:** 2026-03-17
