#!/bin/bash

# 🔄 سكربت استعادة النسخة الاحتياطية
# الاستخدام: bash .context/restore.sh [backup-file]

BACKUP_FILE=$1

echo "═══════════════════════════════════════════════════════════"
echo "           🔄 استعادة النسخة الاحتياطية"
echo "═══════════════════════════════════════════════════════════"

# إذا لم يُحدد ملف، اعرض القائمة
if [ -z "$BACKUP_FILE" ]; then
    echo ""
    echo "📋 النسخ الاحتياطية المتاحة:"
    echo ""
    
    if [ -f /tmp/dayf-backups-list.txt ]; then
        cat -n /tmp/dayf-backups-list.txt
        echo ""
        echo "Usage: bash .context/restore.sh [file-number-or-path]"
    else
        echo "❌ لا يوجد سجل نسخ احتياطية"
        echo "   يمكنك تحديد المسار يدوياً:"
        echo "   bash .context/restore.sh /path/to/backup.tar.gz"
    fi
    exit 0
fi

# إذا كان رقماً، استخدم الملف من القائمة
if [[ "$BACKUP_FILE" =~ ^[0-9]+$ ]]; then
    BACKUP_FILE=$(sed -n "${BACKUP_FILE}p" /tmp/dayf-backups-list.txt)
fi

# التحقق من وجود الملف
if [ ! -f "$BACKUP_FILE" ]; then
    echo "❌ الملف غير موجود: $BACKUP_FILE"
    exit 1
fi

echo ""
echo "📄 الملف: $BACKUP_FILE"
echo ""

# إنشاء مجلد مؤقت
RESTORE_DIR="/tmp/restore-$(date +%s)"
mkdir -p "$RESTORE_DIR"

# فك الضغط
echo "📦 فك الضغط..."
tar -xzvf "$BACKUP_FILE" -C "$RESTORE_DIR" 2>/dev/null

# البحث عن المجلد المستخرج
EXTRACTED_DIR=$(find "$RESTORE_DIR" -maxdepth 1 -type d -name "dayf-backup-*" | head -1)

if [ -z "$EXTRACTED_DIR" ]; then
    echo "❌ فشل في استخراج الملفات"
    rm -rf "$RESTORE_DIR"
    exit 1
fi

echo ""
echo "📁 الملفات المستخرجة:"
ls -la "$EXTRACTED_DIR"

echo ""
echo "⚠️  تحذير: هذا سيستبدل الملفات الحالية!"
read -p "هل تريد المتابعة؟ (y/n): " CONFIRM

if [ "$CONFIRM" != "y" ]; then
    echo "❌ تم الإلغاء"
    rm -rf "$RESTORE_DIR"
    exit 0
fi

# استعادة الملفات
echo ""
echo "🔄 استعادة الملفات..."

# استعادة السياق
if [ -d "$EXTRACTED_DIR/.context" ]; then
    rm -rf /home/z/my-project/.context
    cp -r "$EXTRACTED_DIR/.context" /home/z/my-project/
    echo "  ✅ .context/"
fi

# استعادة Spec
if [ -d "$EXTRACTED_DIR/.spec" ]; then
    rm -rf /home/z/my-project/.spec
    cp -r "$EXTRACTED_DIR/.spec" /home/z/my-project/
    echo "  ✅ .spec/"
fi

# استعادة src
if [ -d "$EXTRACTED_DIR/src" ]; then
    rm -rf /home/z/my-project/src
    cp -r "$EXTRACTED_DIR/src" /home/z/my-project/
    echo "  ✅ src/"
fi

# استعادة ملفات الإعداد
cp "$EXTRACTED_DIR/package.json" /home/z/my-project/ 2>/dev/null && echo "  ✅ package.json"
cp "$EXTRACTED_DIR/tsconfig.json" /home/z/my-project/ 2>/dev/null && echo "  ✅ tsconfig.json"
cp "$EXTRACTED_DIR/next.config.ts" /home/z/my-project/ 2>/dev/null && echo "  ✅ next.config.ts"

# تنظيف
rm -rf "$RESTORE_DIR"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ تمت الاستعادة بنجاح!"
echo ""
echo "📝 لا تنسَ:"
echo "   1. تشغيل: bun install"
echo "   2. مراجعة: .context/STATUS.md"
echo "═══════════════════════════════════════════════════════════"
