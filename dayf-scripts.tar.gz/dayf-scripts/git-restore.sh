#!/bin/bash

# 🔄 سكربت استعادة Git History
# الاستخدام: bash .context/git-restore.sh [bundle-file]

BUNDLE_FILE=$1

echo "═══════════════════════════════════════════════════════════════"
echo "                    🔄 استعادة Git History"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# إذا لم يُحدد ملف، اعرض القائمة
if [ -z "$BUNDLE_FILE" ]; then
    echo "📋 Bundles المتاحة:"
    echo ""
    
    if [ -f /tmp/git-backups-list.txt ]; then
        cat -n /tmp/git-backups-list.txt
        echo ""
        echo "Usage: bash .context/git-restore.sh [number-or-path]"
    else
        echo "❌ لا يوجد سجل bundles"
        echo ""
        echo "💡 البحث عن bundles..."
        find /tmp -name "git-backup-*.bundle" 2>/dev/null
    fi
    exit 0
fi

# إذا كان رقماً، استخدم الملف من القائمة
if [[ "$BUNDLE_FILE" =~ ^[0-9]+$ ]]; then
    BUNDLE_FILE=$(sed -n "${BUNDLE_FILE}p" /tmp/git-backups-list.txt)
fi

# التحقق من وجود الملف
if [ ! -f "$BUNDLE_FILE" ]; then
    echo "❌ الملف غير موجود: $BUNDLE_FILE"
    exit 1
fi

echo "📦 الملف: $BUNDLE_FILE"
echo ""

# التحقق من صحة الـ bundle
echo "🔍 التحقق من صحة الـ bundle..."
if git bundle verify "$BUNDLE_FILE" 2>/dev/null; then
    echo "  ✅ الـ bundle صالح"
else
    echo "  ⚠️  تحذير: قد يكون الـ bundle غير مكتمل"
fi

echo ""
echo "⚠️  تحذير: هذا سينشئ مجلد جديد مع الـ git history"
read -p "هل تريد المتابعة؟ (y/n): " CONFIRM

if [ "$CONFIRM" != "y" ]; then
    echo "❌ تم الإلغاء"
    exit 0
fi

# إنشاء مجلد الاستعادة
RESTORE_DIR="restored-git-$(date +%Y%m%d-%H%M%S)"
echo ""
echo "📁 إنشاء مجلد: $RESTORE_DIR"

# استخراج من الـ bundle
git clone "$BUNDLE_FILE" "$RESTORE_DIR" 2>&1

if [ -d "$RESTORE_DIR/.git" ]; then
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "✅ تمت الاستعادة بنجاح!"
    echo ""
    echo "📁 المجلد: $RESTORE_DIR"
    echo ""
    cd "$RESTORE_DIR"
    echo "📊 معلومات المستودع:"
    echo "   Commits: $(git log --oneline | wc -l)"
    echo "   Branch: $(git branch --show-current)"
    echo ""
    echo "💡 لاستبدال المشروع الحالي:"
    echo "   1. انسخ الملفات من $RESTORE_DIR"
    echo "   2. أو اعمل في المجلد الجديد"
    echo "═══════════════════════════════════════════════════════════════"
else
    echo "❌ فشلت الاستعادة"
    exit 1
fi
