#!/bin/bash

# 🔍 سكربت الفحص الشامل التلقائي
# الاستخدام: bash .context/check.sh [--quick | --full]

MODE=${1:---quick}

echo "═══════════════════════════════════════════════════════════════"
echo "                    🔍 الفحص الشامل للمشروع"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 التاريخ: $(date '+%Y-%m-%d %H:%M:%S')"
echo "🔧 الوضع: $MODE"
echo ""

# متغيرات للنتائج
TOTAL_CHECKS=0
PASSED=0
FAILED=0
WARNINGS=0
ISSUES=""

# دالة لتسجيل النتائج
check_pass() {
    PASSED=$((PASSED + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo "  ✅ $1"
}

check_fail() {
    FAILED=$((FAILED + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo "  ❌ $1"
    ISSUES="$ISSUES\n- $1: $2"
}

check_warn() {
    WARNINGS=$((WARNINGS + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo "  ⚠️  $1"
    ISSUES="$ISSUES\n- $1 (تحذير): $2"
}

# ═══════════════════════════════════════════════════════════════
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣  البناء والتجميع"
echo "───────────────────────────────────────────────────────────────"

# فحص ESLint
echo ""
echo "📌 ESLint..."
if bun run lint 2>&1 | grep -q "error"; then
    check_fail "ESLint" "أخطاء في الكود"
else
    check_pass "ESlint نظيف"
fi

# فحص TypeScript
echo ""
echo "📌 TypeScript Errors..."
TS_ERRORS=$(npx tsc --noEmit 2>&1 | grep -c "error TS" 2>/dev/null || echo "0")
if [ "$TS_ERRORS" -gt 0 ]; then
    check_warn "TypeScript" "$TS_ERRORS خطأ"
else
    check_pass "TypeScript بدون أخطاء"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   4️⃣  Runtime & Server"
echo "───────────────────────────────────────────────────────────────"

# فحص الخادم
echo ""
echo "📌 الخادم (localhost:3000)..."
if curl -s --max-time 5 http://localhost:3000 > /dev/null 2>&1; then
    check_pass "الخادم يعمل"
else
    check_fail "الخادم" "لا يستجيب"
fi

# فحص الصفحة الرئيسية
echo ""
echo "📌 الصفحة الرئيسية..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
if [ "$HTTP_CODE" = "200" ]; then
    check_pass "الصفحة الرئيسية (200 OK)"
else
    check_fail "الصفحة الرئيسية" "HTTP $HTTP_CODE"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   5️⃣  API Routes"
echo "───────────────────────────────────────────────────────────────"

# فحص API listings
echo ""
echo "📌 /api/listings..."
API_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/listings 2>/dev/null)
if [ "$API_CODE" = "200" ]; then
    check_pass "API /listings (200 OK)"
else
    check_fail "API /listings" "HTTP $API_CODE"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   6️⃣  قاعدة البيانات & Prisma"
echo "───────────────────────────────────────────────────────────────"

# فحص Prisma Schema
echo ""
echo "📌 Prisma Schema..."
if [ -f "prisma/schema.prisma" ]; then
    check_pass "schema.prisma موجود"
else
    check_fail "Prisma Schema" "الملف غير موجود"
fi

# فحص قاعدة البيانات
echo ""
echo "📌 قاعدة البيانات..."
if [ -f "prisma/dev.db" ]; then
    check_pass "قاعدة البيانات موجودة"
else
    check_warn "قاعدة البيانات" "قد تحتاج bun run db:push"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   7️⃣  التبعيات"
echo "───────────────────────────────────────────────────────────────"

# فحص node_modules
echo ""
echo "📌 node_modules..."
if [ -d "node_modules" ]; then
    check_pass "node_modules موجود"
else
    check_fail "node_modules" "run bun install"
fi

# فحص package.json
echo ""
echo "📌 package.json..."
if [ -f "package.json" ]; then
    check_pass "package.json موجود"
else
    check_fail "package.json" "الملف غير موجود"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣2️⃣  هيكل الملفات"
echo "───────────────────────────────────────────────────────────────"

# فحص هيكل المجلدات
echo ""
echo "📌 المجلدات الرئيسية..."

[ -d "src" ] && check_pass "src/ موجود" || check_fail "src/" "غير موجود"
[ -d "src/app" ] && check_pass "src/app/ موجود" || check_fail "src/app/" "غير موجود"
[ -d "src/core" ] && check_pass "src/core/ موجود" || check_fail "src/core/" "غير موجود"
[ -d "src/application" ] && check_pass "src/application/ موجود" || check_warn "src/application/" "قد لا يكون ضرورياً"
[ -d "src/infrastructure" ] && check_pass "src/infrastructure/ موجود" || check_warn "src/infrastructure/" "قد لا يكون ضرورياً"

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣4️⃣  Environment Variables"
echo "───────────────────────────────────────────────────────────────"

# فحص .env
echo ""
echo "📌 Environment Files..."
if [ -f ".env" ] || [ -f ".env.local" ]; then
    check_pass "ملف .env موجود"
else
    check_warn ".env" "قد تحتاج لإنشائه"
fi

if [ -f ".env.example" ]; then
    check_pass ".env.example موجود"
else
    check_warn ".env.example" "يُنصح بإنشائه"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣5️⃣  التوثيق"
echo "───────────────────────────────────────────────────────────────"

# فحص ملفات السياق
echo ""
echo "📌 ملفات السياق..."
if [ -d ".context" ]; then
    check_pass ".context/ موجود"
    [ -f ".context/STATUS.md" ] && check_pass "STATUS.md موجود" || check_warn "STATUS.md" "غير موجود"
    [ -f ".context/TODO.md" ] && check_pass "TODO.md موجود" || check_warn "TODO.md" "غير موجود"
else
    check_warn ".context/" "يُنصح بإنشائه لحفظ السياق"
fi

# فحص Spec
echo ""
echo "📌 Spec Files..."
if [ -d ".spec" ]; then
    check_pass ".spec/ موجود"
else
    check_warn ".spec/" "يُنصح بإنشائه"
fi

# ═══════════════════════════════════════════════════════════════
# الفحص الكامل (إذا طُلب)
if [ "$MODE" = "--full" ]; then
    echo ""
    echo "───────────────────────────────────────────────────────────────"
    echo "                   🔍 فحص إضافي (Full Mode)"
    echo "───────────────────────────────────────────────────────────────"
    
    # فحص Build
    echo ""
    echo "📌 Next.js Build..."
    if bun run build 2>&1 | grep -q "Failed to compile"; then
        check_fail "Build" "فشل التجميع"
    else
        check_pass "Build يعمل"
    fi
    
    # فحص Imports الدائرية
    echo ""
    echo "📌 فحص Circular Imports..."
    # هذا يتطلب أداة إضافية، سنكتشف بوجود TypeScript errors معينة
    
    # فحص حجم node_modules
    echo ""
    echo "📌 حجم node_modules..."
    SIZE=$(du -sh node_modules 2>/dev/null | cut -f1)
    echo "  ℹ️  الحجم: $SIZE"
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
fi

# ═══════════════════════════════════════════════════════════════
# النتائج النهائية
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "                        📊 النتائج النهائية"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  إجمالي الفحوصات: $TOTAL_CHECKS"
echo "  ✅ ناجحة: $PASSED"
echo "  ❌ فاشلة: $FAILED"
echo "  ⚠️  تحذيرات: $WARNINGS"
echo ""

if [ $FAILED -gt 0 ]; then
    echo "───────────────────────────────────────────────────────────────"
    echo "                   🔴 المشاكل المكتشفة:"
    echo "───────────────────────────────────────────────────────────────"
    echo -e "$ISSUES"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════"

# كود الخروج
if [ $FAILED -gt 0 ]; then
    exit 1
else
    exit 0
fi
