# 📦 مجموعة السكربتات الكاملة - مشروع ضيف

> **تاريخ الإنشاء:** 2025-03-19
> **عدد السكربتات:** 10 سكربتات

---

## 📋 الفهرس

| # | السكربت | الفئة | الوظيفة |
|---|---------|-------|---------|
| 1 | `init-session.sh` | 🚀 الجلسة | تهيئة جلسة جديدة |
| 2 | `log-achievement.sh` | 🚀 الجلسة | تسجيل إنجاز |
| 3 | `checkpoint.sh` | 🔖 الحفظ | إنشاء نقطة حفظ |
| 4 | `backup.sh` | 💾 النسخ | نسخ احتياطي سريع |
| 5 | `restore.sh` | 💾 النسخ | استعادة نسخة احتياطية |
| 6 | `rescue.sh` | 🆘 الإنقاذ | إنقاذ السياق قبل انتهاء الجلسة |
| 7 | `git-save.sh` | 📦 Git | حفظ Git History |
| 8 | `git-restore.sh` | 📦 Git | استعادة Git History |
| 9 | `check.sh` | 🔍 الفحص | فحص شامل للمشروع |
| 10 | `worklog-add.sh` | 📝 التوثيق | إضافة لسجل العمل |

---

# ═══════════════════════════════════════════════════════════════
#                    🚀 فئة: إدارة الجلسة
# ═══════════════════════════════════════════════════════════════

---

## 1️⃣ init-session.sh - تهيئة جلسة جديدة

**الاستخدام:** `bash .context/init-session.sh`

**الوظيفة:**
- يُشغّل في بداية كل جلسة جديدة
- يفحص ملفات السياق الموجودة
- يتحقق من Git و worklog.md
- ينشئ SESSION_ID جديد
- يضيف بداية الجلسة لـ worklog.md

```bash
#!/bin/bash

# 🚀 تهيئة جلسة جديدة - يُنفذ في بداية كل جلسة
# الاستخدام: bash .context/init-session.sh

SESSION_ID=$(date +%Y%m%d-%H%M%S)
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

echo "═══════════════════════════════════════════════════════════════"
echo "                    🚀 تهيئة جلسة جديدة"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 الوقت: $TIMESTAMP"
echo "🆔 SESSION_ID: $SESSION_ID"
echo ""

# 1. البحث عن جلسة سابقة
echo "🔍 البحث عن جلسة سابقة..."
echo ""

if [ -f "/tmp/last-session-info.txt" ]; then
    echo "📄 وجدت معلومات آخر جلسة:"
    echo "───────────────────────────────────────"
    cat /tmp/last-session-info.txt
    echo "───────────────────────────────────────"
    echo ""
else
    echo "⚠️  لم أجد معلومات جلسة سابقة"
    echo ""
fi

# 2. فحص وجود worklog.md
echo "📝 فحص worklog.md..."
if [ -f "/home/z/my-project/worklog.md" ]; then
    LINES=$(wc -l < /home/z/my-project/worklog.md)
    echo "  ✅ موجود ($LINES سطر)"
    
    # عرض آخر 10 أسطر
    echo ""
    echo "📋 آخر 10 أسطر:"
    echo "───────────────────────────────────────"
    tail -10 /home/z/my-project/worklog.md
    echo "───────────────────────────────────────"
else
    echo "  ⚠️  غير موجود - سيُنشأ"
    
    # إنشاء worklog.md جديد
    cat > /home/z/my-project/worklog.md << 'EOF'
# 📜 سجل العمل (WORKLOG)

## ⚠️ قواعد مهمة

> **هذا الملف للإضافة فقط (append-only)**
> - لا تحذف المحتوى السابق أبداً
> - أضف دائماً في الأسفل
> - استخدم: `cat >> worklog.md << 'EOF' ... EOF`
> - أو: `bash .context/log-achievement.sh "إنجاز" "ملفات"`

---

EOF
    echo "  ✅ تم إنشاء worklog.md جديد"
fi
echo ""

# 3. فحص .context/
echo "📁 فحص .context/..."
if [ -d "/home/z/my-project/.context" ]; then
    FILES=$(ls /home/z/my-project/.context | wc -l)
    echo "  ✅ موجود ($FILES ملف)"
    
    # فحص الملفات المهمة
    echo ""
    echo "📋 فحص الملفات المهمة:"
    [ -f "/home/z/my-project/.context/STATUS.md" ] && echo "  ✅ STATUS.md" || echo "  ❌ STATUS.md مفقود"
    [ -f "/home/z/my-project/.context/TODO.md" ] && echo "  ✅ TODO.md" || echo "  ❌ TODO.md مفقود"
    [ -f "/home/z/my-project/.context/SESSION-STATE.md" ] && echo "  ✅ SESSION-STATE.md" || echo "  ⚠️  SESSION-STATE.md مفقود"
else
    echo "  ❌ .context/ غير موجود!"
    echo "  💡 يجب إنشاؤه أولاً"
fi
echo ""

# 4. فحص Git
echo "📦 فحص Git..."
if [ -d "/home/z/my-project/.git" ]; then
    COMMITS=$(git log --oneline 2>/dev/null | wc -l | tr -d ' ')
    echo "  ✅ موجود ($COMMITS commits)"
    
    # عرض آخر 5 commits
    echo ""
    echo "📋 آخر 5 commits:"
    echo "───────────────────────────────────────"
    git log --oneline -5 2>/dev/null || echo "  (لا يوجد commits)"
    echo "───────────────────────────────────────"
else
    echo "  ⚠️  ليس مستودع Git - جاري التهيئة..."
    git init
    echo "  ✅ تم تهيئة Git"
fi
echo ""

# 5. إنشاء معرف الجلسة
echo "🆔 تسجيل معرف الجلسة..."
export SESSION_ID="$SESSION_ID"
echo "SESSION_ID=$SESSION_ID" > /tmp/current-session.txt
echo "START_TIME=$TIMESTAMP" >> /tmp/current-session.txt
echo "  ✅ SESSION_ID: $SESSION_ID"
echo ""

# 6. إضافة بداية الجلسة لـ worklog
echo "📝 إضافة بداية الجلسة لـ worklog..."
cat >> /home/z/my-project/worklog.md << EOF

---

## 🚀 جلسة جديدة: $SESSION_ID
**الوقت:** $TIMESTAMP

### بداية الجلسة:
- تم قراءة السياق
- تم التحقق من الملفات
- الجاهزية: ✅

EOF
echo "  ✅ تمت الإضافة"
echo ""

# 7. Git commit لبداية الجلسة
echo "📦 Git commit لبداية الجلسة..."
git add -A 2>/dev/null
git commit -m "🚀 بدء جلسة $SESSION_ID" --allow-empty 2>/dev/null
echo "  ✅ تم الـ commit"
echo ""

# النتيجة النهائية
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تمت تهيئة الجلسة بنجاح!"
echo ""
echo "📋 ما يجب فعله الآن:"
echo "   1. اقرأ .context/STATUS.md"
echo "   2. اقرأ .context/TODO.md"
echo "   3. حدد المهمة التالية"
echo "   4. ابدأ العمل!"
echo ""
echo "📝 بعد كل إنجاز:"
echo "   bash .context/log-achievement.sh \"الإنجاز\" \"الملفات\""
echo ""
echo "🔖 عند إنجاز milestone:"
echo "   bash .context/checkpoint.sh \"اسم الـ checkpoint\""
echo ""
echo "═══════════════════════════════════════════════════════════════"
```

---

## 2️⃣ log-achievement.sh - تسجيل إنجاز

**الاستخدام:** `bash .context/log-achievement.sh "وصف الإنجاز" "ملف1,ملف2"`

**الوظيفة:**
- يُشغّل بعد كل إنجاز صغير
- يضيف لـ worklog.md
- يحدّث SESSION-STATE.md
- يعمل Git commit

```bash
#!/bin/bash

# 📝 تسجيل إنجاز - يُنفذ بعد كل إنجاز صغير
# الاستخدام: bash .context/log-achievement.sh "وصف الإنجاز" "ملف1,ملف2"

ACHIEVEMENT=${1:-"تحديث"}
FILES=${2:-"غير محدد"}
TIMESTAMP=$(date '+%H:%M')
DATE=$(date '+%Y-%m-%d')
WORKLOG="/home/z/my-project/worklog.md"
SESSION_STATE="/home/z/my-project/.context/SESSION-STATE.md"

echo "═══════════════════════════════════════════════════════════════"
echo "                    📝 تسجيل إنجاز"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "⏰ الوقت: $TIMESTAMP"
echo "📋 الإنجاز: $ACHIEVEMENT"
echo "📁 الملفات: $FILES"
echo ""

# 1. إضافة لـ worklog.md (append فقط!)
echo "📝 إضافة لـ worklog.md..."
cat >> "$WORKLOG" << EOF

### [$TIMESTAMP] $ACHIEVEMENT
- الملفات المعدلة: $FILES
- النتيجة: ✅ تم

EOF
echo "  ✅ تمت الإضافة"

# 2. تحديث SESSION-STATE.md
echo ""
echo "📝 تحديث SESSION-STATE.md..."

# تحديث LAST_UPDATE
sed -i "s/LAST_UPDATE.*/LAST_UPDATE | $DATE $TIMESTAMP |/" "$SESSION_STATE" 2>/dev/null

# إضافة الإنجاز
cat >> "$SESSION_STATE" << EOF

### [$TIMESTAMP] $ACHIEVEMENT
- الملفات: $FILES

EOF
echo "  ✅ تم التحديث"

# 3. Git commit
echo ""
echo "📦 Git commit..."
cd /home/z/my-project

# التحقق من وجود Git
if [ -d ".git" ]; then
    # إضافة كل التغييرات
    git add -A 2>/dev/null
    
    # commit
    git commit -m "[$TIMESTAMP] $ACHIEVEMENT" --allow-empty 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo "  ✅ تم الـ commit"
    else
        echo "  ⚠️  لا توجد تغييرات جديدة"
    fi
else
    echo "  ⚠️  ليس مستودع Git - جاري التهيئة..."
    git init 2>/dev/null
    git add -A 2>/dev/null
    git commit -m "[$TIMESTAMP] $ACHIEVEMENT" --allow-empty 2>/dev/null
    echo "  ✅ تم تهيئة Git وعمل commit"
fi

# 4. حفظ معلومات الجلسة
echo ""
echo "💾 حفظ معلومات الجلسة..."
echo "LAST_ACHIEVEMENT=$ACHIEVEMENT" > /tmp/last-session-info.txt
echo "LAST_TIME=$TIMESTAMP" >> /tmp/last-session-info.txt
echo "LAST_FILES=$FILES" >> /tmp/last-session-info.txt
echo "WORKLOG_LINES=$(wc -l < "$WORKLOG")" >> /tmp/last-session-info.txt
echo "  ✅ تم الحفظ في /tmp/last-session-info.txt"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم تسجيل الإنجاز بنجاح!"
echo ""
echo "📊 الإحصائيات:"
echo "   worklog.md: $(wc -l < "$WORKLOG") سطر"
echo "   Git commits: $(git log --oneline 2>/dev/null | wc -l)"
echo "═══════════════════════════════════════════════════════════════"
```

---

# ═══════════════════════════════════════════════════════════════
#                    🔖 فئة: الحفظ والاستعادة
# ═══════════════════════════════════════════════════════════════

---

## 3️⃣ checkpoint.sh - إنشاء نقطة حفظ

**الاستخدام:** `bash .context/checkpoint.sh "اسم-checkpoint"`

**الوظيفة:**
- يُنشئ عند إنجاز milestone
- يجمع الإحصائيات
- يضيف لـ worklog.md و CHECKPOINTS.md
- ينشئ Git tag وأرشيف

```bash
#!/bin/bash

# 🔖 إنشاء Checkpoint - يُنفذ عند إنجاز milestone
# الاستخدام: bash .context/checkpoint.sh "وصف الـ checkpoint"

CHECKPOINT_NAME=${1:-"checkpoint-$(date +%H%M)"}
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
CHECKPOINT_ID=$(date +%Y%m%d-%H%M%S)

echo "═══════════════════════════════════════════════════════════════"
echo "                    🔖 إنشاء Checkpoint"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 الوقت: $TIMESTAMP"
echo "🔖 الاسم: $CHECKPOINT_NAME"
echo "🆔 ID: $CHECKPOINT_ID"
echo ""

# 1. جمع الإحصائيات
echo "📊 جمع الإحصائيات..."
TS_ERRORS=$(npx tsc --noEmit 2>&1 | grep -c "error TS" 2>/dev/null || echo "N/A")
COMMITS=$(git log --oneline 2>/dev/null | wc -l | tr -d ' ')
WORKLOG_LINES=$(wc -l < /home/z/my-project/worklog.md 2>/dev/null || echo "0")
FILES_MODIFIED=$(find /home/z/my-project/src -name "*.ts" -newer /tmp/last-checkpoint 2>/dev/null | wc -l | tr -d ' ')

echo "   TypeScript Errors: $TS_ERRORS"
echo "   Git Commits: $COMMITS"
echo "   Worklog Lines: $WORKLOG_LINES"
echo "   Files Modified: $FILES_MODIFIED"

# 2. إضافة لـ worklog.md
echo ""
echo "📝 إضافة لـ worklog.md..."
cat >> /home/z/my-project/worklog.md << EOF

---

## 🔖 Checkpoint: $CHECKPOINT_NAME
**الوقت:** $TIMESTAMP
**ID:** $CHECKPOINT_ID

### 📊 الإحصائيات:
| البند | القيمة |
|-------|--------|
| TypeScript Errors | $TS_ERRORS |
| Git Commits | $COMMITS |
| Worklog Lines | $WORKLOG_LINES |

### 📁 الملفات المعدلة منذ آخر checkpoint:
$FILES_MODIFIED ملفات

---

EOF
echo "  ✅ تمت الإضافة"

# 3. تحديث CHECKPOINTS.md
echo ""
echo "📝 تحديث CHECKPOINTS.md..."
cat >> /home/z/my-project/.context/CHECKPOINTS.md << EOF

### Checkpoint: $CHECKPOINT_NAME
**التاريخ:** $TIMESTAMP
**ID:** $CHECKPOINT_ID

#### 📊 الإحصائيات:
| البند | القيمة |
|-------|--------|
| TypeScript Errors | $TS_ERRORS |
| Git Commits | $COMMITS |
| Worklog Lines | $WORKLOG_LINES |

#### 📁 الملفات المعدلة:
$FILES_MODIFIED ملفات

EOF
echo "  ✅ تم التحديث"

# 4. Git commit مع tag
echo ""
echo "📦 Git commit مع tag..."
cd /home/z/my-project

git add -A 2>/dev/null
git commit -m "🔖 CHECKPOINT: $CHECKPOINT_NAME" --allow-empty 2>/dev/null
git tag "checkpoint-$CHECKPOINT_ID" 2>/dev/null

echo "  ✅ تم الـ commit والـ tag"

# 5. إنشاء أرشيف checkpoint
echo ""
echo "📦 إنشاء أرشيف..."
CHECKPOINT_DIR="/tmp/checkpoint-$CHECKPOINT_ID"
mkdir -p "$CHECKPOINT_DIR"

# نسخ الملفات المهمة
cp -r .context "$CHECKPOINT_DIR/" 2>/dev/null
cp worklog.md "$CHECKPOINT_DIR/" 2>/dev/null
cp RESCUE.md "$CHECKPOINT_DIR/" 2>/dev/null
git log --oneline > "$CHECKPOINT_DIR/git-log.txt" 2>/dev/null

# إنشاء tar.gz
tar -czvf "/tmp/checkpoint-$CHECKPOINT_ID.tar.gz" -C /tmp "checkpoint-$CHECKPOINT_ID" 2>/dev/null
rm -rf "$CHECKPOINT_DIR"

CHECKPOINT_SIZE=$(du -h "/tmp/checkpoint-$CHECKPOINT_ID.tar.gz" | cut -f1)
echo "  ✅ /tmp/checkpoint-$CHECKPOINT_ID.tar.gz ($CHECKPOINT_SIZE)"

# تحديث ملف آخر checkpoint
touch /tmp/last-checkpoint
echo "$CHECKPOINT_ID" > /tmp/last-checkpoint-id.txt

# 6. تحديث last-session-info.txt
echo ""
echo "💾 تحديث معلومات الجلسة..."
cat > /tmp/last-session-info.txt << EOF
LAST_CHECKPOINT=$CHECKPOINT_ID
CHECKPOINT_NAME=$CHECKPOINT_NAME
CHECKPOINT_TIME=$TIMESTAMP
TS_ERRORS=$TS_ERRORS
COMMITS=$COMMITS
WORKLOG_LINES=$WORKLOG_LINES
EOF
echo "  ✅ تم التحديث"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم إنشاء Checkpoint بنجاح!"
echo ""
echo "📦 الأرشيف: /tmp/checkpoint-$CHECKPOINT_ID.tar.gz"
echo "🏷️  Tag: checkpoint-$CHECKPOINT_ID"
echo ""
echo "📋 للاستعادة:"
echo "   git checkout checkpoint-$CHECKPOINT_ID"
echo "   أو"
echo "   tar -xzvf /tmp/checkpoint-$CHECKPOINT_ID.tar.gz"
echo "═══════════════════════════════════════════════════════════════"
```

---

## 4️⃣ backup.sh - نسخ احتياطي سريع

**الاستخدام:** `bash .context/backup.sh`

**الوظيفة:**
- ينسخ الملفات المهمة
- ينشئ أرشيف tar.gz
- يضيف لسجل النسخ الاحتياطية

```bash
#!/bin/bash

# 💾 سكربت حفظ السياق السريع
# الاستخدام: bash .context/backup.sh

echo "═══════════════════════════════════════════════════════════"
echo "           💾 حفظ السياق والملفات المهمة"
echo "═══════════════════════════════════════════════════════════"

BACKUP_DIR="/tmp/dayf-backup-$(date +%Y%m%d-%H%M%S)"
BACKUP_FILE="${BACKUP_DIR}.tar.gz"

echo ""
echo "📁 إنشاء مجلد النسخة الاحتياطية..."
mkdir -p "$BACKUP_DIR"

# نسخ الملفات المهمة
echo "📋 نسخ الملفات المهمة..."

# السياق (الأهم!)
cp -r /home/z/my-project/.context "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ .context/"

# Spec
cp -r /home/z/my-project/.spec "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ .spec/"

# الكود المصدري
cp -r /home/z/my-project/src "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ src/"

# Prisma
cp -r /home/z/my-project/prisma "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ prisma/"

# ملفات الإعداد
cp /home/z/my-project/package.json "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ package.json"
cp /home/z/my-project/tsconfig.json "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ tsconfig.json"
cp /home/z/my-project/next.config.ts "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ next.config.ts"
cp /home/z/my-project/tailwind.config.ts "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ tailwind.config.ts"
cp /home/z/my-project/components.json "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ components.json"

# أرشفة
echo ""
echo "📦 إنشاء ملف الأرشفة..."
tar -czvf "$BACKUP_FILE" -C "$(dirname $BACKUP_DIR)" "$(basename $BACKUP_DIR)" 2>/dev/null

# تنظيف المجلد المؤقت
rm -rf "$BACKUP_DIR"

# عرض النتيجة
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ تم إنشاء النسخة الاحتياطية:"
echo "   📄 $BACKUP_FILE"
echo ""
BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
echo "   📊 الحجم: $BACKUP_SIZE"
echo "═══════════════════════════════════════════════════════════"

# إضافة موقع النسخة إلى ملف
echo "$BACKUP_FILE" >> /tmp/dayf-backups-list.txt
echo "📝 تم إضافة النسخة للسجل: /tmp/dayf-backups-list.txt"
```

---

## 5️⃣ restore.sh - استعادة نسخة احتياطية

**الاستخدام:** `bash .context/restore.sh [backup-file]`

**الوظيفة:**
- يعرض قائمة النسخ المتاحة
- يستعيد الملفات من النسخة المحددة

```bash
#!/bin/bash

# 🔄 سكربت استعادة النسخة الاحتياطية
# الاستخدام: bash .context/restore.sh [backup-file]

BACKUP_FILE=$1

echo "═══════════════════════════════════════════════════════════"
echo "           🔄 استعادة النسخة الاحتياطية"
echo "═══════════════════════════════════════════════════════════"

# إذا لم يُحدد ملف، اعرض القائمة
if [ -z "$BACKUP_FILE" ]; then
    echo ""
    echo "📋 النسخ الاحتياطية المتاحة:"
    echo ""
    
    if [ -f /tmp/dayf-backups-list.txt ]; then
        cat -n /tmp/dayf-backups-list.txt
        echo ""
        echo "Usage: bash .context/restore.sh [file-number-or-path]"
    else
        echo "❌ لا يوجد سجل نسخ احتياطية"
        echo "   يمكنك تحديد المسار يدوياً:"
        echo "   bash .context/restore.sh /path/to/backup.tar.gz"
    fi
    exit 0
fi

# إذا كان رقماً، استخدم الملف من القائمة
if [[ "$BACKUP_FILE" =~ ^[0-9]+$ ]]; then
    BACKUP_FILE=$(sed -n "${BACKUP_FILE}p" /tmp/dayf-backups-list.txt)
fi

# التحقق من وجود الملف
if [ ! -f "$BACKUP_FILE" ]; then
    echo "❌ الملف غير موجود: $BACKUP_FILE"
    exit 1
fi

echo ""
echo "📄 الملف: $BACKUP_FILE"
echo ""

# إنشاء مجلد مؤقت
RESTORE_DIR="/tmp/restore-$(date +%s)"
mkdir -p "$RESTORE_DIR"

# فك الضغط
echo "📦 فك الضغط..."
tar -xzvf "$BACKUP_FILE" -C "$RESTORE_DIR" 2>/dev/null

# البحث عن المجلد المستخرج
EXTRACTED_DIR=$(find "$RESTORE_DIR" -maxdepth 1 -type d -name "dayf-backup-*" | head -1)

if [ -z "$EXTRACTED_DIR" ]; then
    echo "❌ فشل في استخراج الملفات"
    rm -rf "$RESTORE_DIR"
    exit 1
fi

echo ""
echo "📁 الملفات المستخرجة:"
ls -la "$EXTRACTED_DIR"

echo ""
echo "⚠️  تحذير: هذا سيستبدل الملفات الحالية!"
read -p "هل تريد المتابعة؟ (y/n): " CONFIRM

if [ "$CONFIRM" != "y" ]; then
    echo "❌ تم الإلغاء"
    rm -rf "$RESTORE_DIR"
    exit 0
fi

# استعادة الملفات
echo ""
echo "🔄 استعادة الملفات..."

# استعادة السياق
if [ -d "$EXTRACTED_DIR/.context" ]; then
    rm -rf /home/z/my-project/.context
    cp -r "$EXTRACTED_DIR/.context" /home/z/my-project/
    echo "  ✅ .context/"
fi

# استعادة Spec
if [ -d "$EXTRACTED_DIR/.spec" ]; then
    rm -rf /home/z/my-project/.spec
    cp -r "$EXTRACTED_DIR/.spec" /home/z/my-project/
    echo "  ✅ .spec/"
fi

# استعادة src
if [ -d "$EXTRACTED_DIR/src" ]; then
    rm -rf /home/z/my-project/src
    cp -r "$EXTRACTED_DIR/src" /home/z/my-project/
    echo "  ✅ src/"
fi

# استعادة ملفات الإعداد
cp "$EXTRACTED_DIR/package.json" /home/z/my-project/ 2>/dev/null && echo "  ✅ package.json"
cp "$EXTRACTED_DIR/tsconfig.json" /home/z/my-project/ 2>/dev/null && echo "  ✅ tsconfig.json"
cp "$EXTRACTED_DIR/next.config.ts" /home/z/my-project/ 2>/dev/null && echo "  ✅ next.config.ts"

# تنظيف
rm -rf "$RESTORE_DIR"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ تمت الاستعادة بنجاح!"
echo ""
echo "📝 لا تنسَ:"
echo "   1. تشغيل: bun install"
echo "   2. مراجعة: .context/STATUS.md"
echo "═══════════════════════════════════════════════════════════"
```

---

## 6️⃣ rescue.sh - إنقاذ السياق

**الاستخدام:** `bash .context/rescue.sh`

**الوظيفة:**
- يُشغّل قبل انتهاء الجلسة
- يحفظ كل ملفات السياق
- يحفظ Git History
- ينشئ أرشيف إنقاذ

```bash
#!/bin/bash

# 🚨 سكربت إنقاذ السياق - نفذ قبل انتهاء الجلسة!
# الاستخدام: bash .context/rescue.sh

echo "═══════════════════════════════════════════════════════════════"
echo "              🚨 إنقاذ السياق قبل انتهاء الجلسة"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 التاريخ: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
RESCUE_DIR="/tmp/context-rescue-${TIMESTAMP}"

# إنشاء مجلد الإنقاذ
mkdir -p "$RESCUE_DIR"
echo "📁 مجلد الإنقاذ: $RESCUE_DIR"
echo ""

# ═══════════════════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📋 1. حفظ ملفات السياق"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# نسخ ملفات السياق
if [ -d ".context" ]; then
    cp -r .context "$RESCUE_DIR/"
    echo "  ✅ .context/ ($(ls .context | wc -l) ملف)"
else
    echo "  ⚠️  .context/ غير موجود"
fi

# نسخ worklog
if [ -f "worklog.md" ]; then
    cp worklog.md "$RESCUE_DIR/"
    echo "  ✅ worklog.md ($(wc -l < worklog.md) سطر)"
else
    echo "  ⚠️  worklog.md غير موجود"
fi

# نسخ RESCUE.md
if [ -f "RESCUE.md" ]; then
    cp RESCUE.md "$RESCUE_DIR/"
    echo "  ✅ RESCUE.md"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📦 2. حفظ Git History"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -d ".git" ]; then
    # تصدير التاريخ
    git log --pretty=format:"%h|%ad|%an|%s" --date=short > "$RESCUE_DIR/git-history.txt" 2>/dev/null
    echo "  ✅ git-history.txt ($(wc -l < "$RESCUE_DIR/git-history.txt") commit)"
    
    # إنشاء bundle
    git bundle create "$RESCUE_DIR/git-backup.bundle" --all 2>/dev/null
    if [ -f "$RESCUE_DIR/git-backup.bundle" ]; then
        echo "  ✅ git-backup.bundle ($(du -h "$RESCUE_DIR/git-backup.bundle" | cut -f1))"
    fi
else
    echo "  ⚠️  ليس مستودع Git"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📊 3. حفظ الإحصائيات"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# إحصائيات TypeScript
TS_ERRORS=$(npx tsc --noEmit 2>&1 | grep -c "error TS" 2>/dev/null || echo "N/A")
echo "  TypeScript Errors: $TS_ERRORS" > "$RESCUE_DIR/stats.txt"

# حالة الخادم
if curl -s --max-time 2 http://localhost:3000 > /dev/null 2>&1; then
    echo "  Server: Running" >> "$RESCUE_DIR/stats.txt"
else
    echo "  Server: Not Running" >> "$RESCUE_DIR/stats.txt"
fi

# عدد الملفات
FILES=$(find src -type f -name "*.ts" -o -name "*.tsx" 2>/dev/null | wc -l)
echo "  TypeScript Files: $FILES" >> "$RESCUE_DIR/stats.txt"

echo "  ✅ stats.txt"

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   💾 4. إنشاء أرشيف"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# إنشاء tar.gz
ARCHIVE_FILE="/tmp/context-rescue-${TIMESTAMP}.tar.gz"
tar -czvf "$ARCHIVE_FILE" -C "$(dirname $RESCUE_DIR)" "$(basename $RESCUE_DIR)" 2>/dev/null
ARCHIVE_SIZE=$(du -h "$ARCHIVE_FILE" | cut -f1)

# إضافة للسجل
echo "$ARCHIVE_FILE" >> /tmp/context-rescue-list.txt

echo "  ✅ $ARCHIVE_FILE ($ARCHIVE_SIZE)"

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📝 5. تحديث RESCUE.md"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# إضافة معلومات الإنقاذ لـ RESCUE.md
cat >> RESCUE.md << EOF

---

## 📦 آخر إنقاذ: $TIMESTAMP

| البند | القيمة |
|-------|--------|
| TypeScript Errors | $TS_ERRORS |
| Server | $(curl -s --max-time 2 http://localhost:3000 > /dev/null 2>&1 && echo "Running" || echo "Not Running") |
| Files | $FILES |
| Archive | $ARCHIVE_FILE |

EOF

echo "  ✅ تم تحديث RESCUE.md"

# ═══════════════════════════════════════════════════════════════
# النتيجة النهائية
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم إنقاذ السياق بنجاح!"
echo ""
echo "📦 أرشيف الإنقاذ:"
echo "   $ARCHIVE_FILE"
echo ""
echo "📁 محتويات الإنقاذ:"
ls -la "$RESCUE_DIR"
echo ""
echo "📋 سجل الإنقاذات:"
cat /tmp/context-rescue-list.txt 2>/dev/null | tail -5
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "⚠️  في الجلسة القادمة: اقرأ RESCUE.md أولاً!"
echo "═══════════════════════════════════════════════════════════════"
```

---

# ═══════════════════════════════════════════════════════════════
#                    📦 فئة: Git
# ═══════════════════════════════════════════════════════════════

---

## 7️⃣ git-save.sh - حفظ Git History

**الاستخدام:** `bash .context/git-save.sh`

**الوظيفة:**
- يصدر تاريخ Git بصيغ متعددة
- ينشئ Git Bundle (نسخة كاملة)
- يحفظ معلومات المستودع

```bash
#!/bin/bash

# 📦 سكربت حفظ Git History
# الاستخدام: bash .context/git-save.sh

echo "═══════════════════════════════════════════════════════════════"
echo "                    📦 حفظ Git History"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# التحقق من وجود Git
if [ ! -d ".git" ]; then
    echo "❌ هذا ليس مستودع Git!"
    exit 1
fi

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
COMMITS=$(git log --oneline 2>/dev/null | wc -l | tr -d ' ')

echo "📊 عدد الـ Commits: $COMMITS"
echo ""

# 1. تصدير التاريخ المختصر
echo "📝 تصدير التاريخ المختصر..."
git log --pretty=format:"%h|%ad|%an|%s" --date=short > .context/git-history.txt 2>/dev/null
echo "  ✅ .context/git-history.txt ($(wc -l < .context/git-history.txt) سطر)"

# 2. تصدير التاريخ الكامل مع الإحصائيات
echo ""
echo "📝 تصدير التاريخ الكامل..."
git log --stat > .context/git-history-full.txt 2>/dev/null
echo "  ✅ .context/git-history-full.txt ($(wc -l < .context/git-history-full.txt) سطر)"

# 3. إنشاء JSON للقراءة السهلة
echo ""
echo "📝 إنشاء JSON..."
echo "[" > .context/git-history.json
git log --pretty=format:'  {"hash":"%h","date":"%ad","author":"%an","message":"%s"},' --date=short 2>/dev/null | sed '$ s/,$//' >> .context/git-history.json
echo "" >> .context/git-history.json
echo "]" >> .context/git-history.json
echo "  ✅ .context/git-history.json"

# 4. إنشاء Git Bundle (نسخة كاملة)
echo ""
echo "📦 إنشاء Git Bundle..."
BUNDLE_FILE="/tmp/git-backup-${TIMESTAMP}.bundle"
git bundle create "$BUNDLE_FILE" --all 2>/dev/null
if [ -f "$BUNDLE_FILE" ]; then
    BUNDLE_SIZE=$(du -h "$BUNDLE_FILE" | cut -f1)
    echo "  ✅ $BUNDLE_FILE ($BUNDLE_SIZE)"
    echo "$BUNDLE_FILE" >> /tmp/git-backups-list.txt
else
    echo "  ⚠️  تعذر إنشاء Bundle"
fi

# 5. حفظ معلومات إضافية
echo ""
echo "📝 حفظ معلومات إضافية..."
{
    echo "# Git Repository Info"
    echo "Timestamp: $TIMESTAMP"
    echo "Commits: $COMMITS"
    echo "Branch: $(git branch --show-current 2>/dev/null || echo 'unknown')"
    echo "Remote: $(git remote -v 2>/dev/null | head -1 || echo 'none')"
    echo ""
    echo "# Last 10 Commits"
    git log --oneline -10 2>/dev/null
} > .context/git-info.txt
echo "  ✅ .context/git-info.txt"

# 6. حفظ حالة الملفات المتغيرة
echo ""
echo "📝 حفظ حالة الملفات..."
git status --short > .context/git-status.txt 2>/dev/null
echo "  ✅ .context/git-status.txt ($(wc -l < .context/git-status.txt) ملف متغير)"

# النتيجة النهائية
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم حفظ Git History بنجاح!"
echo ""
echo "📁 الملفات المُنشأة:"
echo "   .context/git-history.txt      - التاريخ المختصر"
echo "   .context/git-history-full.txt - التاريخ الكامل"
echo "   .context/git-history.json     - نسخة JSON"
echo "   .context/git-info.txt         - معلومات المستودع"
echo "   .context/git-status.txt       - حالة الملفات"
if [ -f "$BUNDLE_FILE" ]; then
    echo "   $BUNDLE_FILE - نسخة كاملة"
fi
echo "═══════════════════════════════════════════════════════════════"
```

---

## 8️⃣ git-restore.sh - استعادة Git History

**الاستخدام:** `bash .context/git-restore.sh [bundle-file]`

**الوظيفة:**
- يستعيد Git History من Bundle
- ينشئ مستودع جديد مع التاريخ

```bash
#!/bin/bash

# 🔄 سكربت استعادة Git History
# الاستخدام: bash .context/git-restore.sh [bundle-file]

BUNDLE_FILE=$1

echo "═══════════════════════════════════════════════════════════════"
echo "                    🔄 استعادة Git History"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# إذا لم يُحدد ملف، اعرض القائمة
if [ -z "$BUNDLE_FILE" ]; then
    echo "📋 Bundles المتاحة:"
    echo ""
    
    if [ -f /tmp/git-backups-list.txt ]; then
        cat -n /tmp/git-backups-list.txt
        echo ""
        echo "Usage: bash .context/git-restore.sh [number-or-path]"
    else
        echo "❌ لا يوجد سجل bundles"
        echo ""
        echo "💡 البحث عن bundles..."
        find /tmp -name "git-backup-*.bundle" 2>/dev/null
    fi
    exit 0
fi

# إذا كان رقماً، استخدم الملف من القائمة
if [[ "$BUNDLE_FILE" =~ ^[0-9]+$ ]]; then
    BUNDLE_FILE=$(sed -n "${BUNDLE_FILE}p" /tmp/git-backups-list.txt)
fi

# التحقق من وجود الملف
if [ ! -f "$BUNDLE_FILE" ]; then
    echo "❌ الملف غير موجود: $BUNDLE_FILE"
    exit 1
fi

echo "📦 الملف: $BUNDLE_FILE"
echo ""

# التحقق من صحة الـ bundle
echo "🔍 التحقق من صحة الـ bundle..."
if git bundle verify "$BUNDLE_FILE" 2>/dev/null; then
    echo "  ✅ الـ bundle صالح"
else
    echo "  ⚠️  تحذير: قد يكون الـ bundle غير مكتمل"
fi

echo ""
echo "⚠️  تحذير: هذا سينشئ مجلد جديد مع الـ git history"
read -p "هل تريد المتابعة؟ (y/n): " CONFIRM

if [ "$CONFIRM" != "y" ]; then
    echo "❌ تم الإلغاء"
    exit 0
fi

# إنشاء مجلد الاستعادة
RESTORE_DIR="restored-git-$(date +%Y%m%d-%H%M%S)"
echo ""
echo "📁 إنشاء مجلد: $RESTORE_DIR"

# استخراج من الـ bundle
git clone "$BUNDLE_FILE" "$RESTORE_DIR" 2>&1

if [ -d "$RESTORE_DIR/.git" ]; then
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "✅ تمت الاستعادة بنجاح!"
    echo ""
    echo "📁 المجلد: $RESTORE_DIR"
    echo ""
    cd "$RESTORE_DIR"
    echo "📊 معلومات المستودع:"
    echo "   Commits: $(git log --oneline | wc -l)"
    echo "   Branch: $(git branch --show-current)"
    echo ""
    echo "💡 لاستبدال المشروع الحالي:"
    echo "   1. انسخ الملفات من $RESTORE_DIR"
    echo "   2. أو اعمل في المجلد الجديد"
    echo "═══════════════════════════════════════════════════════════════"
else
    echo "❌ فشلت الاستعادة"
    exit 1
fi
```

---

# ═══════════════════════════════════════════════════════════════
#                    🔍 فئة: الفحص
# ═══════════════════════════════════════════════════════════════

---

## 9️⃣ check.sh - فحص شامل للمشروع

**الاستخدام:** `bash .context/check.sh [--quick | --full]`

**الوظيفة:**
- يفحص Build & Compilation
- يفحص Runtime & Server
- يفحص API Routes
- يفحص Prisma & Database
- يفحص التبعيات
- يفحص هيكل الملفات

```bash
#!/bin/bash

# 🔍 سكربت الفحص الشامل التلقائي
# الاستخدام: bash .context/check.sh [--quick | --full]

MODE=${1:---quick}

echo "═══════════════════════════════════════════════════════════════"
echo "                    🔍 الفحص الشامل للمشروع"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 التاريخ: $(date '+%Y-%m-%d %H:%M:%S')"
echo "🔧 الوضع: $MODE"
echo ""

# متغيرات للنتائج
TOTAL_CHECKS=0
PASSED=0
FAILED=0
WARNINGS=0
ISSUES=""

# دالة لتسجيل النتائج
check_pass() {
    PASSED=$((PASSED + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo "  ✅ $1"
}

check_fail() {
    FAILED=$((FAILED + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo "  ❌ $1"
    ISSUES="$ISSUES\n- $1: $2"
}

check_warn() {
    WARNINGS=$((WARNINGS + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo "  ⚠️  $1"
    ISSUES="$ISSUES\n- $1 (تحذير): $2"
}

# ═══════════════════════════════════════════════════════════════
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣  البناء والتجميع"
echo "───────────────────────────────────────────────────────────────"

# فحص ESLint
echo ""
echo "📌 ESLint..."
if bun run lint 2>&1 | grep -q "error"; then
    check_fail "ESLint" "أخطاء في الكود"
else
    check_pass "ESlint نظيف"
fi

# فحص TypeScript
echo ""
echo "📌 TypeScript Errors..."
TS_ERRORS=$(npx tsc --noEmit 2>&1 | grep -c "error TS" 2>/dev/null || echo "0")
if [ "$TS_ERRORS" -gt 0 ]; then
    check_warn "TypeScript" "$TS_ERRORS خطأ"
else
    check_pass "TypeScript بدون أخطاء"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   4️⃣  Runtime & Server"
echo "───────────────────────────────────────────────────────────────"

# فحص الخادم
echo ""
echo "📌 الخادم (localhost:3000)..."
if curl -s --max-time 5 http://localhost:3000 > /dev/null 2>&1; then
    check_pass "الخادم يعمل"
else
    check_fail "الخادم" "لا يستجيب"
fi

# فحص الصفحة الرئيسية
echo ""
echo "📌 الصفحة الرئيسية..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null)
if [ "$HTTP_CODE" = "200" ]; then
    check_pass "الصفحة الرئيسية (200 OK)"
else
    check_fail "الصفحة الرئيسية" "HTTP $HTTP_CODE"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   5️⃣  API Routes"
echo "───────────────────────────────────────────────────────────────"

# فحص API listings
echo ""
echo "📌 /api/listings..."
API_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/listings 2>/dev/null)
if [ "$API_CODE" = "200" ]; then
    check_pass "API /listings (200 OK)"
else
    check_fail "API /listings" "HTTP $API_CODE"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   6️⃣  قاعدة البيانات & Prisma"
echo "───────────────────────────────────────────────────────────────"

# فحص Prisma Schema
echo ""
echo "📌 Prisma Schema..."
if [ -f "prisma/schema.prisma" ]; then
    check_pass "schema.prisma موجود"
else
    check_fail "Prisma Schema" "الملف غير موجود"
fi

# فحص قاعدة البيانات
echo ""
echo "📌 قاعدة البيانات..."
if [ -f "prisma/dev.db" ]; then
    check_pass "قاعدة البيانات موجودة"
else
    check_warn "قاعدة البيانات" "قد تحتاج bun run db:push"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   7️⃣  التبعيات"
echo "───────────────────────────────────────────────────────────────"

# فحص node_modules
echo ""
echo "📌 node_modules..."
if [ -d "node_modules" ]; then
    check_pass "node_modules موجود"
else
    check_fail "node_modules" "run bun install"
fi

# فحص package.json
echo ""
echo "📌 package.json..."
if [ -f "package.json" ]; then
    check_pass "package.json موجود"
else
    check_fail "package.json" "الملف غير موجود"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣2️⃣  هيكل الملفات"
echo "───────────────────────────────────────────────────────────────"

# فحص هيكل المجلدات
echo ""
echo "📌 المجلدات الرئيسية..."

[ -d "src" ] && check_pass "src/ موجود" || check_fail "src/" "غير موجود"
[ -d "src/app" ] && check_pass "src/app/ موجود" || check_fail "src/app/" "غير موجود"
[ -d "src/core" ] && check_pass "src/core/ موجود" || check_fail "src/core/" "غير موجود"
[ -d "src/application" ] && check_pass "src/application/ موجود" || check_warn "src/application/" "قد لا يكون ضرورياً"
[ -d "src/infrastructure" ] && check_pass "src/infrastructure/ موجود" || check_warn "src/infrastructure/" "قد لا يكون ضرورياً"

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣4️⃣  Environment Variables"
echo "───────────────────────────────────────────────────────────────"

# فحص .env
echo ""
echo "📌 Environment Files..."
if [ -f ".env" ] || [ -f ".env.local" ]; then
    check_pass "ملف .env موجود"
else
    check_warn ".env" "قد تحتاج لإنشائه"
fi

if [ -f ".env.example" ]; then
    check_pass ".env.example موجود"
else
    check_warn ".env.example" "يُنصح بإنشائه"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "───────────────────────────────────────────────────────────────"
echo "                   1️⃣5️⃣  التوثيق"
echo "───────────────────────────────────────────────────────────────"

# فحص ملفات السياق
echo ""
echo "📌 ملفات السياق..."
if [ -d ".context" ]; then
    check_pass ".context/ موجود"
    [ -f ".context/STATUS.md" ] && check_pass "STATUS.md موجود" || check_warn "STATUS.md" "غير موجود"
    [ -f ".context/TODO.md" ] && check_pass "TODO.md موجود" || check_warn "TODO.md" "غير موجود"
else
    check_warn ".context/" "يُنصح بإنشائه لحفظ السياق"
fi

# فحص Spec
echo ""
echo "📌 Spec Files..."
if [ -d ".spec" ]; then
    check_pass ".spec/ موجود"
else
    check_warn ".spec/" "يُنصح بإنشائه"
fi

# ═══════════════════════════════════════════════════════════════
# الفحص الكامل (إذا طُلب)
if [ "$MODE" = "--full" ]; then
    echo ""
    echo "───────────────────────────────────────────────────────────────"
    echo "                   🔍 فحص إضافي (Full Mode)"
    echo "───────────────────────────────────────────────────────────────"
    
    # فحص Build
    echo ""
    echo "📌 Next.js Build..."
    if bun run build 2>&1 | grep -q "Failed to compile"; then
        check_fail "Build" "فشل التجميع"
    else
        check_pass "Build يعمل"
    fi
    
    # فحص حجم node_modules
    echo ""
    echo "📌 حجم node_modules..."
    SIZE=$(du -sh node_modules 2>/dev/null | cut -f1)
    echo "  ℹ️  الحجم: $SIZE"
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
fi

# ═══════════════════════════════════════════════════════════════
# النتائج النهائية
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "                        📊 النتائج النهائية"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  إجمالي الفحوصات: $TOTAL_CHECKS"
echo "  ✅ ناجحة: $PASSED"
echo "  ❌ فاشلة: $FAILED"
echo "  ⚠️  تحذيرات: $WARNINGS"
echo ""

if [ $FAILED -gt 0 ]; then
    echo "───────────────────────────────────────────────────────────────"
    echo "                   🔴 المشاكل المكتشفة:"
    echo "───────────────────────────────────────────────────────────────"
    echo -e "$ISSUES"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════"

# كود الخروج
if [ $FAILED -gt 0 ]; then
    exit 1
else
    exit 0
fi
```

---

# ═══════════════════════════════════════════════════════════════
#                    📝 فئة: التوثيق
# ═══════════════════════════════════════════════════════════════

---

## 🔟 worklog-add.sh - إضافة لسجل العمل

**الاستخدام:** `bash .context/worklog-add.sh "العنوان" "المحتوى"`

**الوظيفة:**
- يضيف قسم جديد لـ worklog.md
- يحافظ على قاعدة append-only

```bash
#!/bin/bash

# 📝 سكربت الإضافة لـ worklog.md
# الاستخدام: bash .context/worklog-add.sh "العنوان" "المحتوى"

TITLE=${1:-"تحديث"}
CONTENT=${2:-"لا يوجد محتوى"}
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
WORKLOG_FILE="/home/z/my-project/worklog.md"

echo "═══════════════════════════════════════════════════════════════"
echo "                    📝 إضافة لـ worklog.md"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# التحقق من وجود الملف
if [ ! -f "$WORKLOG_FILE" ]; then
    echo "📄 إنشاء ملف worklog.md جديد..."
    cat > "$WORKLOG_FILE" << 'HEADER'
# 📜 سجل العمل (WORKLOG)

## ⚠️ قواعد مهمة

> **هذا الملف للإضافة فقط (append-only)**
> - لا تحذف المحتوى السابق أبداً
> - أضف دائماً في الأسفل
> - استخدم: `bash .context/worklog-add.sh "عنوان" "محتوى"`

---

HEADER
fi

# عدد الأسطر قبل الإضافة
LINES_BEFORE=$(wc -l < "$WORKLOG_FILE")

# إضافة المحتوى الجديد
echo "📝 إضافة قسم جديد..."
echo "   العنوان: $TITLE"
echo "   الوقت: $TIMESTAMP"
echo ""

cat >> "$WORKLOG_FILE" << ENTRY

---
## [$TIMESTAMP] $TITLE

$CONTENT

---
ENTRY

# عدد الأسطر بعد الإضافة
LINES_AFTER=$(wc -l < "$WORKLOG_FILE")
LINES_ADDED=$((LINES_AFTER - LINES_BEFORE))

echo "═══════════════════════════════════════════════════════════════"
echo "✅ تمت الإضافة بنجاح!"
echo ""
echo "📊 الإحصائيات:"
echo "   الأسطر قبل: $LINES_BEFORE"
echo "   الأسطر بعد: $LINES_AFTER"
echo "   الأسطر المضافة: $LINES_ADDED"
echo ""
echo "📄 الملف: $WORKLOG_FILE"
echo "═══════════════════════════════════════════════════════════════"

# عرض آخر 5 أسطر
echo ""
echo "📋 آخر 5 أسطر:"
echo "───────────────────────────────────────"
tail -5 "$WORKLOG_FILE"
echo "───────────────────────────────────────"
```

---

# 📊 ملخص الاستخدام

## 🚀 بداية الجلسة:
```bash
bash .context/init-session.sh
```

## 📝 بعد كل إنجاز:
```bash
bash .context/log-achievement.sh "إنجاز" "ملفات"
```

## 🔖 عند Milestone:
```bash
bash .context/checkpoint.sh "اسم-checkpoint"
```

## 🆘 قبل انتهاء الجلسة:
```bash
bash .context/rescue.sh
```

## 🔍 للفحص:
```bash
bash .context/check.sh --quick
bash .context/check.sh --full
```

## 💾 للنسخ الاحتياطي:
```bash
bash .context/backup.sh
bash .context/restore.sh
```

## 📦 لـ Git:
```bash
bash .context/git-save.sh
bash .context/git-restore.sh
```

---

*تم إنشاء هذا الملف: 2025-03-19*
