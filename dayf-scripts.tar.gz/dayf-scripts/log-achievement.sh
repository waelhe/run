#!/bin/bash

# 📝 تسجيل إنجاز - يُنفذ بعد كل إنجاز صغير
# الاستخدام: bash .context/log-achievement.sh "وصف الإنجاز" "ملف1,ملف2"

ACHIEVEMENT=${1:-"تحديث"}
FILES=${2:-"غير محدد"}
TIMESTAMP=$(date '+%H:%M')
DATE=$(date '+%Y-%m-%d')
WORKLOG="/home/z/my-project/worklog.md"
SESSION_STATE="/home/z/my-project/.context/SESSION-STATE.md"

echo "═══════════════════════════════════════════════════════════════"
echo "                    📝 تسجيل إنجاز"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "⏰ الوقت: $TIMESTAMP"
echo "📋 الإنجاز: $ACHIEVEMENT"
echo "📁 الملفات: $FILES"
echo ""

# 1. إضافة لـ worklog.md (append فقط!)
echo "📝 إضافة لـ worklog.md..."
cat >> "$WORKLOG" << EOF

### [$TIMESTAMP] $ACHIEVEMENT
- الملفات المعدلة: $FILES
- النتيجة: ✅ تم

EOF
echo "  ✅ تمت الإضافة"

# 2. تحديث SESSION-STATE.md
echo ""
echo "📝 تحديث SESSION-STATE.md..."

# تحديث LAST_UPDATE
sed -i "s/LAST_UPDATE.*/LAST_UPDATE | $DATE $TIMESTAMP |/" "$SESSION_STATE" 2>/dev/null

# إضافة الإنجاز
cat >> "$SESSION_STATE" << EOF

### [$TIMESTAMP] $ACHIEVEMENT
- الملفات: $FILES

EOF
echo "  ✅ تم التحديث"

# 3. Git commit
echo ""
echo "📦 Git commit..."
cd /home/z/my-project

# التحقق من وجود Git
if [ -d ".git" ]; then
    # إضافة كل التغييرات
    git add -A 2>/dev/null
    
    # commit
    git commit -m "[$TIMESTAMP] $ACHIEVEMENT" --allow-empty 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo "  ✅ تم الـ commit"
    else
        echo "  ⚠️  لا توجد تغييرات جديدة"
    fi
else
    echo "  ⚠️  ليس مستودع Git - جاري التهيئة..."
    git init 2>/dev/null
    git add -A 2>/dev/null
    git commit -m "[$TIMESTAMP] $ACHIEVEMENT" --allow-empty 2>/dev/null
    echo "  ✅ تم تهيئة Git وعمل commit"
fi

# 4. حفظ معلومات الجلسة
echo ""
echo "💾 حفظ معلومات الجلسة..."
echo "LAST_ACHIEVEMENT=$ACHIEVEMENT" > /tmp/last-session-info.txt
echo "LAST_TIME=$TIMESTAMP" >> /tmp/last-session-info.txt
echo "LAST_FILES=$FILES" >> /tmp/last-session-info.txt
echo "WORKLOG_LINES=$(wc -l < "$WORKLOG")" >> /tmp/last-session-info.txt
echo "  ✅ تم الحفظ في /tmp/last-session-info.txt"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم تسجيل الإنجاز بنجاح!"
echo ""
echo "📊 الإحصائيات:"
echo "   worklog.md: $(wc -l < "$WORKLOG") سطر"
echo "   Git commits: $(git log --oneline 2>/dev/null | wc -l)"
echo "═══════════════════════════════════════════════════════════════"
