#!/bin/bash

# 💾 سكربت حفظ السياق السريع
# الاستخدام: bash .context/backup.sh

echo "═══════════════════════════════════════════════════════════"
echo "           💾 حفظ السياق والملفات المهمة"
echo "═══════════════════════════════════════════════════════════"

BACKUP_DIR="/tmp/dayf-backup-$(date +%Y%m%d-%H%M%S)"
BACKUP_FILE="${BACKUP_DIR}.tar.gz"

echo ""
echo "📁 إنشاء مجلد النسخة الاحتياطية..."
mkdir -p "$BACKUP_DIR"

# نسخ الملفات المهمة
echo "📋 نسخ الملفات المهمة..."

# السياق (الأهم!)
cp -r /home/z/my-project/.context "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ .context/"

# Spec
cp -r /home/z/my-project/.spec "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ .spec/"

# الكود المصدري
cp -r /home/z/my-project/src "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ src/"

# Prisma
cp -r /home/z/my-project/prisma "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ prisma/"

# ملفات الإعداد
cp /home/z/my-project/package.json "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ package.json"
cp /home/z/my-project/tsconfig.json "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ tsconfig.json"
cp /home/z/my-project/next.config.ts "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ next.config.ts"
cp /home/z/my-project/tailwind.config.ts "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ tailwind.config.ts"
cp /home/z/my-project/components.json "$BACKUP_DIR/" 2>/dev/null && echo "  ✅ components.json"

# أرشفة
echo ""
echo "📦 إنشاء ملف الأرشفة..."
tar -czvf "$BACKUP_FILE" -C "$(dirname $BACKUP_DIR)" "$(basename $BACKUP_DIR)" 2>/dev/null

# تنظيف المجلد المؤقت
rm -rf "$BACKUP_DIR"

# عرض النتيجة
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ تم إنشاء النسخة الاحتياطية:"
echo "   📄 $BACKUP_FILE"
echo ""
BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
echo "   📊 الحجم: $BACKUP_SIZE"
echo "═══════════════════════════════════════════════════════════"

# إضافة موقع النسخة إلى ملف
echo "$BACKUP_FILE" >> /tmp/dayf-backups-list.txt
echo "📝 تم إضافة النسخة للسجل: /tmp/dayf-backups-list.txt"
