#!/bin/bash

# 📝 سكربت الإضافة لـ worklog.md
# الاستخدام: bash .context/worklog-add.sh "العنوان" "المحتوى"

TITLE=${1:-"تحديث"}
CONTENT=${2:-"لا يوجد محتوى"}
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
WORKLOG_FILE="/home/z/my-project/worklog.md"

echo "═══════════════════════════════════════════════════════════════"
echo "                    📝 إضافة لـ worklog.md"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# التحقق من وجود الملف
if [ ! -f "$WORKLOG_FILE" ]; then
    echo "📄 إنشاء ملف worklog.md جديد..."
    cat > "$WORKLOG_FILE" << 'HEADER'
# 📜 سجل العمل (WORKLOG)

## ⚠️ قواعد مهمة

> **هذا الملف للإضافة فقط (append-only)**
> - لا تحذف المحتوى السابق أبداً
> - أضف دائماً في الأسفل
> - استخدم: `bash .context/worklog-add.sh "عنوان" "محتوى"`

---

HEADER
fi

# عدد الأسطر قبل الإضافة
LINES_BEFORE=$(wc -l < "$WORKLOG_FILE")

# إضافة المحتوى الجديد
echo "📝 إضافة قسم جديد..."
echo "   العنوان: $TITLE"
echo "   الوقت: $TIMESTAMP"
echo ""

cat >> "$WORKLOG_FILE" << ENTRY

---
## [$TIMESTAMP] $TITLE

$CONTENT

---
ENTRY

# عدد الأسطر بعد الإضافة
LINES_AFTER=$(wc -l < "$WORKLOG_FILE")
LINES_ADDED=$((LINES_AFTER - LINES_BEFORE))

echo "═══════════════════════════════════════════════════════════════"
echo "✅ تمت الإضافة بنجاح!"
echo ""
echo "📊 الإحصائيات:"
echo "   الأسطر قبل: $LINES_BEFORE"
echo "   الأسطر بعد: $LINES_AFTER"
echo "   الأسطر المضافة: $LINES_ADDED"
echo ""
echo "📄 الملف: $WORKLOG_FILE"
echo "═══════════════════════════════════════════════════════════════"

# عرض آخر 5 أسطر
echo ""
echo "📋 آخر 5 أسطر:"
echo "───────────────────────────────────────"
tail -5 "$WORKLOG_FILE"
echo "───────────────────────────────────────"
