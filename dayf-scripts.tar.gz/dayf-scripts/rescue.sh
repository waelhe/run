#!/bin/bash

# 🚨 سكربت إنقاذ السياق - نفذ قبل انتهاء الجلسة!
# الاستخدام: bash .context/rescue.sh

echo "═══════════════════════════════════════════════════════════════"
echo "              🚨 إنقاذ السياق قبل انتهاء الجلسة"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 التاريخ: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
RESCUE_DIR="/tmp/context-rescue-${TIMESTAMP}"

# إنشاء مجلد الإنقاذ
mkdir -p "$RESCUE_DIR"
echo "📁 مجلد الإنقاذ: $RESCUE_DIR"
echo ""

# ═══════════════════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📋 1. حفظ ملفات السياق"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# نسخ ملفات السياق
if [ -d ".context" ]; then
    cp -r .context "$RESCUE_DIR/"
    echo "  ✅ .context/ ($(ls .context | wc -l) ملف)"
else
    echo "  ⚠️  .context/ غير موجود"
fi

# نسخ worklog
if [ -f "worklog.md" ]; then
    cp worklog.md "$RESCUE_DIR/"
    echo "  ✅ worklog.md ($(wc -l < worklog.md) سطر)"
else
    echo "  ⚠️  worklog.md غير موجود"
fi

# نسخ RESCUE.md
if [ -f "RESCUE.md" ]; then
    cp RESCUE.md "$RESCUE_DIR/"
    echo "  ✅ RESCUE.md"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📦 2. حفظ Git History"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -d ".git" ]; then
    # تصدير التاريخ
    git log --pretty=format:"%h|%ad|%an|%s" --date=short > "$RESCUE_DIR/git-history.txt" 2>/dev/null
    echo "  ✅ git-history.txt ($(wc -l < "$RESCUE_DIR/git-history.txt") commit)"
    
    # إنشاء bundle
    git bundle create "$RESCUE_DIR/git-backup.bundle" --all 2>/dev/null
    if [ -f "$RESCUE_DIR/git-backup.bundle" ]; then
        echo "  ✅ git-backup.bundle ($(du -h "$RESCUE_DIR/git-backup.bundle" | cut -f1))"
    fi
else
    echo "  ⚠️  ليس مستودع Git"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📊 3. حفظ الإحصائيات"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# إحصائيات TypeScript
TS_ERRORS=$(npx tsc --noEmit 2>&1 | grep -c "error TS" 2>/dev/null || echo "N/A")
echo "  TypeScript Errors: $TS_ERRORS" > "$RESCUE_DIR/stats.txt"

# حالة الخادم
if curl -s --max-time 2 http://localhost:3000 > /dev/null 2>&1; then
    echo "  Server: Running" >> "$RESCUE_DIR/stats.txt"
else
    echo "  Server: Not Running" >> "$RESCUE_DIR/stats.txt"
fi

# عدد الملفات
FILES=$(find src -type f -name "*.ts" -o -name "*.tsx" 2>/dev/null | wc -l)
echo "  TypeScript Files: $FILES" >> "$RESCUE_DIR/stats.txt"

echo "  ✅ stats.txt"

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   💾 4. إنشاء أرشيف"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# إنشاء tar.gz
ARCHIVE_FILE="/tmp/context-rescue-${TIMESTAMP}.tar.gz"
tar -czvf "$ARCHIVE_FILE" -C "$(dirname $RESCUE_DIR)" "$(basename $RESCUE_DIR)" 2>/dev/null
ARCHIVE_SIZE=$(du -h "$ARCHIVE_FILE" | cut -f1)

# إضافة للسجل
echo "$ARCHIVE_FILE" >> /tmp/context-rescue-list.txt

echo "  ✅ $ARCHIVE_FILE ($ARCHIVE_SIZE)"

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📝 5. تحديث RESCUE.md"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# إضافة معلومات الإنقاذ لـ RESCUE.md
cat >> RESCUE.md << EOF

---

## 📦 آخر إنقاذ: $TIMESTAMP

| البند | القيمة |
|-------|--------|
| TypeScript Errors | $TS_ERRORS |
| Server | $(curl -s --max-time 2 http://localhost:3000 > /dev/null 2>&1 && echo "Running" || echo "Not Running") |
| Files | $FILES |
| Archive | $ARCHIVE_FILE |

EOF

echo "  ✅ تم تحديث RESCUE.md"

# ═══════════════════════════════════════════════════════════════
# النتيجة النهائية
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم إنقاذ السياق بنجاح!"
echo ""
echo "📦 أرشيف الإنقاذ:"
echo "   $ARCHIVE_FILE"
echo ""
echo "📁 محتويات الإنقاذ:"
ls -la "$RESCUE_DIR"
echo ""
echo "📋 سجل الإنقاذات:"
cat /tmp/context-rescue-list.txt 2>/dev/null | tail -5
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "⚠️  في الجلسة القادمة: اقرأ RESCUE.md أولاً!"
echo "═══════════════════════════════════════════════════════════════"
