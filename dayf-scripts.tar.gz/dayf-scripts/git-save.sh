#!/bin/bash

# 📦 سكربت حفظ Git History
# الاستخدام: bash .context/git-save.sh

echo "═══════════════════════════════════════════════════════════════"
echo "                    📦 حفظ Git History"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# التحقق من وجود Git
if [ ! -d ".git" ]; then
    echo "❌ هذا ليس مستودع Git!"
    exit 1
fi

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
COMMITS=$(git log --oneline 2>/dev/null | wc -l | tr -d ' ')

echo "📊 عدد الـ Commits: $COMMITS"
echo ""

# 1. تصدير التاريخ المختصر
echo "📝 تصدير التاريخ المختصر..."
git log --pretty=format:"%h|%ad|%an|%s" --date=short > .context/git-history.txt 2>/dev/null
echo "  ✅ .context/git-history.txt ($(wc -l < .context/git-history.txt) سطر)"

# 2. تصدير التاريخ الكامل مع الإحصائيات
echo ""
echo "📝 تصدير التاريخ الكامل..."
git log --stat > .context/git-history-full.txt 2>/dev/null
echo "  ✅ .context/git-history-full.txt ($(wc -l < .context/git-history-full.txt) سطر)"

# 3. إنشاء JSON للقراءة السهلة
echo ""
echo "📝 إنشاء JSON..."
echo "[" > .context/git-history.json
git log --pretty=format:'  {"hash":"%h","date":"%ad","author":"%an","message":"%s"},' --date=short 2>/dev/null | sed '$ s/,$//' >> .context/git-history.json
echo "" >> .context/git-history.json
echo "]" >> .context/git-history.json
echo "  ✅ .context/git-history.json"

# 4. إنشاء Git Bundle (نسخة كاملة)
echo ""
echo "📦 إنشاء Git Bundle..."
BUNDLE_FILE="/tmp/git-backup-${TIMESTAMP}.bundle"
git bundle create "$BUNDLE_FILE" --all 2>/dev/null
if [ -f "$BUNDLE_FILE" ]; then
    BUNDLE_SIZE=$(du -h "$BUNDLE_FILE" | cut -f1)
    echo "  ✅ $BUNDLE_FILE ($BUNDLE_SIZE)"
    echo "$BUNDLE_FILE" >> /tmp/git-backups-list.txt
else
    echo "  ⚠️  تعذر إنشاء Bundle"
fi

# 5. حفظ معلومات إضافية
echo ""
echo "📝 حفظ معلومات إضافية..."
{
    echo "# Git Repository Info"
    echo "Timestamp: $TIMESTAMP"
    echo "Commits: $COMMITS"
    echo "Branch: $(git branch --show-current 2>/dev/null || echo 'unknown')"
    echo "Remote: $(git remote -v 2>/dev/null | head -1 || echo 'none')"
    echo ""
    echo "# Last 10 Commits"
    git log --oneline -10 2>/dev/null
} > .context/git-info.txt
echo "  ✅ .context/git-info.txt"

# 6. حفظ حالة الملفات المتغيرة
echo ""
echo "📝 حفظ حالة الملفات..."
git status --short > .context/git-status.txt 2>/dev/null
echo "  ✅ .context/git-status.txt ($(wc -l < .context/git-status.txt) ملف متغير)"

# النتيجة النهائية
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم حفظ Git History بنجاح!"
echo ""
echo "📁 الملفات المُنشأة:"
echo "   .context/git-history.txt      - التاريخ المختصر"
echo "   .context/git-history-full.txt - التاريخ الكامل"
echo "   .context/git-history.json     - نسخة JSON"
echo "   .context/git-info.txt         - معلومات المستودع"
echo "   .context/git-status.txt       - حالة الملفات"
if [ -f "$BUNDLE_FILE" ]; then
    echo "   $BUNDLE_FILE - نسخة كاملة"
fi
echo "═══════════════════════════════════════════════════════════════"
