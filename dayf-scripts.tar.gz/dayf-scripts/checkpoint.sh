#!/bin/bash

# 🔖 إنشاء Checkpoint - يُنفذ عند إنجاز milestone
# الاستخدام: bash .context/checkpoint.sh "وصف الـ checkpoint"

CHECKPOINT_NAME=${1:-"checkpoint-$(date +%H%M)"}
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
CHECKPOINT_ID=$(date +%Y%m%d-%H%M%S)

echo "═══════════════════════════════════════════════════════════════"
echo "                    🔖 إنشاء Checkpoint"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 الوقت: $TIMESTAMP"
echo "🔖 الاسم: $CHECKPOINT_NAME"
echo "🆔 ID: $CHECKPOINT_ID"
echo ""

# 1. جمع الإحصائيات
echo "📊 جمع الإحصائيات..."
TS_ERRORS=$(npx tsc --noEmit 2>&1 | grep -c "error TS" 2>/dev/null || echo "N/A")
COMMITS=$(git log --oneline 2>/dev/null | wc -l | tr -d ' ')
WORKLOG_LINES=$(wc -l < /home/z/my-project/worklog.md 2>/dev/null || echo "0")
FILES_MODIFIED=$(find /home/z/my-project/src -name "*.ts" -newer /tmp/last-checkpoint 2>/dev/null | wc -l | tr -d ' ')

echo "   TypeScript Errors: $TS_ERRORS"
echo "   Git Commits: $COMMITS"
echo "   Worklog Lines: $WORKLOG_LINES"
echo "   Files Modified: $FILES_MODIFIED"

# 2. إضافة لـ worklog.md
echo ""
echo "📝 إضافة لـ worklog.md..."
cat >> /home/z/my-project/worklog.md << EOF

---

## 🔖 Checkpoint: $CHECKPOINT_NAME
**الوقت:** $TIMESTAMP
**ID:** $CHECKPOINT_ID

### 📊 الإحصائيات:
| البند | القيمة |
|-------|--------|
| TypeScript Errors | $TS_ERRORS |
| Git Commits | $COMMITS |
| Worklog Lines | $WORKLOG_LINES |

### 📁 الملفات المعدلة منذ آخر checkpoint:
$FILES_MODIFIED ملفات

---

EOF
echo "  ✅ تمت الإضافة"

# 3. تحديث CHECKPOINTS.md
echo ""
echo "📝 تحديث CHECKPOINTS.md..."
cat >> /home/z/my-project/.context/CHECKPOINTS.md << EOF

### Checkpoint: $CHECKPOINT_NAME
**التاريخ:** $TIMESTAMP
**ID:** $CHECKPOINT_ID

#### 📊 الإحصائيات:
| البند | القيمة |
|-------|--------|
| TypeScript Errors | $TS_ERRORS |
| Git Commits | $COMMITS |
| Worklog Lines | $WORKLOG_LINES |

#### 📁 الملفات المعدلة:
$FILES_MODIFIED ملفات

EOF
echo "  ✅ تم التحديث"

# 4. Git commit مع tag
echo ""
echo "📦 Git commit مع tag..."
cd /home/z/my-project

git add -A 2>/dev/null
git commit -m "🔖 CHECKPOINT: $CHECKPOINT_NAME" --allow-empty 2>/dev/null
git tag "checkpoint-$CHECKPOINT_ID" 2>/dev/null

echo "  ✅ تم الـ commit والـ tag"

# 5. إنشاء أرشيف checkpoint
echo ""
echo "📦 إنشاء أرشيف..."
CHECKPOINT_DIR="/tmp/checkpoint-$CHECKPOINT_ID"
mkdir -p "$CHECKPOINT_DIR"

# نسخ الملفات المهمة
cp -r .context "$CHECKPOINT_DIR/" 2>/dev/null
cp worklog.md "$CHECKPOINT_DIR/" 2>/dev/null
cp RESCUE.md "$CHECKPOINT_DIR/" 2>/dev/null
git log --oneline > "$CHECKPOINT_DIR/git-log.txt" 2>/dev/null

# إنشاء tar.gz
tar -czvf "/tmp/checkpoint-$CHECKPOINT_ID.tar.gz" -C /tmp "checkpoint-$CHECKPOINT_ID" 2>/dev/null
rm -rf "$CHECKPOINT_DIR"

CHECKPOINT_SIZE=$(du -h "/tmp/checkpoint-$CHECKPOINT_ID.tar.gz" | cut -f1)
echo "  ✅ /tmp/checkpoint-$CHECKPOINT_ID.tar.gz ($CHECKPOINT_SIZE)"

# تحديث ملف آخر checkpoint
touch /tmp/last-checkpoint
echo "$CHECKPOINT_ID" > /tmp/last-checkpoint-id.txt

# 6. تحديث last-session-info.txt
echo ""
echo "💾 تحديث معلومات الجلسة..."
cat > /tmp/last-session-info.txt << EOF
LAST_CHECKPOINT=$CHECKPOINT_ID
CHECKPOINT_NAME=$CHECKPOINT_NAME
CHECKPOINT_TIME=$TIMESTAMP
TS_ERRORS=$TS_ERRORS
COMMITS=$COMMITS
WORKLOG_LINES=$WORKLOG_LINES
EOF
echo "  ✅ تم التحديث"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تم إنشاء Checkpoint بنجاح!"
echo ""
echo "📦 الأرشيف: /tmp/checkpoint-$CHECKPOINT_ID.tar.gz"
echo "🏷️  Tag: checkpoint-$CHECKPOINT_ID"
echo ""
echo "📋 للاستعادة:"
echo "   git checkout checkpoint-$CHECKPOINT_ID"
echo "   أو"
echo "   tar -xzvf /tmp/checkpoint-$CHECKPOINT_ID.tar.gz"
echo "═══════════════════════════════════════════════════════════════"
