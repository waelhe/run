#!/bin/bash

# 🚀 تهيئة جلسة جديدة - يُنفذ في بداية كل جلسة
# الاستخدام: bash .context/init-session.sh

SESSION_ID=$(date +%Y%m%d-%H%M%S)
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

echo "═══════════════════════════════════════════════════════════════"
echo "                    🚀 تهيئة جلسة جديدة"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📅 الوقت: $TIMESTAMP"
echo "🆔 SESSION_ID: $SESSION_ID"
echo ""

# 1. البحث عن جلسة سابقة
echo "🔍 البحث عن جلسة سابقة..."
echo ""

if [ -f "/tmp/last-session-info.txt" ]; then
    echo "📄 وجدت معلومات آخر جلسة:"
    echo "───────────────────────────────────────"
    cat /tmp/last-session-info.txt
    echo "───────────────────────────────────────"
    echo ""
else
    echo "⚠️  لم أجد معلومات جلسة سابقة"
    echo ""
fi

# 2. فحص وجود worklog.md
echo "📝 فحص worklog.md..."
if [ -f "/home/z/my-project/worklog.md" ]; then
    LINES=$(wc -l < /home/z/my-project/worklog.md)
    echo "  ✅ موجود ($LINES سطر)"
    
    # عرض آخر 10 أسطر
    echo ""
    echo "📋 آخر 10 أسطر:"
    echo "───────────────────────────────────────"
    tail -10 /home/z/my-project/worklog.md
    echo "───────────────────────────────────────"
else
    echo "  ⚠️  غير موجود - سيُنشأ"
    
    # إنشاء worklog.md جديد
    cat > /home/z/my-project/worklog.md << 'EOF'
# 📜 سجل العمل (WORKLOG)

## ⚠️ قواعد مهمة

> **هذا الملف للإضافة فقط (append-only)**
> - لا تحذف المحتوى السابق أبداً
> - أضف دائماً في الأسفل
> - استخدم: `cat >> worklog.md << 'EOF' ... EOF`
> - أو: `bash .context/log-achievement.sh "إنجاز" "ملفات"`

---

EOF
    echo "  ✅ تم إنشاء worklog.md جديد"
fi
echo ""

# 3. فحص .context/
echo "📁 فحص .context/..."
if [ -d "/home/z/my-project/.context" ]; then
    FILES=$(ls /home/z/my-project/.context | wc -l)
    echo "  ✅ موجود ($FILES ملف)"
    
    # فحص الملفات المهمة
    echo ""
    echo "📋 فحص الملفات المهمة:"
    [ -f "/home/z/my-project/.context/STATUS.md" ] && echo "  ✅ STATUS.md" || echo "  ❌ STATUS.md مفقود"
    [ -f "/home/z/my-project/.context/TODO.md" ] && echo "  ✅ TODO.md" || echo "  ❌ TODO.md مفقود"
    [ -f "/home/z/my-project/.context/SESSION-STATE.md" ] && echo "  ✅ SESSION-STATE.md" || echo "  ⚠️  SESSION-STATE.md مفقود"
else
    echo "  ❌ .context/ غير موجود!"
    echo "  💡 يجب إنشاؤه أولاً"
fi
echo ""

# 4. فحص Git
echo "📦 فحص Git..."
if [ -d "/home/z/my-project/.git" ]; then
    COMMITS=$(git log --oneline 2>/dev/null | wc -l | tr -d ' ')
    echo "  ✅ موجود ($COMMITS commits)"
    
    # عرض آخر 5 commits
    echo ""
    echo "📋 آخر 5 commits:"
    echo "───────────────────────────────────────"
    git log --oneline -5 2>/dev/null || echo "  (لا يوجد commits)"
    echo "───────────────────────────────────────"
else
    echo "  ⚠️  ليس مستودع Git - جاري التهيئة..."
    git init
    echo "  ✅ تم تهيئة Git"
fi
echo ""

# 5. فحص RESCUE.md
echo "🚨 فحص RESCUE.md..."
if [ -f "/home/z/my-project/RESCUE.md" ]; then
    echo "  ✅ موجود"
else
    echo "  ⚠️  غير موجود - سيُنشأ"
    cat > /home/z/my-project/RESCUE.md << 'EOF'
# 🚨 RESCUE.md - ابدأ من هنا!

## ⚠️ تحذير هام!

> **إذا كنت تقرأ هذا الملف، فأنت في جلسة جديدة!**
> **لا تبدأ أي عمل قبل قراءة السياق!**

---

## 📋 الخطوة 1: اقرأ السياق فوراً!

```
1. .context/STATUS.md      ← الحالة الحالية
2. .context/TODO.md        ← المهام المعلقة
3. .context/SESSION-STATE.md ← حالة الجلسة
4. worklog.md              ← سجل العمل
```

---

## 📋 الخطوة 2: فحص آخر جلسة

```bash
cat /tmp/last-session-info.txt
```

---

## 📋 الخطوة 3: أكمل من حيث توقفت

```
لا تبدأ من الصفر!
استخدم المعلومات من ملفات السياق
```

---

EOF
    echo "  ✅ تم إنشاء RESCUE.md"
fi
echo ""

# 6. إنشاء معرف الجلسة
echo "🆔 تسجيل معرف الجلسة..."
export SESSION_ID="$SESSION_ID"
echo "SESSION_ID=$SESSION_ID" > /tmp/current-session.txt
echo "START_TIME=$TIMESTAMP" >> /tmp/current-session.txt
echo "  ✅ SESSION_ID: $SESSION_ID"
echo ""

# 7. إضافة بداية الجلسة لـ worklog
echo "📝 إضافة بداية الجلسة لـ worklog..."
cat >> /home/z/my-project/worklog.md << EOF

---

## 🚀 جلسة جديدة: $SESSION_ID
**الوقت:** $TIMESTAMP

### بداية الجلسة:
- تم قراءة السياق
- تم التحقق من الملفات
- الجاهزية: ✅

EOF
echo "  ✅ تمت الإضافة"
echo ""

# 8. Git commit لبداية الجلسة
echo "📦 Git commit لبداية الجلسة..."
git add -A 2>/dev/null
git commit -m "🚀 بدء جلسة $SESSION_ID" --allow-empty 2>/dev/null
echo "  ✅ تم الـ commit"
echo ""

# النتيجة النهائية
echo "═══════════════════════════════════════════════════════════════"
echo "✅ تمت تهيئة الجلسة بنجاح!"
echo ""
echo "📋 ما يجب فعله الآن:"
echo "   1. اقرأ .context/STATUS.md"
echo "   2. اقرأ .context/TODO.md"
echo "   3. حدد المهمة التالية"
echo "   4. ابدأ العمل!"
echo ""
echo "📝 بعد كل إنجاز:"
echo "   bash .context/log-achievement.sh \"الإنجاز\" \"الملفات\""
echo ""
echo "🔖 عند إنجاز milestone:"
echo "   bash .context/checkpoint.sh \"اسم الـ checkpoint\""
echo ""
echo "═══════════════════════════════════════════════════════════════"
