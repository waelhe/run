import fs from 'fs';
import path from 'path';

function fixLinks(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      fixLinks(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      
      if (content.includes('next/link')) {
        // Replace to="..." with href="..."
        content = content.replace(/\bto=(['"{])/g, 'href=$1');
        fs.writeFileSync(fullPath, content);
      }
    }
  }
}

fixLinks('src');
console.log('Fixed Links in src');
