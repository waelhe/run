"use client";
import { usePathname, useSearchParams } from 'next/navigation';
export function useLocation() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  return {
    pathname,
    search: searchParams ? '?' + searchParams.toString() : '',
    hash: '',
    state: null,
    key: 'default'
  };
}
