"use client";
import { useRouter } from 'next/navigation';
export function useNavigate() {
  const router = useRouter();
  return (path: string, options?: any) => {
    if (path === -1) {
      router.back();
    } else {
      router.push(path);
    }
  };
}
