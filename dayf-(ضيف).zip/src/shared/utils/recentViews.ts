/**
 * Utility to manage recently viewed services in local storage
 */

const RECENTLY_VIEWED_KEY = 'recently_viewed_services';
const MAX_RECENT_ITEMS = 10;

export interface RecentService {
  id: string;
  title: string;
  image: string;
  price: number;
  location: string;
  rating: number;
  timestamp: number;
}

export const addRecentlyViewed = (service: RecentService) => {
  try {
    const existing = getRecentlyViewed();
    const filtered = existing.filter(item => item.id !== service.id);
    const updated = [service, ...filtered].slice(0, MAX_RECENT_ITEMS);
    localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Error adding to recently viewed:', error);
  }
};

export const getRecentlyViewed = (): RecentService[] => {
  try {
    const data = localStorage.getItem(RECENTLY_VIEWED_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting recently viewed:', error);
    return [];
  }
};

export const clearRecentlyViewed = () => {
  localStorage.removeItem(RECENTLY_VIEWED_KEY);
};
