"use client";
import React, { useState, useEffect } from 'react';
import { Search, Globe, User, Menu, LogIn, LogOut, ShoppingCart } from 'lucide-react';
import { motion, useScroll } from 'motion/react';
import { useLocation } from '../../../useLocation';

import Link from 'next/link';

import { useLanguage } from '../../../core/contexts/LanguageContext';
import { useScrollDirection } from '../../hooks/useScrollDirection';
import { useAuth } from '../../../core/contexts/AuthContext';
import { useCart } from '../../../features/marketplace/contexts/CartContext';

export default function Header() {
  const { scrollY } = useScroll();
  const [isExpanded, setIsExpanded] = useState(true);
  const { scrollDirection, isScrolled } = useScrollDirection();
  const location = useLocation();
  const { t, language, setLanguage } = useLanguage();
  const { user, signInWithGoogle, logout } = useAuth();
  const { cartCount, setIsCartOpen } = useCart();
  const isHome = location.pathname === '/';

  const isMinimized = scrollDirection === 'down' && isScrolled;

  useEffect(() => {
    return scrollY.on('change', (latest) => {
      setIsExpanded(latest <= 0);
    });
  }, [scrollY]);

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleLogin = async () => {
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    try {
      await signInWithGoogle();
    } finally {
      setIsLoggingIn(false);
    }
  };

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const headerHeight = isHome && isExpanded ? '80px' : '64px';

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 ${
        isHome && !isScrolled 
          ? 'bg-white/50 backdrop-blur-sm border-transparent' 
          : 'bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm'
      }`}
      style={{ 
        height: headerHeight,
        transform: isMinimized ? 'translateY(-100%)' : 'translateY(0)',
        transition: 'transform 0.2s ease-in-out, background-color 0.2s, height 0.2s'
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
        {/* Logo */}
        <Link 
          href="/" 
          className="flex items-center gap-2 group"
        >
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-900/20 group-hover:scale-110 transition-transform">
            <span className="text-white font-black text-lg">S</span>
          </div>
          <span className="text-xl font-black text-gray-900 tracking-tight hidden sm:block">
            SYRIA<span className="text-emerald-600">GUIDE</span>
          </span>
        </Link>
        
        {/* Search Bar */}
        <div
          className={`hidden md:flex items-center gap-0 bg-white border border-gray-200 rounded-full shadow-sm cursor-pointer hover:shadow-md transition-all duration-300 overflow-hidden`}
        >
          <button className={`px-5 font-semibold hover:bg-gray-50 transition-all duration-300 py-2.5 text-sm`}>
            {t('header.anywhere')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className={`px-5 font-semibold hover:bg-gray-50 transition-all duration-300 py-2.5 text-sm`}>
            {t('header.any_week')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className={`px-5 font-medium text-gray-500 hover:bg-gray-50 transition-all duration-300 flex items-center gap-2 py-2.5 text-sm`}>
            {t('header.add_guests')}
            <div className={`bg-emerald-600 text-white rounded-full transition-all duration-300 overflow-hidden flex items-center justify-center p-1.5 w-7 h-7 opacity-100`}>
              <Search className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>

        {/* Mobile Search Trigger */}
        <div className={`md:hidden flex-1 mx-4 transition-all duration-300 max-w-[200px]`}>
          <div className={`flex items-center gap-2 bg-white border border-gray-200 rounded-full shadow-sm transition-all duration-300 px-3 py-2`}>
            <div className={`transition-all duration-300 overflow-hidden flex items-center justify-center w-4 opacity-100`}>
              <Search className="w-4 h-4 text-emerald-600" />
            </div>
            <span className={`font-medium text-gray-500 truncate transition-all duration-300 text-xs`}>{t('hero.placeholder')}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 sm:gap-4">
          <Link 
            href="/provider-dashboard" 
            className={`hidden sm:block text-sm font-semibold px-3 py-2 rounded-full hover:bg-black/5 transition-colors text-gray-700`}
          >
            {t('header.host')}
          </Link>
          
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 rounded-full hover:bg-black/5 transition-colors text-gray-700"
            title={language === 'ar' ? 'السلة' : 'Cart'}
          >
            <ShoppingCart className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 bg-emerald-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          <button 
            onClick={toggleLanguage}
            className={`p-2 rounded-full hover:bg-black/5 transition-colors text-gray-700`}
            title={language === 'ar' ? 'English' : 'العربية'}
          >
            <Globe className="w-5 h-5" />
          </button>

          <div className="relative" ref={menuRef}>
            <button 
              onClick={toggleMenu}
              className={`flex items-center gap-2 border border-gray-200 rounded-full p-1.5 hover:shadow-md transition-all cursor-pointer bg-white text-gray-700`}
            >
              <Menu className="w-4 h-4" />
              <div className="w-7 h-7 rounded-full bg-gray-500 flex items-center justify-center overflow-hidden">
                {user?.photoURL ? (
                  <img src={user.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <User className="w-4 h-4 text-white" />
                )}
              </div>
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <div className={`absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-[60] ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                {!user ? (
                  <>
                    <button 
                      onClick={() => { handleLogin(); setIsMenuOpen(false); }}
                      className="w-full px-4 py-3 text-sm font-semibold hover:bg-gray-50 flex items-center gap-3"
                    >
                      <LogIn className="w-4 h-4" />
                      {language === 'ar' ? 'تسجيل الدخول' : 'Login'}
                    </button>
                    <div className="h-[1px] bg-gray-100 my-1" />
                  </>
                ) : (
                  <>
                    <div className="px-4 py-3 border-b border-gray-100">
                      <p className="text-sm font-bold text-gray-900 truncate">{user.displayName || user.email}</p>
                      <p className="text-xs text-gray-500 truncate">{user.email}</p>
                    </div>
                    <Link href="/profile" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50">{language === 'ar' ? 'الملف الشخصي' : 'Profile'}</Link>
                    <Link href="/provider-dashboard" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50 font-bold text-emerald-600">{language === 'ar' ? 'لوحة تحكم المزود' : 'Provider Dashboard'}</Link>
                    <Link href="/my-bookings" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50">{language === 'ar' ? 'حجوزاتي' : 'My Bookings'}</Link>
                    <Link href="/orders" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50">{language === 'ar' ? 'طلباتي' : 'My Orders'}</Link>
                    <div className="h-[1px] bg-gray-100 my-1" />
                  </>
                )}
                
                <Link href="/marketplace" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50 font-medium">{language === 'ar' ? 'السوق المحلي' : 'Local Marketplace'}</Link>
                <Link href="/community" onClick={() => setIsMenuOpen(false)} className="block px-4 py-3 text-sm hover:bg-gray-50 font-medium">{language === 'ar' ? 'المجتمع' : 'Community'}</Link>
                
                {user && (
                  <>
                    <div className="h-[1px] bg-gray-100 my-1" />
                    <button 
                      onClick={() => { logout(); setIsMenuOpen(false); }}
                      className="w-full px-4 py-3 text-sm text-red-600 hover:bg-red-50 flex items-center gap-3"
                    >
                      <LogOut className="w-4 h-4" />
                      {language === 'ar' ? 'تسجيل الخروج' : 'Logout'}
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
