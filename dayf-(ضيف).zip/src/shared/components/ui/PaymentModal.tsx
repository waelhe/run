"use client";
import React from 'react';
import { X, ShieldCheck, CreditCard } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  serviceId?: string;
  amount: number;
  onSuccess?: () => void;
  title?: string;
}

export default function PaymentModal({ isOpen, onClose, serviceId, amount, onSuccess, title }: PaymentModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl overflow-hidden"
          >
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>

            <div className="flex flex-col items-center text-center mb-8">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <CreditCard className="w-8 h-8 text-emerald-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">تأكيد الدفع</h2>
              <p className="text-gray-500">
                {title || 'يرجى تأكيد تفاصيل الدفع لإتمام الحجز'}
              </p>
            </div>

            <div className="bg-gray-50 rounded-2xl p-6 mb-8">
              <div className="flex justify-between items-center mb-4">
                <span className="text-gray-600">المبلغ الإجمالي</span>
                <span className="text-2xl font-bold text-gray-900">${amount}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-emerald-600 font-medium">
                <ShieldCheck className="w-4 h-4" />
                <span>دفع آمن ومحمي عبر ضيف</span>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <button 
                onClick={() => {
                  onSuccess?.();
                  onClose();
                }} 
                className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200"
              >
                ادفع الآن
              </button>
              <button 
                onClick={onClose} 
                className="w-full py-4 text-gray-500 font-bold hover:bg-gray-50 rounded-2xl transition-colors"
              >
                إلغاء
              </button>
            </div>

            <p className="mt-6 text-center text-xs text-gray-400">
              بالضغط على "ادفع الآن"، فإنك توافق على شروط الخدمة وسياسة الخصوصية الخاصة بضيف.
            </p>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
