"use client";
import React, { useEffect, useState } from 'react';
import { useNavigate } from '../../../useNavigate';


import { motion } from 'framer-motion';
import { Star, MapPin, Clock } from 'lucide-react';
import { getRecentlyViewed, RecentService } from '../../utils/recentViews';
import { useLanguage } from '../../../core/contexts/LanguageContext';

export default function RecentlyViewed() {
  const [recentItems, setRecentItems] = useState<RecentService[]>([]);
  const { language } = useLanguage();
  const navigate = useNavigate();

  useEffect(() => {
    setRecentItems(getRecentlyViewed());
  }, []);

  if (recentItems.length === 0) return null;

  return (
    <section className="py-12 bg-gray-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {language === 'ar' ? 'شاهدتها مؤخراً' : 'Recently Viewed'}
            </h2>
            <p className="text-gray-500 text-sm mt-1">
              {language === 'ar' ? 'تابع من حيث توقفت' : 'Continue where you left off'}
            </p>
          </div>
        </div>

        <div className="flex gap-6 overflow-x-auto pb-6 hide-scrollbar snap-x">
          {recentItems.map((item) => (
            <motion.div
              key={item.id}
              whileHover={{ y: -4 }}
              onClick={() => navigate(`/listing/${item.id}`)}
              className="min-w-[280px] md:min-w-[320px] bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer snap-start"
            >
              <div className="relative h-40">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-2 py-1 rounded-lg text-xs font-bold text-gray-900 shadow-sm">
                  ${item.price}
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-900 mb-1 line-clamp-1">{item.title}</h3>
                <div className="flex items-center gap-1 text-gray-500 text-xs mb-3">
                  <MapPin className="w-3 h-3" />
                  <span>{item.location}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-emerald-500 fill-emerald-500" />
                    <span className="text-xs font-bold text-gray-900">{item.rating}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-400 text-[10px]">
                    <Clock className="w-3 h-3" />
                    <span>
                      {new Date(item.timestamp).toLocaleDateString(language === 'ar' ? 'ar-SY' : 'en-US', {
                        month: 'short',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
