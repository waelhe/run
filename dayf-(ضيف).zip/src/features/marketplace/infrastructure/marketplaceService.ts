import { collection, getDocs, query, orderBy, addDoc, doc, getDoc } from 'firebase/firestore';
import { db } from '../../../firebase';
import { Product } from '../types';

const PRODUCTS_COLLECTION = 'products';

export const marketplaceService = {
  async getProducts(): Promise<Product[]> {
    try {
      const q = query(collection(db, PRODUCTS_COLLECTION));
      const snapshot = await getDocs(q);
      console.log('Products fetched (no order):', snapshot.size);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
    } catch (error) {
      console.error('Error in getProducts:', error);
      throw error;
    }
  },
  async getProductById(id: string): Promise<Product | null> {
    try {
      const docRef = doc(db, PRODUCTS_COLLECTION, id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Product;
      }
      return null;
    } catch (error) {
      console.error('Error in getProductById:', error);
      throw error;
    }
  },
  async getProductsByVendor(vendorName: string): Promise<Product[]> {
    try {
      const q = query(collection(db, PRODUCTS_COLLECTION));
      const snapshot = await getDocs(q);
      const allProducts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
      return allProducts.filter(p => p.vendor === vendorName);
    } catch (error) {
      console.error('Error in getProductsByVendor:', error);
      throw error;
    }
  },
  async seedProducts(products: Omit<Product, 'id'>[]) {
    const colRef = collection(db, PRODUCTS_COLLECTION);
    for (const product of products) {
      await addDoc(colRef, product);
    }
  }
};
