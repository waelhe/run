"use client";
import React, { useState, useEffect } from 'react';
import { ShoppingBag, MapPin, Star, Filter, Search, ShoppingCart, X, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';

import { useLanguage } from '../../../core/contexts/LanguageContext';
import { useAuth } from '../../../core/contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import toast from 'react-hot-toast';
import { marketplaceService } from '../infrastructure/marketplaceService';
import { Product } from '../types';
import { ListingSkeleton } from '../../../shared/components/ui/Skeleton';

const CATEGORIES = [
  { id: 'all', name: 'الكل' },
  { id: 'sweets', name: 'حلويات شامية' },
  { id: 'soap', name: 'صابون غار' },
  { id: 'spices', name: 'بهارات وتوابل' },
  { id: 'crafts', name: 'صناعات يدوية' },
  { id: 'textiles', name: 'أقمشة ومطرزات' },
];

const VENDORS = [
  { id: 'v1', name: 'حلويات الشام', image: 'https://picsum.photos/seed/vendor1/200/200', location: 'دمشق', rating: 4.9, category: 'حلويات' },
  { id: 'v2', name: 'حرفيو حلب', image: 'https://picsum.photos/seed/vendor2/200/200', location: 'حلب', rating: 4.8, category: 'صناعات يدوية' },
  { id: 'v3', name: 'عطار دمشق', image: 'https://picsum.photos/seed/vendor3/200/200', location: 'دمشق', rating: 4.7, category: 'توابل' },
  { id: 'v4', name: 'منسوجات حلب', image: 'https://picsum.photos/seed/vendor4/200/200', location: 'حلب', rating: 4.9, category: 'أقمشة' },
  { id: 'v5', name: 'تراث الشام', image: 'https://picsum.photos/seed/vendor5/200/200', location: 'دمشق', rating: 4.8, category: 'تحف' },
];

export default function MarketplacePage() {
  const { t } = useLanguage();
  const { user, userProfile } = useAuth();
  const { cartItems, isCartOpen, setIsCartOpen, addToCart, removeFromCart, updateQuantity, clearCart, cartTotal, cartCount } = useCart();
  const userId = user?.uid;
  const isAdmin = user?.email === 'wael.he88@gmail.com' || userProfile?.role === 'admin';
  
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [priceRange, setPriceRange] = useState({ min: 0, max: 1000000 });
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await marketplaceService.getProducts();
        setProducts(data);
        // Set initial max price
        const maxP = Math.max(...data.map(p => p.price), 1000000);
        setPriceRange(prev => ({ ...prev, max: maxP }));
      } catch (error) {
        console.error('Error fetching products:', error);
        toast.error('حدث خطأ أثناء تحميل المنتجات');
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const filteredProducts = products.filter(product => {
    const matchesCategory = activeCategory === 'all' || product.category === activeCategory;
    const matchesSearch = product.name.includes(searchQuery) || product.description.includes(searchQuery) || product.location.includes(searchQuery);
    const matchesPrice = product.price >= priceRange.min && product.price <= priceRange.max;
    return matchesCategory && matchesSearch && matchesPrice;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0; // default newest
  });

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    toast.success('تمت الإضافة إلى السلة');
  };

  const cartItemCount = cartCount;

  const handleSeedProducts = async () => {
    if (!userId) {
      toast.error('يرجى تسجيل الدخول أولاً');
      return;
    }

    if (!isAdmin) {
      toast.error('عذراً، يجب أن تكون مسؤولاً (Admin) لإضافة المنتجات');
      console.log('User is not admin:', user?.email, userProfile?.role);
      return;
    }

    console.log('Admin seeding products...', user?.email);
    const productsToSeed: Omit<Product, 'id'>[] = [
      { name: 'بقلاوة بالفستق', description: 'بقلاوة مقرمشة محشوة بفستق حلبي فاخر.', price: 35000, category: 'sweets', location: 'دمشق', rating: 4.9, reviews: 200, image: 'https://picsum.photos/seed/baklava/800/600', vendor: 'حلويات الشام', createdAt: new Date() },
      { name: 'معمول بالتمر', description: 'معمول هش محشو بتمر طازج.', price: 15000, category: 'sweets', location: 'حلب', rating: 4.7, reviews: 150, image: 'https://picsum.photos/seed/maamoul/800/600', vendor: 'حرفيو حلب', createdAt: new Date() },
      { name: 'راحة حلقوم', description: 'راحة حلقوم بنكهة الورد والمستكة.', price: 8000, category: 'sweets', location: 'دمشق', rating: 4.6, reviews: 90, image: 'https://picsum.photos/seed/lokum/800/600', vendor: 'حلويات الشام', createdAt: new Date() },
      { name: 'صابون غار طبيعي', description: 'صابون غار تقليدي للبشرة الحساسة.', price: 4000, category: 'soap', location: 'حلب', rating: 4.8, reviews: 300, image: 'https://picsum.photos/seed/soap1/800/600', vendor: 'حرفيو حلب', createdAt: new Date() },
      { name: 'صابون باللافندر', description: 'صابون غار معطر برائحة اللافندر المهدئة.', price: 6000, category: 'soap', location: 'حلب', rating: 4.7, reviews: 110, image: 'https://picsum.photos/seed/soap2/800/600', vendor: 'حرفيو حلب', createdAt: new Date() },
      { name: 'بهارات مشكلة', description: 'خلطة بهارات سورية أصلية لكل أنواع الطبخ.', price: 12000, category: 'spices', location: 'دمشق', rating: 4.9, reviews: 400, image: 'https://picsum.photos/seed/spices1/800/600', vendor: 'عطار دمشق', createdAt: new Date() },
      { name: 'سماق بلدي', description: 'سماق أحمر حامض طبيعي.', price: 7000, category: 'spices', location: 'اللاذقية', rating: 4.5, reviews: 80, image: 'https://picsum.photos/seed/spices2/800/600', vendor: 'عطار دمشق', createdAt: new Date() },
      { name: 'صحن نحاس منقوش', description: 'صحن نحاس مشغول يدوياً بزخارف دمشقية.', price: 50000, category: 'crafts', location: 'دمشق', rating: 5.0, reviews: 50, image: 'https://picsum.photos/seed/craft1/800/600', vendor: 'حرفيو دمشق', createdAt: new Date() },
      { name: 'علبة خشب مطعمة بالصدف', description: 'علبة مجوهرات خشبية مطعمة بالصدف الطبيعي.', price: 30000, category: 'crafts', location: 'دمشق', rating: 4.8, reviews: 70, image: 'https://picsum.photos/seed/craft2/800/600', vendor: 'حرفيو دمشق', createdAt: new Date() },
      { name: 'شال حرير مطرز', description: 'شال حرير طبيعي مطرز يدوياً.', price: 45000, category: 'textiles', location: 'حلب', rating: 4.7, reviews: 60, image: 'https://picsum.photos/seed/textile1/800/600', vendor: 'منسوجات حلب', createdAt: new Date() },
      { name: 'مفرش طاولة مطرز', description: 'مفرش طاولة من الكتان مطرز بغرز يدوية.', price: 20000, category: 'textiles', location: 'حلب', rating: 4.6, reviews: 40, image: 'https://picsum.photos/seed/textile2/800/600', vendor: 'منسوجات حلب', createdAt: new Date() },
      { name: 'زعتر حلبي', description: 'زعتر حلبي أصلي مع سمسم وزيت زيتون.', price: 9000, category: 'spices', location: 'حلب', rating: 4.9, reviews: 250, image: 'https://picsum.photos/seed/zaatar/800/600', vendor: 'عطار حلب', createdAt: new Date() },
      { name: 'دبس رمان', description: 'دبس رمان طبيعي 100%.', price: 11000, category: 'spices', location: 'اللاذقية', rating: 4.8, reviews: 180, image: 'https://picsum.photos/seed/pomegranate/800/600', vendor: 'عطار دمشق', createdAt: new Date() },
      { name: 'مربى المشمش', description: 'مربى مشمش طازج.', price: 7500, category: 'sweets', location: 'دمشق', rating: 4.7, reviews: 130, image: 'https://picsum.photos/seed/apricot/800/600', vendor: 'حلويات الشام', createdAt: new Date() },
      { name: 'صابون زيت زيتون', description: 'صابون زيت زيتون نقي.', price: 3500, category: 'soap', location: 'حلب', rating: 4.6, reviews: 95, image: 'https://picsum.photos/seed/olive-soap/800/600', vendor: 'حرفيو حلب', createdAt: new Date() },
      { name: 'طقم فناجين قهوة دمشقي', description: 'طقم فناجين قهوة مزخرف يدوياً بنقوش دمشقية أصيلة.', price: 45000, category: 'crafts', location: 'دمشق', rating: 4.9, reviews: 30, image: 'https://picsum.photos/seed/coffee-set/800/600', vendor: 'تراث الشام', createdAt: new Date() },
      { name: 'زيت زيتون عفريني (1 لتر)', description: 'زيت زيتون بكر ممتاز من منطقة عفرين.', price: 25000, category: 'spices', location: 'حلب', rating: 5.0, reviews: 45, image: 'https://picsum.photos/seed/olive-oil/800/600', vendor: 'خيرات الشمال', createdAt: new Date() },
    ];
    try {
      await marketplaceService.seedProducts(productsToSeed);
      toast.success('تمت إضافة المنتجات بنجاح');
      window.location.reload(); // Reload to fetch new products
    } catch (error) {
      console.error('Error seeding products:', error);
      if (error instanceof Error) {
        toast.error(`حدث خطأ أثناء إضافة المنتجات: ${error.message}`);
      } else {
        toast.error('حدث خطأ غير معروف أثناء إضافة المنتجات');
      }
    }
  };


  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      {/* Seed Button (Hidden/Admin only - for now just add it) */}
      <button 
        onClick={handleSeedProducts} 
        className="fixed bottom-10 right-10 bg-red-600 text-white p-4 rounded-full text-sm font-bold z-[9999] shadow-2xl hover:bg-red-700 transition-all flex items-center gap-2"
      >
        <Plus className="w-4 h-4" />
        تحديث وإضافة المنتجات (v2)
      </button>
      {/* Hero Section */}
      <div className="relative bg-emerald-950 text-white py-16 mb-4 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/syria-souq/1600/800" 
            alt="Souq Background" 
            className="w-full h-full object-cover opacity-10"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-emerald-950 via-transparent to-transparent" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="max-w-2xl text-center md:text-right">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-400/10 text-emerald-400 text-sm font-bold mb-6 border border-emerald-400/20"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>سوق ضيف المحلي</span>
              </motion.div>
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-4xl md:text-6xl font-bold mb-6 leading-tight"
              >
                اكتشف <span className="text-emerald-400">كنوز</span> سوريا المحلية
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-gray-300 text-lg md:text-xl leading-relaxed mb-8"
              >
                من الحلويات الشامية الأصيلة إلى الصناعات اليدوية العريقة، تصلك أينما كنت لدعم الحرفيين المحليين.
              </motion.p>
            </div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
              className="bg-white/5 p-8 rounded-[2.5rem] backdrop-blur-xl border border-white/10 flex flex-col items-center gap-6 cursor-pointer hover:bg-white/10 transition-all shadow-2xl group"
              onClick={() => setIsCartOpen(true)}
            >
              <div className="relative">
                <div className="bg-emerald-500 w-20 h-20 rounded-3xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <ShoppingCart className="w-10 h-10 text-white" />
                </div>
                {cartItemCount > 0 && (
                  <div className="absolute -top-3 -right-3 bg-rose-500 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shadow-xl border-4 border-emerald-900">
                    {cartItemCount}
                  </div>
                )}
              </div>
              <div className="text-center">
                <span className="block text-sm font-bold text-emerald-400 uppercase tracking-widest mb-2">سلة المشتريات</span>
                <span className="block text-3xl font-black">{cartTotal.toLocaleString('ar-SA')} <span className="text-sm font-normal text-gray-400">ل.س</span></span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="products-grid">
        
        {/* Featured Vendors */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">أبرز البائعين المحليين</h2>
            <button className="text-emerald-600 font-bold text-sm hover:underline">عرض الكل</button>
          </div>
          <div className="flex overflow-x-auto pb-4 gap-6 no-scrollbar">
            {VENDORS.map(vendor => (
              <motion.div 
                key={vendor.id}
                whileHover={{ y: -5 }}
                className="flex-shrink-0 w-48 bg-white p-4 rounded-2xl border border-gray-100 shadow-sm text-center group cursor-pointer"
              >
                <div className="relative w-24 h-24 mx-auto mb-4">
                  <img 
                    src={vendor.image} 
                    alt={vendor.name} 
                    className="w-full h-full rounded-full object-cover border-4 border-emerald-50 group-hover:border-emerald-200 transition-colors"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-amber-400 text-white p-1 rounded-full shadow-sm">
                    <Star className="w-3 h-3 fill-white" />
                  </div>
                </div>
                <h3 className="font-bold text-gray-900 mb-1">{vendor.name}</h3>
                <p className="text-xs text-emerald-600 font-medium mb-2">{vendor.category}</p>
                <div className="flex items-center justify-center gap-1 text-xs text-gray-500">
                  <MapPin className="w-3 h-3" />
                  <span>{vendor.location}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Featured Products Section */}
        {activeCategory === 'all' && searchQuery === '' && products.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
                منتجات مميزة
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {products.slice(0, 3).map(product => (
                <motion.div 
                  key={`featured-${product.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-emerald-100 group"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={product.image || (product.images && product.images[0])} 
                      alt={product.name} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-emerald-700 shadow-sm">
                      {CATEGORIES.find(c => c.id === product.category)?.name}
                    </div>
                    <div className="absolute top-4 left-4 bg-amber-400 text-white px-2 py-1 rounded-lg text-xs font-bold shadow-sm flex items-center gap-1">
                      <Star className="w-3 h-3 fill-white" />
                      مميز
                    </div>
                  </div>
                  <div className="p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-lg font-bold text-gray-900 line-clamp-1">{product.name}</h3>
                      <div className="flex items-center gap-1 bg-gray-50 px-2 py-1 rounded-lg">
                        <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                        <span className="text-sm font-bold">{product.rating}</span>
                      </div>
                    </div>
                    <p className="text-gray-500 text-sm mb-4 line-clamp-2">{product.description}</p>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                      <MapPin className="w-4 h-4 text-emerald-600" />
                      {product.location}
                    </div>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <div className="flex flex-col">
                        <span className="text-xs text-gray-500 mb-1">السعر</span>
                        <span className="text-xl font-bold text-emerald-600">
                          {product.price.toLocaleString('ar-SA')} ل.س
                        </span>
                      </div>
                      <button 
                        onClick={() => handleAddToCart(product)}
                        className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-emerald-700 transition-colors flex items-center gap-2 shadow-sm hover:shadow-md"
                      >
                        <ShoppingCart className="w-4 h-4" />
                        إضافة
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Sidebar / Filters */}
          <div className="w-full lg:w-1/4">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sticky top-24">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Filter className="w-5 h-5 text-emerald-600" />
                تصفية المنتجات
              </h3>
              
              {/* Search */}
              <div className="relative mb-6 group">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-emerald-600 transition-colors" />
                <input 
                  type="text"
                  placeholder="ابحث عن منتج..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pr-12 pl-4 py-3 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-emerald-500 transition-all shadow-sm hover:border-emerald-300"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Sorting */}
              <div className="mb-6">
                <h4 className="font-semibold text-gray-700 mb-3">ترتيب حسب</h4>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full p-3 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-emerald-500 transition-all shadow-sm"
                >
                  <option value="newest">الأحدث</option>
                  <option value="price-asc">السعر: من الأقل للأعلى</option>
                  <option value="price-desc">السعر: من الأعلى للأقل</option>
                  <option value="rating">التقييم</option>
                </select>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className="font-semibold text-gray-700 mb-3">نطاق السعر</h4>
                <div className="flex gap-2">
                  <input 
                    type="number"
                    placeholder="من"
                    value={priceRange.min}
                    onChange={(e) => setPriceRange(prev => ({ ...prev, min: Number(e.target.value) }))}
                    className="w-1/2 p-2 border border-gray-200 rounded-lg text-sm"
                  />
                  <input 
                    type="number"
                    placeholder="إلى"
                    value={priceRange.max}
                    onChange={(e) => setPriceRange(prev => ({ ...prev, max: Number(e.target.value) }))}
                    className="w-1/2 p-2 border border-gray-200 rounded-lg text-sm"
                  />
                </div>
              </div>

              {/* Categories */}
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-700 mb-3">التصنيفات</h4>
                {CATEGORIES.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={`w-full text-right px-4 py-2 rounded-xl text-sm transition-colors ${
                      activeCategory === category.id
                        ? 'bg-emerald-50 text-emerald-700 font-bold'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="w-full lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">
                {activeCategory === 'all' ? 'جميع المنتجات' : CATEGORIES.find(c => c.id === activeCategory)?.name}
              </h2>
              <span className="text-gray-500 text-sm">{filteredProducts.length} منتج</span>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <ListingSkeleton key={i} />
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-gray-100 shadow-sm">
                <ShoppingBag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد منتجات</h3>
                <p className="text-gray-500">جرب البحث بكلمات مختلفة أو تغيير التصنيف</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-xl transition-all group flex flex-col h-full"
                  >
                    <Link href={`/marketplace/product/${product.id}`} className="block relative h-56 overflow-hidden">
                      <img 
                        src={product.image || (product.images && product.images[0])} 
                        alt={product.name} 
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded-lg text-[10px] font-bold text-emerald-700 flex items-center gap-1 shadow-sm uppercase tracking-wider">
                        <MapPin className="w-3 h-3" />
                        {product.location}
                      </div>
                      <div className="absolute bottom-3 left-3 bg-emerald-600 text-white px-2.5 py-1 rounded-lg text-[10px] font-bold shadow-lg">
                        {CATEGORIES.find(c => c.id === product.category)?.name}
                      </div>
                    </Link>
                    
                    <div className="p-5 flex flex-col flex-1">
                      <Link href={`/marketplace/product/${product.id}`} className="block mb-2">
                        <h3 className="font-bold text-gray-900 text-lg line-clamp-1 group-hover:text-emerald-600 transition-colors">{product.name}</h3>
                        <p className="text-gray-500 text-sm line-clamp-2 mt-1 leading-relaxed">
                          {product.description}
                        </p>
                      </Link>
                      
                      <div className="flex items-center gap-3 mb-6">
                        <div className="flex items-center text-amber-500 font-bold text-sm">
                          <Star className="w-4 h-4 fill-current mr-1" />
                          {product.rating}
                        </div>
                        <span className="text-gray-300">|</span>
                        <span className="text-gray-500 text-xs">{product.vendor}</span>
                      </div>
                      
                      <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                        <div className="flex flex-col">
                          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-0.5">السعر</span>
                          <span className="font-black text-emerald-600 text-xl">
                            {product.price.toLocaleString('ar-SA')} <span className="text-xs font-normal">ل.س</span>
                          </span>
                        </div>
                        <button 
                          onClick={() => handleAddToCart(product)}
                          className="bg-gray-900 text-white p-3 rounded-xl hover:bg-emerald-600 transition-all active:scale-95 shadow-lg shadow-gray-200 hover:shadow-emerald-200"
                          title="إضافة إلى السلة"
                        >
                          <ShoppingCart className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
          
        </div>
      </div>


    </div>
  );
}
