import { db } from '../../../firebase';
import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  query, 
  where, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  serverTimestamp,
  setDoc,
  increment
} from 'firebase/firestore';
import { INITIAL_SERVICES } from '../data/initialServices';
import { ServiceSchema, Service } from '../domain/service';
import { handleFirestoreError, OperationType } from '../../../shared/utils/firestoreError';

export type { Service };

const SERVICES_COLLECTION = 'services';

export const seedServices = async (userUid: string, force: boolean = false) => {
  try {
    const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
    
    // Check if we need to seed by looking at the first document or count
    let needsSeeding = force || querySnapshot.size < 20;
    
    if (!needsSeeding && querySnapshot.docs.length > 0) {
      // Check if the first document has mainCategoryId, if not, it's old data and needs reseeding
      const firstDoc = querySnapshot.docs[0].data();
      if (!firstDoc.mainCategoryId) {
        needsSeeding = true;
      }
    }

    if (needsSeeding) {
      console.log('Seeding services to ensure data integrity...');
      for (const service of INITIAL_SERVICES) {
        const { id, ...serviceData } = service;
        try {
          const validatedData = ServiceSchema.parse({ ...serviceData, authorUid: userUid });
          await setDoc(doc(db, SERVICES_COLLECTION, id), {
            ...validatedData,
            createdAt: serverTimestamp()
          });
        } catch (err) {
          console.warn(`Could not seed service ${id}:`, err);
        }
      }
      console.log('Seeding complete.');
    } else {
      console.log('Services already seeded and valid.');
    }
  } catch (error) {
    console.error('Error during seeding check:', error);
  }
};

export const getAllServices = async (): Promise<Service[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, SERVICES_COLLECTION));
    const services: Service[] = [];
    querySnapshot.docs.forEach(doc => {
      try {
        const data = { id: doc.id, ...doc.data() };
        services.push(ServiceSchema.parse(data));
      } catch (err) {
        console.warn(`Invalid service data for document ${doc.id}:`, err);
      }
    });
    return services;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, SERVICES_COLLECTION);
  }
};

export const getServicesByCategory = async (categoryId: string): Promise<Service[]> => {
  const q = query(collection(db, SERVICES_COLLECTION), where('mainCategoryId', '==', categoryId));
  try {
    const querySnapshot = await getDocs(q);
    const services: Service[] = [];
    querySnapshot.docs.forEach(doc => {
      try {
        const data = { id: doc.id, ...doc.data() };
        services.push(ServiceSchema.parse(data));
      } catch (err) {
        console.warn(`Invalid service data for document ${doc.id}:`, err);
      }
    });
    return services;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, SERVICES_COLLECTION);
  }
};

export const getServiceById = async (id: string): Promise<Service | null> => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = { id: docSnap.id, ...docSnap.data() };
      return ServiceSchema.parse(data);
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, SERVICES_COLLECTION + '/' + id);
  }
};

export const createService = async (serviceData: Omit<Service, 'id' | 'createdAt'>) => {
  try {
    const validatedData = ServiceSchema.parse(serviceData);
    return await addDoc(collection(db, SERVICES_COLLECTION), {
      ...validatedData,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, SERVICES_COLLECTION);
  }
};

export const updateService = async (id: string, serviceData: Partial<Service>) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    await updateDoc(docRef, serviceData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, SERVICES_COLLECTION + '/' + id);
  }
};

export const getServicesByAuthor = async (authorUid: string): Promise<Service[]> => {
  const q = query(collection(db, SERVICES_COLLECTION), where('authorUid', '==', authorUid));
  try {
    const querySnapshot = await getDocs(q);
    const services: Service[] = [];
    querySnapshot.docs.forEach(doc => {
      try {
        const data = { id: doc.id, ...doc.data() };
        services.push(ServiceSchema.parse(data));
      } catch (err) {
        console.warn(`Invalid service data for document ${doc.id}:`, err);
      }
    });
    return services;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, SERVICES_COLLECTION);
    return [];
  }
};

export const deleteService = async (id: string) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, SERVICES_COLLECTION + '/' + id);
  }
};

export const incrementServiceViews = async (id: string) => {
  const docRef = doc(db, SERVICES_COLLECTION, id);
  try {
    await updateDoc(docRef, {
      views: increment(1)
    });
  } catch (error) {
    // Silently fail for views
    console.warn('Could not increment views:', error);
  }
};
