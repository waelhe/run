"use client";
import React, { useState, useEffect } from 'react';
import Link from 'next/link';

import { Star, MapPin, Heart, ChevronRight, ChevronLeft, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../../../../core/contexts/AuthContext';
import { db } from '../../../../firebase';
import { collection, query, where, getDocs, addDoc, deleteDoc, doc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import toast from 'react-hot-toast';
import { Service } from '../../domain/service';

interface ServiceCardProps {
  service: Service;
  activeColorClass?: string;
  activeTextClass?: string;
  activeBgLightClass?: string;
  className?: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ 
  service, 
  activeColorClass = 'bg-emerald-600', 
  activeTextClass = 'text-emerald-600', 
  activeBgLightClass = 'bg-emerald-50',
  className = "w-[280px] md:w-[320px]"
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const { user, signInWithGoogle } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteId, setFavoriteId] = useState<string | null>(null);
  const [isFavoriteLoading, setIsFavoriteLoading] = useState(false);

  useEffect(() => {
    if (!user || !service.id) {
      setIsFavorite(false);
      setFavoriteId(null);
      return;
    }

    const q = query(
      collection(db, 'favorites'),
      where('userId', '==', user.uid),
      where('serviceId', '==', service.id)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        setIsFavorite(true);
        setFavoriteId(snapshot.docs[0].id);
      } else {
        setIsFavorite(false);
        setFavoriteId(null);
      }
    });

    return () => unsubscribe();
  }, [user, service.id]);

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!user) {
      signInWithGoogle();
      return;
    }

    if (!service.id) return;

    setIsFavoriteLoading(true);
    try {
      if (isFavorite && favoriteId) {
        await deleteDoc(doc(db, 'favorites', favoriteId));
        toast.success('تمت الإزالة من المفضلة');
      } else {
        await addDoc(collection(db, 'favorites'), {
          userId: user.uid,
          serviceId: service.id,
          createdAt: serverTimestamp()
        });
        toast.success('تمت الإضافة إلى المفضلة');
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
      toast.error('حدث خطأ. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsFavoriteLoading(false);
    }
  };

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % service.images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + service.images.length) % service.images.length);
  };

  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(service.price);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`group flex flex-col shrink-0 cursor-pointer ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-square rounded-xl overflow-hidden mb-2">
        {/* Image Carousel */}
        <Link href={`/listing/${service.id}`} className="block w-full h-full">
          <img 
            src={service.images && service.images.length > 0 ? service.images[currentImageIndex] : 'https://images.unsplash.com/photo-1585076641394-6302f23b7b65?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'} 
            alt={service.title || 'Service'} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
        </Link>

        {/* Carousel Controls */}
        {isHovered && service.images && service.images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute top-1/2 right-2 -translate-y-1/2 p-1 bg-white/90 backdrop-blur-sm rounded-full text-gray-900 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button 
              onClick={nextImage}
              className="absolute top-1/2 left-2 -translate-y-1/2 p-1 bg-white/90 backdrop-blur-sm rounded-full text-gray-900 hover:bg-white hover:scale-110 transition-all z-10 shadow-sm"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </>
        )}

        {/* Carousel Dots */}
        {service.images && service.images.length > 1 && (
          <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1 z-10">
            {service.images.map((_, idx) => (
              <div 
                key={idx} 
                className={`h-1 w-1 rounded-full transition-all ${idx === currentImageIndex ? 'bg-white scale-125' : 'bg-white/60'}`}
              />
            ))}
          </div>
        )}

        {/* Guest Favorite Badge */}
        {service.isPopular && (
          <div className="absolute top-2 right-2 z-10">
            <div className="bg-white/95 backdrop-blur-sm px-2 py-0.5 rounded-full shadow-sm border border-gray-100">
              <span className="text-[10px] font-bold text-gray-900">مفضل لدى الضيوف</span>
            </div>
          </div>
        )}

        {/* Favorite Button */}
        <button 
          onClick={toggleFavorite}
          disabled={isFavoriteLoading}
          className="absolute top-2 left-2 z-10 p-1 group/heart"
        >
          <Heart 
            className={`w-5 h-5 transition-all ${
              isFavorite 
                ? 'fill-red-500 stroke-red-500 scale-110' 
                : 'text-white stroke-[2px] drop-shadow-md group-hover/heart:scale-110'
            }`} 
          />
        </button>
      </div>
      
      <div className="flex flex-col gap-0.5">
        <div className="flex justify-between items-start">
          <Link href={`/listing/${service.id}`} className="flex-1 min-w-0">
            <h3 className="text-[14px] font-bold text-gray-900 truncate">
              {service.title}
            </h3>
          </Link>
          <div className="flex items-center gap-1 shrink-0">
            <Star className="w-3 h-3 fill-current text-gray-900" />
            <span className="text-xs font-medium text-gray-900">{service.rating}</span>
          </div>
        </div>
        
        <p className="text-[13px] text-gray-500 truncate">
          {service.location}
        </p>
        
        <div className="mt-0.5 flex items-center gap-1">
          <span className="text-[14px] font-bold text-gray-900">{formattedPrice}</span>
          <span className="text-[13px] text-gray-600">مقابل 2 ليال</span>
        </div>
      </div>
    </motion.div>
  );
};

export default ServiceCard;
