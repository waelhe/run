// Application layer for services
