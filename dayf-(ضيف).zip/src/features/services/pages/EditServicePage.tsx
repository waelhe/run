"use client";
import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { useNavigate } from '../../../useNavigate';


import { useAuth } from '../../../core/contexts/AuthContext';
import { useLanguage } from '../../../core/contexts/LanguageContext';
import { getServiceById, updateService, Service } from '../infrastructure/serviceService';
import ServiceForm from '../components/ServiceForm';
import { ChevronLeft, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function EditServicePage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { language } = useLanguage();
  const navigate = useNavigate();
  const [service, setService] = useState<Service | null>(null);
  const [loading, setLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    const fetchService = async () => {
      if (!id) return;
      try {
        const data = await getServiceById(id);
        if (data) {
          // Check if user is the owner
          if (data.authorUid !== user?.uid) {
            toast.error(language === 'ar' ? 'ليس لديك صلاحية لتعديل هذه الخدمة' : 'You do not have permission to edit this service');
            navigate('/provider-dashboard');
            return;
          }
          setService(data);
        } else {
          navigate('/provider-dashboard');
        }
      } catch (error) {
        console.error('Error fetching service:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchService();
  }, [id, user, navigate]);

  const handleSubmit = async (data: Service) => {
    if (!id) return;
    setIsUpdating(true);
    try {
      await updateService(id, data);
      toast.success(language === 'ar' ? 'تم تحديث الخدمة بنجاح' : 'Service updated successfully');
      navigate('/provider-dashboard');
    } catch (error) {
      console.error('Error updating service:', error);
      toast.error(language === 'ar' ? 'فشل في تحديث الخدمة' : 'Failed to update service');
    } finally {
      setIsUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="pt-24 pb-20 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-gray-500 hover:text-emerald-600 mb-6 font-bold transition-colors"
      >
        <ChevronLeft className="w-5 h-5 rotate-180" />
        {language === 'ar' ? 'العودة' : 'Back'}
      </button>

      <div className="bg-white border border-gray-200 rounded-3xl p-8 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">
          {language === 'ar' ? 'تعديل الخدمة' : 'Edit Service'}
        </h1>
        
        {service && (
          <ServiceForm 
            initialData={service} 
            onSubmit={handleSubmit} 
            isLoading={isUpdating} 
          />
        )}
      </div>
    </div>
  );
}
