"use client";
import React from 'react';
import { useParams } from 'next/navigation';
import { useNavigate } from '../../../useNavigate';


import { motion } from 'framer-motion';
import { 
  ChevronRight, 
  Clock, 
  BookOpen, 
  Share2, 
  MapPin, 
  Calendar,
  ArrowRight,
  Bookmark,
  Heart
} from 'lucide-react';
import { useLanguage } from '../../../core/contexts/LanguageContext';

const TRAVEL_GUIDES = [
  {
    id: 'damascus',
    title: 'دليل دمشق القديمة',
    description: 'اكتشف سحر أقدم عاصمة مأهولة في التاريخ، من الجامع الأموي إلى سوق الحميدية وحارات الشام العتيقة.',
    content: `دمشق القديمة ليست مجرد مكان، بل هي رحلة عبر الزمن. تبدأ رحلتك عادة من "باب توما" أو "باب شرقي"، حيث تتشابك الأزقة الضيقة المرصوفة بالحجارة السوداء.

أبرز المحطات:
1. الجامع الأموي الكبير: تحفة معمارية فريدة تعكس تعاقب الحضارات.
2. سوق الحميدية: السوق المسقوف الأشهر الذي يفوح برائحة التوابل والتاريخ.
3. قصر العظم: مثال رائع للعمارة الدمشقية في العهد العثماني.
4. حارة اليهود والقيمرية: حيث تجد أجمل البيوت الدمشقية التي تحولت لمطاعم وفنادق تراثية.

نصيحة للمسافر: لا تفوت تجربة "بوظة بكداش" في سوق الحميدية، وتناول وجبة غداء في أحد بيوت دمشق القديمة لتشعر بروح المدينة الحقيقية.`,
    image: 'https://images.unsplash.com/photo-1585282760623-14660851452c?auto=format&fit=crop&w=1200&q=80',
    readTime: '15 دقيقة',
    author: 'فريق ضيف',
    date: '12 مارس 2024',
    tags: ['تاريخ', 'تسوق', 'طعام']
  },
  {
    id: 'aleppo',
    title: 'اكتشف حلب الشهباء',
    description: 'عاصمة الطرب والذواقة. دليلك الشامل لقلعة حلب، أسواقها التاريخية، وأشهر مطاعمها.',
    content: `حلب، المدينة التي لا تنام عن الطرب، ترحب بزوارها بقلعتها الشامخة التي تعد من أقدم وأكبر القلاع في العالم.

ماذا تزور في حلب؟
1. قلعة حلب: الرمز الصامد للمدينة وإطلالة بانورامية لا تنسى.
2. الأسواق القديمة: رغم الدمار، لا تزال روح التجارة تنبض في أسواق المدينة القديمة.
3. حي الجديدة: الحي التاريخي الجميل بكنائسه وبيوته العريقة.

المطبخ الحلبي: حلب هي عاصمة الطعام في المنطقة. جرب "الكبة الحلبية" بأنواعها المختلفة، و"المشاوي" التي تشتهر بها المدينة، ولا تنسَ تذوق "الفستق الحلبي" في الحلويات الشرقية.`,
    image: 'https://images.unsplash.com/photo-1610312278520-bcc893a3ff1d?auto=format&fit=crop&w=1200&q=80',
    readTime: '12 دقيقة',
    author: 'أحمد الحلبي',
    date: '10 مارس 2024',
    tags: ['ثقافة', 'مطبخ', 'تراث']
  }
];

export default function GuideDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { language } = useLanguage();
  
  const guide = TRAVEL_GUIDES.find(g => g.id === id);

  if (!guide) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">الدليل غير موجود</h2>
        <button 
          onClick={() => navigate('/community')}
          className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-bold"
        >
          العودة للمجتمع
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Hero Header */}
      <div className="relative h-[60vh] min-h-[400px] w-full overflow-hidden">
        <img 
          src={guide.image} 
          alt={guide.title} 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        <div className="absolute top-8 left-4 right-4 flex justify-between items-center z-10">
          <button 
            onClick={() => navigate('/community')}
            className="p-3 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/30 transition-all"
          >
            <ArrowRight className="w-6 h-6" />
          </button>
          <div className="flex gap-2">
            <button className="p-3 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/30 transition-all">
              <Heart className="w-6 h-6" />
            </button>
            <button className="p-3 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/30 transition-all">
              <Share2 className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="absolute bottom-12 left-4 right-4 max-w-4xl mx-auto text-white">
          <div className="flex gap-2 mb-4">
            {guide.tags.map(tag => (
              <span key={tag} className="bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                {tag}
              </span>
            ))}
          </div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold mb-4 leading-tight"
          >
            {guide.title}
          </motion.h1>
          <div className="flex items-center gap-6 text-sm text-gray-300">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              <span>{guide.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{guide.date}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>{guide.readTime} قراءة</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-20">
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-gray-100">
          <div className="prose prose-emerald prose-lg max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">
            {guide.content}
          </div>

          <div className="mt-12 pt-12 border-t border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-6">هل أعجبك هذا الدليل؟</h3>
            <div className="flex flex-wrap gap-4">
              <button className="flex-1 min-w-[200px] bg-emerald-600 text-white font-bold py-4 rounded-2xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 flex items-center justify-center gap-2">
                <Bookmark className="w-5 h-5" />
                حفظ الدليل للمستقبل
              </button>
              <button className="flex-1 min-w-[200px] bg-white border-2 border-emerald-600 text-emerald-600 font-bold py-4 rounded-2xl hover:bg-emerald-50 transition-all flex items-center justify-center gap-2">
                <Share2 className="w-5 h-5" />
                مشاركة مع الأصدقاء
              </button>
            </div>
          </div>
        </div>

        {/* Related Guides */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">أدلة أخرى قد تهمك</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TRAVEL_GUIDES.filter(g => g.id !== id).map(g => (
              <div 
                key={g.id}
                onClick={() => navigate(`/community/guide/${g.id}`)}
                className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer group"
              >
                <div className="relative h-40">
                  <img src={g.image} alt={g.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-black/20" />
                </div>
                <div className="p-4">
                  <h4 className="font-bold text-gray-900 group-hover:text-emerald-600 transition-colors">{g.title}</h4>
                  <p className="text-sm text-gray-500 line-clamp-1 mt-1">{g.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
