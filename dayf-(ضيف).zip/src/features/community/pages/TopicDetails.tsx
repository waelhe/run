"use client";
import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useNavigate } from '../../../useNavigate';


import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronRight, 
  ThumbsUp, 
  MessageCircle, 
  Share2, 
  MoreVertical, 
  Send, 
  Loader2, 
  Award,
  Clock,
  User
} from 'lucide-react';
import { useLanguage } from '../../../core/contexts/LanguageContext';
import { useAuth } from '../../../core/contexts/AuthContext';
import { communityService } from '../infrastructure/communityService';
import { CommunityTopic, Reply } from '../types';
import toast from 'react-hot-toast';

const CATEGORIES = [
  { id: 'hosting-tips', title: 'نصائح للمزودين', color: 'bg-amber-100 text-amber-600' },
  { id: 'guest-experiences', title: 'تجارب الضيوف', color: 'bg-blue-100 text-blue-600' },
  { id: 'local-groups', title: 'المجموعات المحلية', color: 'bg-emerald-100 text-emerald-600' },
  { id: 'resource-center', title: 'مركز الموارد', color: 'bg-purple-100 text-purple-600' }
];

export default function TopicDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { language } = useLanguage();
  const { currentUser } = useAuth();
  
  const [topic, setTopic] = useState<CommunityTopic | null>(null);
  const [replies, setReplies] = useState<Reply[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditingTopic, setIsEditingTopic] = useState(false);
  const [editTopicContent, setEditTopicContent] = useState('');
  const [editingReplyId, setEditingReplyId] = useState<string | null>(null);
  const [editReplyContent, setEditReplyContent] = useState('');
  const [replyContent, setReplyContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleUpdateTopic = async () => {
    if (!id) return;
    try {
      await communityService.updateTopic(id, editTopicContent);
      setTopic(prev => prev ? { ...prev, content: editTopicContent } : null);
      setIsEditingTopic(false);
    } catch (error) {
      console.error('Error updating topic:', error);
      toast.error('حدث خطأ أثناء التعديل');
    }
  };

  const handleUpdateReply = async (replyId: string) => {
    try {
      await communityService.updateReply(replyId, editReplyContent);
      setReplies(prev => prev.map(r => r.id === replyId ? { ...r, content: editReplyContent } : r));
      setEditingReplyId(null);
    } catch (error) {
      console.error('Error updating reply:', error);
      toast.error('حدث خطأ أثناء التعديل');
    }
  };

  useEffect(() => {
    if (!id) return;

    const fetchTopic = async () => {
      try {
        const data = await communityService.getTopicById(id);
        if (data) {
          setTopic(data);
        } else {
          toast.error(language === 'ar' ? 'الموضوع غير موجود' : 'Topic not found');
          navigate('/community');
        }
      } catch (error) {
        console.error('Error fetching topic:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTopic();

    const unsubscribe = communityService.subscribeToReplies(id, (fetchedReplies) => {
      setReplies(fetchedReplies);
    });

    return () => unsubscribe();
  }, [id, navigate, language]);

  const handleLikeTopic = async () => {
    if (!currentUser || !id) {
      toast.error(language === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first');
      return;
    }
    try {
      if (topic) {
        await communityService.likeTopic(id, topic.authorUid);
        setTopic(prev => prev ? { ...prev, likesCount: prev.likesCount + 1 } : null);
      }
    } catch (error) {
      console.error('Error liking topic:', error);
    }
  };

  const handleLikeReply = async (reply: Reply) => {
    if (!currentUser) {
      toast.error(language === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first');
      return;
    }
    try {
      await communityService.likeReply(reply.id!, reply.authorUid);
      // Optionally update local state for replies
    } catch (error) {
      console.error('Error liking reply:', error);
    }
  };

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !id) {
      toast.error(language === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first');
      return;
    }

    if (!replyContent.trim()) return;

    setIsSubmitting(true);
    try {
      await communityService.createReply({
        topicId: id,
        content: replyContent,
        authorUid: currentUser.uid,
        authorName: currentUser.displayName || 'مستخدم ضيف',
        authorAvatar: currentUser.photoURL || `https://ui-avatars.com/api/?name=${currentUser.displayName || 'User'}&background=random`
      });
      setReplyContent('');
      toast.success(language === 'ar' ? 'تم إضافة الرد بنجاح' : 'Reply added successfully');
    } catch (error) {
      console.error('Error creating reply:', error);
      toast.error(language === 'ar' ? 'حدث خطأ أثناء إضافة الرد' : 'Error adding reply');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatTimeAgo = (timestamp: any) => {
    if (!timestamp) return language === 'ar' ? 'الآن' : 'Now';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (language === 'ar') {
      if (diffInSeconds < 60) return 'منذ لحظات';
      if (diffInSeconds < 3600) return `منذ ${Math.floor(diffInSeconds / 60)} دقيقة`;
      if (diffInSeconds < 86400) return `منذ ${Math.floor(diffInSeconds / 3600)} ساعة`;
      return `منذ ${Math.floor(diffInSeconds / 86400)} يوم`;
    } else {
      if (diffInSeconds < 60) return 'Just now';
      if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
      if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
      return `${Math.floor(diffInSeconds / 86400)}d ago`;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!topic) return null;

  const category = CATEGORIES.find(c => c.id === topic.categoryId);

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-sm text-gray-500 mb-6 overflow-x-auto whitespace-nowrap pb-2">
          <button onClick={() => navigate('/community')} className="hover:text-emerald-600 transition-colors">
            {language === 'ar' ? 'المجتمع' : 'Community'}
          </button>
          <ChevronRight className="w-4 h-4 flex-shrink-0" />
          <span className="text-gray-400">{category?.title || 'عام'}</span>
          <ChevronRight className="w-4 h-4 flex-shrink-0" />
          <span className="text-gray-900 font-medium truncate">{topic.title}</span>
        </nav>

        {/* Main Topic Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden mb-8"
        >
          <div className="p-6 sm:p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <img 
                  src={topic.authorAvatar} 
                  alt={topic.authorName} 
                  className="w-12 h-12 rounded-full object-cover border border-gray-100"
                />
                <div>
                  <h4 className="font-bold text-gray-900">{topic.authorName}</h4>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>{formatTimeAgo(topic.createdAt)}</span>
                    <span>•</span>
                    <span className={`px-2 py-0.5 rounded-md font-bold ${category?.color || 'bg-gray-100 text-gray-600'}`}>
                      {category?.title || 'عام'}
                    </span>
                  </div>
                </div>
              </div>
              <button className="p-2 text-gray-400 hover:bg-gray-50 rounded-full transition-colors">
                <MoreVertical className="w-5 h-5" />
              </button>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 leading-tight">
              {topic.title}
            </h1>
            
            {isEditingTopic ? (
              <div className="space-y-4 mb-8">
                <textarea
                  value={editTopicContent}
                  onChange={(e) => setEditTopicContent(e.target.value)}
                  className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  rows={6}
                />
                <div className="flex gap-2">
                  <button onClick={handleUpdateTopic} className="bg-emerald-600 text-white px-4 py-2 rounded-lg">حفظ</button>
                  <button onClick={() => setIsEditingTopic(false)} className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg">إلغاء</button>
                </div>
              </div>
            ) : (
              <div className="prose prose-emerald max-w-none text-gray-700 leading-relaxed mb-8 whitespace-pre-wrap">
                {topic.content}
              </div>
            )}

            {!isEditingTopic && currentUser?.uid === topic.authorUid && (
              <button 
                onClick={() => {
                  setEditTopicContent(topic.content);
                  setIsEditingTopic(true);
                }}
                className="text-sm text-emerald-600 hover:underline mb-4 block"
              >
                تعديل الموضوع
              </button>
            )}

            <div className="flex items-center justify-between pt-6 border-t border-gray-100">
              <div className="flex items-center gap-6">
                <button 
                  onClick={handleLikeTopic}
                  className="flex items-center gap-2 text-gray-500 hover:text-emerald-600 transition-colors group"
                >
                  <div className="p-2 rounded-full group-hover:bg-emerald-50 transition-colors">
                    <ThumbsUp className="w-5 h-5" />
                  </div>
                  <span className="font-bold">{topic.likesCount}</span>
                </button>
                <div className="flex items-center gap-2 text-gray-500">
                  <div className="p-2 rounded-full">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <span className="font-bold">{topic.repliesCount}</span>
                </div>
              </div>
              <button className="flex items-center gap-2 text-gray-500 hover:text-emerald-600 transition-colors">
                <Share2 className="w-5 h-5" />
                <span className="hidden sm:inline font-bold">{language === 'ar' ? 'مشاركة' : 'Share'}</span>
              </button>
            </div>
          </div>
        </motion.div>

        {/* Replies Section */}
        <div className="space-y-6 mb-12">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2 px-2">
            <MessageCircle className="w-5 h-5 text-emerald-600" />
            {language === 'ar' ? 'الردود' : 'Replies'} ({replies.length})
          </h2>

          <AnimatePresence mode="popLayout">
            {replies.map((reply, index) => (
              <motion.div
                key={reply.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100"
              >
                <div className="flex items-start gap-4">
                  <img 
                    src={reply.authorAvatar} 
                    alt={reply.authorName} 
                    className="w-10 h-10 rounded-full object-cover border border-gray-100"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="font-bold text-gray-900 text-sm">{reply.authorName}</span>
                        <span className="text-xs text-gray-400 mx-2">•</span>
                        <span className="text-xs text-gray-400">{formatTimeAgo(reply.createdAt)}</span>
                      </div>
                      <button 
                        onClick={() => handleLikeReply(reply)}
                        className="flex items-center gap-1 text-gray-400 hover:text-emerald-600 transition-colors"
                      >
                        <ThumbsUp className="w-4 h-4" />
                        <span className="text-xs font-bold">{reply.likesCount}</span>
                      </button>
                    </div>
                    {editingReplyId === reply.id ? (
                      <div className="space-y-4 mt-4">
                        <textarea
                          value={editReplyContent}
                          onChange={(e) => setEditReplyContent(e.target.value)}
                          className="w-full p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500"
                          rows={3}
                        />
                        <div className="flex gap-2">
                          <button onClick={() => handleUpdateReply(reply.id!)} className="bg-emerald-600 text-white px-4 py-2 rounded-lg">حفظ</button>
                          <button onClick={() => setEditingReplyId(null)} className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg">إلغاء</button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-wrap">
                        {reply.content}
                      </p>
                    )}
                    {editingReplyId !== reply.id && currentUser?.uid === reply.authorUid && (
                      <button 
                        onClick={() => {
                          setEditReplyContent(reply.content);
                          setEditingReplyId(reply.id!);
                        }}
                        className="text-xs text-emerald-600 hover:underline mt-2 block"
                      >
                        تعديل الرد
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Reply Form */}
        <div className="sticky bottom-6 z-10">
          <form 
            onSubmit={handleSubmitReply}
            className="bg-white rounded-2xl shadow-2xl border border-gray-100 p-4 flex items-end gap-3"
          >
            <div className="flex-1">
              <textarea
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                placeholder={language === 'ar' ? 'اكتب ردك هنا...' : 'Write your reply...'}
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 border-none resize-none"
                rows={1}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = `${Math.min(target.scrollHeight, 120)}px`;
                }}
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting || !replyContent.trim()}
              className="bg-emerald-600 text-white p-3 rounded-xl hover:bg-emerald-700 transition-all disabled:opacity-50 disabled:scale-95 flex-shrink-0"
            >
              {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
