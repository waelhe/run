import AdmZip from 'adm-zip';
import fs from 'fs';

async function downloadAndExtract() {
  const url = 'https://github.com/waelhe/my-project/raw/refs/heads/main/dayf-17.zip';
  console.log('Downloading...', url);
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download: ${response.statusText}`);
  }
  
  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  
  fs.writeFileSync('temp.zip', buffer);
  console.log('Downloaded to temp.zip. Extracting...');
  
  const zip = new AdmZip('temp.zip');
  zip.extractAllTo('./extracted', true);
  
  console.log('Extracted successfully to ./extracted');
}

downloadAndExtract().catch(console.error);
