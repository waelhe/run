import fs from 'fs';
import path from 'path';

function moveFiles(srcDir, destDir) {
  const files = fs.readdirSync(srcDir);
  for (const file of files) {
    const srcPath = path.join(srcDir, file);
    const destPath = path.join(destDir, file);
    
    // Skip if it's the extracted directory itself or temp files
    if (file === 'extracted' || file === 'temp.zip' || file === 'fetch-zip.ts' || file === 'move-files.ts') {
      continue;
    }
    
    if (fs.existsSync(destPath)) {
      if (fs.lstatSync(destPath).isDirectory()) {
        fs.rmSync(destPath, { recursive: true, force: true });
      } else {
        fs.unlinkSync(destPath);
      }
    }
    
    fs.renameSync(srcPath, destPath);
    console.log(`Moved ${file}`);
  }
}

moveFiles('./extracted', './');
console.log('All files moved successfully.');
