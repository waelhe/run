const fs = require('fs');
const path = require('path');

function getAllFiles(dir, fileList = []) {
  if (!fs.existsSync(dir)) return fileList;
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      getAllFiles(filePath, fileList);
    } else if (filePath.endsWith('.ts') || filePath.endsWith('.tsx')) {
      fileList.push(filePath);
    }
  }
  return fileList;
}

const allFiles = getAllFiles('src/features');

for (const file of allFiles) {
  if (file.includes('infrastructure')) {
    let content = fs.readFileSync(file, 'utf8');
    let changed = false;

    // Replace ../../shared/ with ../../../shared/
    const regex = /(['"])\.\.\/\.\.\/shared\//g;
    if (regex.test(content)) {
      content = content.replace(regex, `$1../../../shared/`);
      changed = true;
    }
    
    // Replace ../../utils/ with ../../../shared/utils/
    const regexUtils = /(['"])\.\.\/\.\.\/utils\//g;
    if (regexUtils.test(content)) {
      content = content.replace(regexUtils, `$1../../../shared/utils/`);
      changed = true;
    }

    if (changed) {
      fs.writeFileSync(file, content, 'utf8');
      console.log(`Fixed shared/utils import in ${file}`);
    }
  }
}
