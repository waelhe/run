import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  increment,
  onSnapshot,
} from 'firebase/firestore';
import { db } from '../../firebase';
import { CommunityTopic, CommunityReply } from '../../features/community/types';

const TOPICS_COLLECTION = 'community_topics';
const REPLIES_COLLECTION = 'community_replies';

export const communityService = {
  // Topics
  async getTopics(categoryId?: string, limitCount: number = 20): Promise<CommunityTopic[]> {
    let q = query(
      collection(db, TOPICS_COLLECTION),
      orderBy('createdAt', 'desc'),
      limit(limitCount)
    );

    if (categoryId) {
      q = query(
        collection(db, TOPICS_COLLECTION),
        where('categoryId', '==', categoryId),
        orderBy('createdAt', 'desc'),
        limit(limitCount)
      );
    }

    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunityTopic));
  },

  async getTopicById(topicId: string): Promise<CommunityTopic | null> {
    const docRef = doc(db, TOPICS_COLLECTION, topicId);
    const snapshot = await getDoc(docRef);
    if (snapshot.exists()) {
      return { id: snapshot.id, ...snapshot.data() } as CommunityTopic;
    }
    return null;
  },

  async createTopic(topic: Omit<CommunityTopic, 'id' | 'createdAt' | 'likesCount' | 'repliesCount'>): Promise<string> {
    const docRef = await addDoc(collection(db, TOPICS_COLLECTION), {
      ...topic,
      likesCount: 0,
      repliesCount: 0,
      createdAt: serverTimestamp()
    });
    return docRef.id;
  },

  async likeTopic(topicId: string): Promise<void> {
    const docRef = doc(db, TOPICS_COLLECTION, topicId);
    await updateDoc(docRef, {
      likesCount: increment(1)
    });
  },

  // Replies
  async getReplies(topicId: string): Promise<CommunityReply[]> {
    const q = query(
      collection(db, REPLIES_COLLECTION),
      where('topicId', '==', topicId),
      orderBy('createdAt', 'asc')
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunityReply));
  },

  async createReply(reply: Omit<CommunityReply, 'id' | 'createdAt' | 'likesCount'>): Promise<string> {
    const docRef = await addDoc(collection(db, REPLIES_COLLECTION), {
      ...reply,
      likesCount: 0,
      createdAt: serverTimestamp()
    });
    
    // Increment replies count on the topic
    const topicRef = doc(db, TOPICS_COLLECTION, reply.topicId);
    await updateDoc(topicRef, {
      repliesCount: increment(1)
    });

    return docRef.id;
  },

  async likeReply(replyId: string): Promise<void> {
    const docRef = doc(db, REPLIES_COLLECTION, replyId);
    await updateDoc(docRef, {
      likesCount: increment(1)
    });
  },
  
  // Real-time listeners
  subscribeToTopics(callback: (topics: CommunityTopic[]) => void, categoryId?: string) {
    let q = query(
      collection(db, TOPICS_COLLECTION),
      orderBy('createdAt', 'desc'),
      limit(50)
    );

    if (categoryId) {
      q = query(
        collection(db, TOPICS_COLLECTION),
        where('categoryId', '==', categoryId),
        orderBy('createdAt', 'desc'),
        limit(50)
      );
    }

    return onSnapshot(q, (snapshot) => {
      const topics = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunityTopic));
      callback(topics);
    });
  }
};
