import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import { Product } from '../../features/marketplace/types';

const PRODUCTS_COLLECTION = 'products';

export const marketplaceService = {
  async getProducts(): Promise<Product[]> {
    const q = query(collection(db, PRODUCTS_COLLECTION), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
  }
};
