import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, MapPin, Share, Heart, Users, BedDouble, Bath, Wifi, Car, Coffee, Wind, Tv, ShieldCheck, Sparkles, Loader2, CheckCircle2, AlertCircle, Home, Utensils, Waves, Dumbbell, ParkingCircle, ShoppingBag, Calendar, DollarSign, ListChecks, Info, ChevronRight, ArrowRight, Key, Medal, Languages, ChevronLeft, X, Grid } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from '@google/genai';
import { useAuth } from '../contexts/AuthContext';
import ReviewSection from '../components/ReviewSection';
import PaymentModal from '../components/PaymentModal';
import { getServiceById, Service } from '../infrastructure/firebase/serviceService';
import { createBooking } from '../infrastructure/firebase/bookingsService';
import { db } from '../firebase';
import { collection, query, where, getDocs, addDoc, deleteDoc, doc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import toast from 'react-hot-toast';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });

// Icon mapping for amenities
const getAmenityIcon = (name: string) => {
  const n = name.toLowerCase();
  if (n.includes('واي فاي') || n.includes('wifi')) return Wifi;
  if (n.includes('تكييف') || n.includes('ac') || n.includes('air')) return Wind;
  if (n.includes('تلفاز') || n.includes('tv') || n.includes('شاشة')) return Tv;
  if (n.includes('قهوة') || n.includes('coffee')) return Coffee;
  if (n.includes('موقف') || n.includes('parking') || n.includes('سيارات')) return Car;
  if (n.includes('أمان') || n.includes('security') || n.includes('حراسة')) return ShieldCheck;
  if (n.includes('مطبخ') || n.includes('kitchen')) return Utensils;
  if (n.includes('مسبح') || n.includes('pool') || n.includes('سباحة')) return Waves;
  if (n.includes('نادي') || n.includes('gym') || n.includes('رياضة')) return Dumbbell;
  return CheckCircle2;
};

export default function ListingDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, signInWithGoogle } = useAuth();
  const [listing, setListing] = useState<Service | null>(null);
  const [loading, setLoading] = useState(true);
  const [guests, setGuests] = useState(1);
  const [checkIn, setCheckIn] = useState<string>('');
  const [checkOut, setCheckOut] = useState<string>('');
  const [nights, setNights] = useState(1);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isBooking, setIsBooking] = useState(false);
  const [bookingStatus, setBookingStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteId, setFavoriteId] = useState<string | null>(null);
  const [isFavoriteLoading, setIsFavoriteLoading] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [showAllPhotos, setShowAllPhotos] = useState(false);

  // Calculate nights when dates change
  useEffect(() => {
    if (checkIn && checkOut) {
      const start = new Date(checkIn);
      const end = new Date(checkOut);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setNights(diffDays > 0 ? diffDays : 1);
    }
  }, [checkIn, checkOut]);

  useEffect(() => {
    const fetchListing = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const data = await getServiceById(id);
        if (data) {
          setListing(data);
        } else {
          navigate('/');
        }
      } catch (error) {
        console.error('Error fetching listing:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchListing();
  }, [id, navigate]);

  useEffect(() => {
    const generateAISummary = async () => {
      if (!listing) return;
      setIsAiLoading(true);
      try {
        const prompt = `
أنت خبير سياحي في منصة "ضيف". قم بكتابة ملخص جذاب وقصير (حوالي 3-4 أسطر) يبرز أهم مميزات هذا المكان بناءً على المعلومات التالية:
الاسم: ${listing.title}
الموقع: ${listing.location}
الوصف: ${listing.type}
المميزات: ${listing.amenities?.join('، ')}
التقييم: ${listing.rating} من ${listing.reviews} تقييم.

اجعل الملخص مشوقاً وموجهاً للزائر باللغة العربية.
`;
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: prompt,
        });
        setAiSummary(response.text || 'مكان رائع يستحق الزيارة.');
      } catch (error) {
        console.error('Error generating AI summary:', error);
      } finally {
        setIsAiLoading(false);
      }
    };

    if (listing) {
      generateAISummary();
    }
  }, [listing]);

  useEffect(() => {
    if (!user || !listing?.id) {
      setIsFavorite(false);
      setFavoriteId(null);
      return;
    }

    const q = query(
      collection(db, 'favorites'),
      where('userId', '==', user.uid),
      where('serviceId', '==', listing.id)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        setIsFavorite(true);
        setFavoriteId(snapshot.docs[0].id);
      } else {
        setIsFavorite(false);
        setFavoriteId(null);
      }
    });

    return () => unsubscribe();
  }, [user, listing?.id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!listing) return null;

  const totalBase = listing.price * nights;
  const serviceFee = Math.round(totalBase * 0.1);
  const total = totalBase + serviceFee;

  const handleBookingClick = () => {
    if (!user) {
      signInWithGoogle();
      return;
    }

    if (!checkIn || !checkOut) {
      toast.error('يرجى تحديد تواريخ الوصول والمغادرة أولاً.');
      return;
    }

    setIsPaymentModalOpen(true);
  };

  const handlePaymentSuccess = async () => {

    setIsPaymentModalOpen(false);
    setIsBooking(true);
    setBookingStatus('idle');

    try {
      await createBooking({
        serviceId: listing.id,
        serviceTitle: listing.title,
        userId: user.uid,
        userEmail: user.email || '',
        providerId: listing.authorUid,
        checkIn: checkIn,
        checkOut: checkOut,
        guests: guests,
        totalPrice: total,
        status: 'pending' // This would be 'paid' or 'escrowed' in a real app
      });
      setBookingStatus('success');
      toast.success('تم الحجز والدفع بنجاح!');
    } catch (error) {
      console.error("Booking error:", error);
      setBookingStatus('error');
      toast.error('حدث خطأ أثناء محاولة حفظ الحجز.');
    } finally {
      setIsBooking(false);
    }
  };


  const handleShare = () => {
    toast.success('تم نسخ الرابط بنجاح');
  };

  const handleSave = async () => {
    if (!user) {
      signInWithGoogle();
      return;
    }

    if (!listing?.id) return;

    setIsFavoriteLoading(true);
    try {
      if (isFavorite && favoriteId) {
        await deleteDoc(doc(db, 'favorites', favoriteId));
        toast.success('تمت الإزالة من المفضلة');
      } else {
        await addDoc(collection(db, 'favorites'), {
          userId: user.uid,
          serviceId: listing.id,
          createdAt: serverTimestamp()
        });
        toast.success('تمت الإضافة إلى المفضلة');
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
      toast.error('حدث خطأ. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsFavoriteLoading(false);
    }
  };

  return (
    <div className="pt-24 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <button onClick={() => navigate('/')} className="hover:underline">الرئيسية</button>
          <ChevronLeft className="w-3 h-3 rotate-180" />
          <span className="truncate">{listing.title}</span>
        </div>
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{listing.title}</h1>
            <div className="flex flex-wrap items-center gap-4 text-sm font-medium">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-emerald-500 fill-emerald-500" />
                <span className="text-gray-900">{listing.rating}</span>
                <span className="text-gray-500 underline cursor-pointer">({listing.reviews} تقييم)</span>
              </div>
              <span className="text-gray-300">·</span>
              <div className="flex items-center gap-1 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span className="underline cursor-pointer">{listing.location}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button onClick={handleShare} className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-700 font-medium">
              <Share className="w-4 h-4" />
              <span className="underline">مشاركة</span>
            </button>
            <button 
              onClick={handleSave} 
              disabled={isFavoriteLoading}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors font-medium ${isFavorite ? 'text-red-500' : 'text-gray-700'}`}
            >
              {isFavoriteLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
              )}
              <span className="underline">{isFavorite ? 'محفوظ' : 'حفظ'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Image Gallery - Airbnb Style */}
      <div className="relative mb-12 group">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2 h-[400px] md:h-[500px] rounded-2xl overflow-hidden">
          {/* Main Large Image */}
          <div className="md:col-span-2 h-full relative overflow-hidden">
            <img 
              src={listing.images[0]} 
              alt="Main" 
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer"
              referrerPolicy="no-referrer"
              onClick={() => setShowAllPhotos(true)}
            />
          </div>
          
          {/* Right Grid */}
          <div className="hidden md:grid grid-cols-1 gap-2 h-full">
            <div className="relative h-full overflow-hidden">
              <img 
                src={listing.images[1] || listing.images[0]} 
                alt="Gallery 1" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer" 
                referrerPolicy="no-referrer"
                onClick={() => setShowAllPhotos(true)}
              />
            </div>
            <div className="relative h-full overflow-hidden">
              <img 
                src={listing.images[2] || listing.images[0]} 
                alt="Gallery 2" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer" 
                referrerPolicy="no-referrer"
                onClick={() => setShowAllPhotos(true)}
              />
            </div>
          </div>
          
          <div className="hidden md:grid grid-cols-1 gap-2 h-full">
            <div className="relative h-full overflow-hidden">
              <img 
                src={listing.images[3] || listing.images[0]} 
                alt="Gallery 3" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer" 
                referrerPolicy="no-referrer"
                onClick={() => setShowAllPhotos(true)}
              />
            </div>
            <div className="relative h-full overflow-hidden">
              <img 
                src={listing.images[4] || listing.images[0]} 
                alt="Gallery 4" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer" 
                referrerPolicy="no-referrer"
                onClick={() => setShowAllPhotos(true)}
              />
            </div>
          </div>
        </div>
        
        <button 
          onClick={() => setShowAllPhotos(true)}
          className="absolute bottom-6 left-6 bg-white border border-gray-900 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 hover:bg-gray-50 transition-colors shadow-md z-10"
        >
          <Grid className="w-4 h-4" />
          إظهار كل الصور
        </button>
      </div>

      {/* Full Screen Photos Modal */}
      <AnimatePresence>
        {showAllPhotos && (
          <motion.div 
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed inset-0 z-[100] bg-white overflow-y-auto"
          >
            <div className="sticky top-0 bg-white/90 backdrop-blur-md z-10 p-4 border-b border-gray-100 flex justify-between items-center">
              <button 
                onClick={() => setShowAllPhotos(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              <div className="flex gap-4">
                <button onClick={handleShare} className="flex items-center gap-2 text-sm font-bold underline">مشاركة</button>
                <button onClick={handleSave} className="flex items-center gap-2 text-sm font-bold underline">حفظ</button>
              </div>
            </div>
            
            <div className="max-w-3xl mx-auto py-12 px-4">
              <div className="space-y-4">
                {listing.images.map((img, idx) => (
                  <img 
                    key={idx} 
                    src={img} 
                    alt={`Gallery ${idx}`} 
                    className="w-full rounded-lg shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Content Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Details (Right in RTL) */}
        <div className="lg:col-span-2">
          {/* Host Info */}
          <div className="flex justify-between items-start sm:items-center pb-6 border-b border-gray-200 gap-4">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold text-gray-900 mb-2 truncate">
                استضافة بواسطة {listing.host?.name || 'مضيف ضيف'}
              </h2>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-gray-600 text-sm sm:text-base">
                <span className="flex items-center gap-1 shrink-0"><Home className="w-4 h-4"/> {listing.type}</span>
                {listing.features?.map((feature, idx) => (
                  <React.Fragment key={idx}>
                    <span className="hidden sm:inline">·</span>
                    <span className="flex items-center gap-1 shrink-0"><Sparkles className="w-4 h-4"/> {feature}</span>
                  </React.Fragment>
                ))}
              </div>
            </div>
            <img 
              src={listing.host?.avatar || 'https://i.pravatar.cc/150?u=default'} 
              alt={listing.host?.name} 
              className="w-14 h-14 rounded-full object-cover shrink-0"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* AI Insights Section */}
          <div className="py-8 border-b border-gray-200">
            <div className="bg-gradient-to-br from-emerald-50 via-white to-teal-50 rounded-3xl p-8 border border-emerald-100 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-400/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
              <div className="flex flex-col sm:flex-row items-start gap-6 relative z-10">
                <div className="w-14 h-14 bg-emerald-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-emerald-200 rotate-3">
                  <Sparkles className="w-7 h-7 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-xl font-bold text-gray-900">نظرة ذكية</h3>
                    <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full font-bold tracking-wider uppercase">Gemini AI</span>
                  </div>
                  {isAiLoading ? (
                    <div className="flex items-center gap-3 text-emerald-600 mt-4">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span className="font-medium">جاري صياغة الملخص الذكي...</span>
                    </div>
                  ) : (
                    <p className="text-gray-800 leading-relaxed text-lg font-medium italic">
                      "{aiSummary}"
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="py-8 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900 mb-4">عن هذا المكان</h3>
            <p className="text-gray-600 leading-relaxed text-lg">
              {listing.title} - {listing.type} في {listing.location}. يوفر هذا المكان تجربة مميزة مع مجموعة من المرافق والخدمات.
            </p>
          </div>

          {/* Amenities */}
          <div className="py-8 border-b border-gray-200">
            <h3 className="text-xl font-bold text-gray-900 mb-6">ما يوفره هذا المكان</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {listing.amenities?.map((amenity, index) => {
                const Icon = getAmenityIcon(amenity);
                return (
                  <div key={index} className="flex items-center gap-4 text-gray-700">
                    <Icon className="w-6 h-6 text-emerald-600" />
                    <span className="text-lg">{amenity}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Host Information */}
          <div className="py-8 border-b border-gray-200">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-700 font-bold text-2xl shrink-0">
                {listing.authorUid ? listing.authorUid.charAt(0).toUpperCase() : 'H'}
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">المُضيف: {listing.authorUid ? 'مضيف محلي' : 'مضيف ضيف'}</h3>
                <p className="text-gray-500">انضم في 2023</p>
              </div>
            </div>
            <div className="flex items-center gap-6 mb-6">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-gray-900 fill-current" />
                <span className="font-bold text-gray-900">{listing.reviews} تقييم</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-gray-900" />
                <span className="font-bold text-gray-900">هوية موثقة</span>
              </div>
              <div className="flex items-center gap-2">
                <Medal className="w-5 h-5 text-gray-900" />
                <span className="font-bold text-gray-900">مضيف متميز</span>
              </div>
            </div>
            <p className="text-gray-700 leading-relaxed mb-6">
              مرحباً بك في مكاني! أسعى دائماً لتقديم أفضل تجربة للضيوف وتوفير كل ما يحتاجونه لإقامة مريحة وممتعة. لا تتردد في التواصل معي لأي استفسار.
            </p>
            <button className="px-6 py-3 border border-gray-900 rounded-xl font-bold text-gray-900 hover:bg-gray-50 transition-colors">
              تواصل مع المُضيف
            </button>
          </div>

          {/* Review Section */}
          <ReviewSection serviceId={listing.id} />

          {/* Community Integration */}
          <div className="py-8 border-t border-gray-200 mt-8">
            <div className="bg-emerald-50 rounded-3xl p-8 border border-emerald-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                  <Users className="w-6 h-6 text-emerald-600" />
                  اسأل مجتمع ضيف
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  هل لديك استفسارات حول هذا المكان أو المنطقة المحيطة به؟ تواصل مع ضيوف سابقين أو خبراء محليين في مجتمع ضيف للحصول على إجابات وتوصيات.
                </p>
              </div>
              <button 
                onClick={() => navigate('/community')}
                className="shrink-0 bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 w-full md:w-auto text-center"
              >
                اذهب إلى المجتمع
              </button>
            </div>
          </div>

          {/* Local Market Integration */}
          <div className="py-8 border-t border-gray-200">
            <div className="bg-amber-50 rounded-3xl p-8 border border-amber-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                  <ShoppingBag className="w-6 h-6 text-amber-600" />
                  تسوق منتجات محلية
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  اكتشف أفضل المنتجات المحلية في {listing.location} واطلب توصيلها مباشرة إلى مكان إقامتك أثناء رحلتك.
                </p>
              </div>
              <button 
                onClick={() => navigate('/marketplace')}
                className="shrink-0 bg-amber-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-amber-700 transition-colors shadow-lg shadow-amber-200 w-full md:w-auto text-center"
              >
                تصفح سوق ضيف
              </button>
            </div>
          </div>
        </div>

        {/* Booking Widget (Left in RTL) */}
        <div className="lg:col-span-1">
          <div className="sticky top-28 bg-white border border-gray-200 rounded-3xl p-8 shadow-2xl shadow-gray-200/50">
            <div className="flex justify-between items-end mb-8">
              <div>
                <span className="text-3xl font-bold text-gray-900">${listing.price}</span>
                <span className="text-gray-500 font-medium"> / ليلة</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm font-bold">
                <Star className="w-4 h-4 text-emerald-500 fill-emerald-500" />
                <span>{listing.rating}</span>
                <span className="text-gray-400 font-normal">({listing.reviews})</span>
              </div>
            </div>

            <div className="border-2 border-gray-100 rounded-2xl mb-6 overflow-hidden focus-within:border-emerald-500 transition-colors">
              <div className="flex border-b-2 border-gray-100">
                <div className="flex-1 p-4 border-l-2 border-gray-100 relative hover:bg-gray-50 transition-colors">
                  <label htmlFor="checkin" className="block text-[10px] font-black text-gray-900 uppercase tracking-widest mb-1">تسجيل الوصول</label>
                  <input 
                    type="date" 
                    id="checkin"
                    className="w-full bg-transparent outline-none text-gray-900 font-bold text-sm cursor-pointer"
                    value={checkIn}
                    min={new Date().toISOString().split('T')[0]}
                    onChange={(e) => setCheckIn(e.target.value)}
                  />
                </div>
                <div className="flex-1 p-4 relative hover:bg-gray-50 transition-colors">
                  <label htmlFor="checkout" className="block text-[10px] font-black text-gray-900 uppercase tracking-widest mb-1">المغادرة</label>
                  <input 
                    type="date" 
                    id="checkout"
                    className="w-full bg-transparent outline-none text-gray-900 font-bold text-sm cursor-pointer"
                    value={checkOut}
                    min={checkIn || new Date().toISOString().split('T')[0]}
                    onChange={(e) => setCheckOut(e.target.value)}
                  />
                </div>
              </div>
              <div className="p-4 hover:bg-gray-50 transition-colors">
                <label htmlFor="guests" className="block text-[10px] font-black text-gray-900 uppercase tracking-widest mb-1">الضيوف</label>
                <select 
                  id="guests"
                  className="w-full bg-transparent outline-none text-gray-900 font-bold text-sm cursor-pointer"
                  value={guests}
                  onChange={(e) => setGuests(Number(e.target.value))}
                >
                  <option value={1}>ضيف واحد</option>
                  <option value={2}>ضيفان</option>
                  <option value={3}>3 ضيوف</option>
                  <option value={4}>4 ضيوف</option>
                  <option value={5}>5 ضيوف</option>
                  <option value={6}>6 ضيوف</option>
                </select>
              </div>
            </div>

            <button 
              onClick={handleBookingClick}
              disabled={isBooking || bookingStatus === 'success'}
              className={`w-full py-4 rounded-2xl font-bold text-lg transition-all mb-4 flex items-center justify-center gap-2 shadow-lg ${
                bookingStatus === 'success' 
                  ? 'bg-emerald-100 text-emerald-700 cursor-default' 
                  : 'bg-emerald-600 text-white hover:bg-emerald-700 active:scale-[0.98] shadow-emerald-200'
              }`}
            >
              {isBooking ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>جاري المعالجة...</span>
                </>
              ) : bookingStatus === 'success' ? (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  <span>تم الحجز بنجاح!</span>
                </>
              ) : (
                'احجز الآن'
              )}
            </button>
            
            <p className="text-center text-gray-400 text-xs mb-8">لن يتم خصم أي مبلغ منك في هذه المرحلة</p>
            
            <div className="space-y-4 text-gray-700 font-medium">
              <div className="flex justify-between">
                <span className="underline decoration-gray-300 underline-offset-4">${listing.price} × {nights} ليالي</span>
                <span>${totalBase}</span>
              </div>
              <div className="flex justify-between">
                <span className="underline decoration-gray-300 underline-offset-4">رسوم خدمة ضيف</span>
                <span>${serviceFee}</span>
              </div>
            </div>

            <div className="border-t-2 border-gray-100 mt-8 pt-8 flex justify-between font-black text-xl text-gray-900">
              <span>الإجمالي</span>
              <span>${total}</span>
            </div>

            {/* Escrow Badge */}
            <div className="mt-8 bg-blue-50/50 border border-blue-100 rounded-2xl p-4 flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-sm font-bold text-blue-900 mb-1">حماية ضيف المالية</div>
                <div className="text-[11px] text-blue-700 leading-relaxed">يتم الاحتفاظ بأموالك في حساب وسيط (Escrow) ولا يتم تحويلها للمزود إلا بعد إتمام الخدمة.</div>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <button className="text-gray-500 hover:text-gray-900 underline text-sm font-medium flex items-center justify-center gap-2 mx-auto">
              <AlertCircle className="w-4 h-4" />
              الإبلاغ عن هذا المكان
            </button>
          </div>

          {/* Planning Tools Widget */}
          <div className="mt-8 bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <ListChecks className="w-5 h-5 text-emerald-600" />
              أدوات التخطيط
            </h3>
            <div className="space-y-4">
              <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-gray-400 group-hover:text-emerald-600" />
                  <span className="text-sm font-medium text-gray-700">بناء برنامج الرحلة</span>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-300 rotate-180" />
              </button>
              <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-5 h-5 text-gray-400 group-hover:text-emerald-600" />
                  <span className="text-sm font-medium text-gray-700">تقدير الميزانية الكلية</span>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-300 rotate-180" />
              </button>
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                <div className="flex items-center gap-2 text-amber-800 font-bold text-xs mb-1">
                  <Info className="w-3 h-3" />
                  نصيحة ضيف
                </div>
                <p className="text-[11px] text-amber-700 leading-relaxed">
                  هذا المكان قريب من 3 معالم سياحية مشهورة. ننصح بحجز جولة سياحية معه لتوفير الوقت.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <PaymentModal 
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        amount={total}
        onSuccess={handlePaymentSuccess}
        title={`الدفع لحجز: ${listing.title}`}
      />
    </div>
  );
}
