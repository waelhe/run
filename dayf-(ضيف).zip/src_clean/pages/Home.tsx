import React from 'react';
import Hero from '../components/Hero';
import Categories from '../components/Categories';
import ServiceSection from '../components/ServiceSection';
import CommunityHighlights from '../components/CommunityHighlights';
import MarketHighlights from '../components/MarketHighlights';
import { useLanguage } from '../contexts/LanguageContext';

export default function Home() {
  const { language } = useLanguage();

  return (
    <main className="space-y-4">
      <Hero />
      <Categories />
      
      <div className="pb-12">
        <ServiceSection 
          title={language === 'ar' ? 'بيوت رائعة في ميامي' : 'Great homes in Miami'}
          filterPopular={true}
          viewAllPath="/category/tourism"
        />

        <ServiceSection 
          title={language === 'ar' ? 'فنادق مميزة في ميامي' : 'Featured hotels in Miami'}
          subtitle={language === 'ar' ? 'مجموعة من الفنادق المستقلة والمختارة بعناية' : 'A curated collection of independent hotels'}
          categoryId="tourism"
          limit={8}
          viewAllPath="/category/tourism"
        />

        <ServiceSection 
          title={language === 'ar' ? 'تجارب فريدة' : 'Unique experiences'}
          categoryId="experiences"
          limit={8}
          viewAllPath="/category/experiences"
        />

        <ServiceSection 
          title={language === 'ar' ? 'خدمات طبية متميزة' : 'Top medical services'}
          subtitle={language === 'ar' ? 'أفضل المراكز الطبية والأطباء في سوريا' : 'The best medical centers and doctors in Syria'}
          categoryId="medical"
          limit={8}
          viewAllPath="/category/medical"
        />

        <ServiceSection 
          title={language === 'ar' ? 'فرص عقارية' : 'Real Estate Opportunities'}
          subtitle={language === 'ar' ? 'اكتشف أفضل العقارات المتاحة للبيع والإيجار' : 'Discover the best properties available for sale and rent'}
          categoryId="realestate"
          limit={8}
          viewAllPath="/category/realestate"
        />

        <ServiceSection 
          title={language === 'ar' ? 'خدمات الأعمال' : 'Business Services'}
          subtitle={language === 'ar' ? 'حلول احترافية لنمو أعمالك' : 'Professional solutions for your business growth'}
          categoryId="business"
          limit={8}
          viewAllPath="/category/business"
        />

        <ServiceSection 
          title={language === 'ar' ? 'تعليم وتدريب' : 'Education & Training'}
          subtitle={language === 'ar' ? 'طور مهاراتك مع أفضل الخبراء' : 'Develop your skills with the best experts'}
          categoryId="education"
          limit={8}
          viewAllPath="/category/education"
        />

        <MarketHighlights />
        <CommunityHighlights />
      </div>
    </main>
  );
}
