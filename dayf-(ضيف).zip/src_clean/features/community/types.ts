export interface CommunityTopic {
  id?: string;
  title: string;
  content: string;
  categoryId: string;
  authorUid: string;
  authorName: string;
  authorAvatar?: string;
  likesCount: number;
  repliesCount: number;
  isOfficial?: boolean;
  createdAt: any;
}

export interface CommunityReply {
  id?: string;
  topicId: string;
  content: string;
  authorUid: string;
  authorName: string;
  authorAvatar?: string;
  likesCount: number;
  createdAt: any;
}
