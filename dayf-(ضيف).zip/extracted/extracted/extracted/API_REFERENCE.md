# 📡 مرجع واجهات البرمجة (API Reference) - مشروع "ضيف"

## 📋 نظرة عامة

### عنوان الأساسي (Base URL)
```
https://api.dayf.syria
```

### الإصدار الحالي
```
v1
```

### التنسيق
- **الطلبات**: JSON
- **الاستجابات**: JSON
- **الترميز**: UTF-8

---

## 🔐 المصادقة

### رمز Bearer Token
```http
Authorization: Bearer <access_token>
```

### رمز التحديث (Refresh Token)
```http
POST /api/auth/refresh
Content-Type: application/json

{
  "refreshToken": "<refresh_token>"
}
```

---

## 📝 اصطلاحات API

### رموز الحالة HTTP

| الرمز | المعنى | الاستخدام |
|-------|--------|----------|
| 200 | OK | نجاح العملية |
| 201 | Created | إنشاء عنصر جديد |
| 204 | No Content | نجاح بدون محتوى |
| 400 | Bad Request | بيانات غير صالحة |
| 401 | Unauthorized | غير مصادق |
| 403 | Forbidden | غير مصرح |
| 404 | Not Found | غير موجود |
| 409 | Conflict | تعارض |
| 422 | Unprocessable Entity | فشل التحقق |
| 429 | Too Many Requests | تجاوز الحد |
| 500 | Internal Server Error | خطأ خادم |

### تنسيق الاستجابة

#### نجاح
```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "timestamp": "2025-01-01T00:00:00Z",
    "requestId": "abc123"
  }
}
```

#### خطأ
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "البيانات غير صالحة",
    "details": [
      {
        "field": "email",
        "message": "البريد الإلكتروني غير صالح"
      }
    ]
  },
  "meta": {
    "timestamp": "2025-01-01T00:00:00Z",
    "requestId": "abc123"
  }
}
```

---

## 🔐 المصادقة (Auth)

### POST /api/auth/register
تسجيل مستخدم جديد

#### الطلب
```json
{
  "email": "user@example.com",
  "phone": "+963912345678",
  "password": "SecurePass123!",
  "firstName": "أحمد",
  "lastName": "محمد",
  "preferredLanguage": "ar"
}
```

#### الاستجابة (201)
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "clx123456",
      "email": "user@example.com",
      "phone": "+963912345678",
      "firstName": "أحمد",
      "lastName": "محمد",
      "role": "USER",
      "status": "PENDING",
      "createdAt": "2025-01-01T00:00:00Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600
  }
}
```

---

### POST /api/auth/login
تسجيل الدخول

#### الطلب
```json
{
  "identifier": "user@example.com",
  "password": "SecurePass123!"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "clx123456",
      "email": "user@example.com",
      "firstName": "أحمد",
      "lastName": "محمد",
      "role": "USER",
      "status": "ACTIVE",
      "membershipLevel": "BRONZE",
      "loyaltyPoints": 100
    },
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600
  }
}
```

---

### POST /api/auth/otp/send
إرسال رمز التحقق

#### الطلب
```json
{
  "phone": "+963912345678",
  "type": "LOGIN"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "message": "تم إرسال الرمز بنجاح",
    "expiresIn": 300,
    "retryAfter": 60
  }
}
```

---

### POST /api/auth/otp/verify
التحقق من الرمز

#### الطلب
```json
{
  "phone": "+963912345678",
  "code": "123456"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "verified": true,
    "user": { ... },
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "isNewUser": false
  }
}
```

---

### GET /api/auth/oauth/{provider}
توجيه لمزود OAuth

#### المسارات المتاحة
- `/api/auth/oauth/google`
- `/api/auth/oauth/apple`
- `/api/auth/oauth/facebook`

#### الاستجابة (302)
```
Location: https://accounts.google.com/o/oauth2/v2/auth?...
```

---

### GET /api/auth/oauth/callback/{provider}
رد الاتصال من مزود OAuth

#### المعاملات
- `code`: رمز التفويض
- `state`: حالة الأمان

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "user": { ... },
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "isNewUser": true
  }
}
```

---

### POST /api/auth/logout
تسجيل الخروج

#### الرؤوس
```
Authorization: Bearer <token>
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "message": "تم تسجيل الخروج بنجاح"
  }
}
```

---

### POST /api/auth/refresh
تحديث الرمز

#### الطلب
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIs..."
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
    "expiresIn": 3600
  }
}
```

---

### POST /api/auth/password/reset-request
طلب إعادة تعيين كلمة المرور

#### الطلب
```json
{
  "email": "user@example.com"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "message": "تم إرسال رابط إعادة التعيين",
    "expiresIn": 3600
  }
}
```

---

### POST /api/auth/password/reset
إعادة تعيين كلمة المرور

#### الطلب
```json
{
  "token": "reset_token_here",
  "newPassword": "NewSecurePass123!"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "message": "تم تغيير كلمة المرور بنجاح"
  }
}
```

---

## 👤 الملف الشخصي (Profile)

### GET /api/profile
الحصول على الملف الشخصي

#### الرؤوس
```
Authorization: Bearer <token>
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "clx123456",
      "email": "user@example.com",
      "phone": "+963912345678",
      "firstName": "أحمد",
      "lastName": "محمد",
      "displayName": "أحمد محمد",
      "avatar": "https://cdn.dayf.syria/avatars/abc.jpg",
      "bio": "مسافر ومحب للاستكشاف",
      "dateOfBirth": "1990-01-01",
      "gender": "MALE",
      "nationality": "SY",
      "country": "Syria",
      "city": "دمشق",
      "membershipLevel": "GOLD",
      "loyaltyPoints": 2500,
      "stats": {
        "totalBookings": 15,
        "totalReviews": 12,
        "totalSpent": 15000
      },
      "preferences": {
        "language": "ar",
        "currency": "SYP",
        "notifications": {
          "email": true,
          "push": true,
          "sms": false
        }
      }
    }
  }
}
```

---

### PUT /api/profile
تحديث الملف الشخصي

#### الطلب
```json
{
  "firstName": "أحمد",
  "lastName": "علي",
  "displayName": "أحمد علي",
  "bio": "مسافر شغوف",
  "gender": "MALE",
  "nationality": "SY",
  "country": "Syria",
  "city": "دمشق"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "user": { ... }
  }
}
```

---

### POST /api/profile/avatar
رفع صورة الملف الشخصي

#### الطلب
```
Content-Type: multipart/form-data

avatar: <file>
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "avatar": "https://cdn.dayf.syria/avatars/abc.jpg"
  }
}
```

---

### PUT /api/profile/password
تغيير كلمة المرور

#### الطلب
```json
{
  "currentPassword": "OldPass123!",
  "newPassword": "NewPass456!"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "message": "تم تغيير كلمة المرور بنجاح"
  }
}
```

---

### GET /api/profile/verification
حالة التحقق

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "verifications": [
      {
        "id": "clx123",
        "type": "IDENTITY",
        "status": "APPROVED",
        "verifiedAt": "2025-01-01T00:00:00Z"
      },
      {
        "id": "clx124",
        "type": "PHONE",
        "status": "APPROVED"
      }
    ]
  }
}
```

---

### POST /api/profile/verification
طلب تحقق جديد

#### الطلب
```
Content-Type: multipart/form-data

type: IDENTITY
documentType: PASSPORT
documentFile: <file>
documentNumber: A12345678
```

#### الاستجابة (201)
```json
{
  "success": true,
  "data": {
    "verification": {
      "id": "clx125",
      "type": "IDENTITY",
      "status": "PENDING",
      "createdAt": "2025-01-01T00:00:00Z"
    }
  }
}
```

---

## 🌍 الوجهات (Destinations)

### GET /api/destinations
قائمة الوجهات

#### المعاملات
| المعامل | النوع | مطلوب | الوصف |
|---------|-------|--------|--------|
| page | number | لا | رقم الصفحة (افتراضي: 1) |
| limit | number | لا | عدد العناصر (افتراضي: 20) |
| type | string | لا | نوع الوجهة |
| city | string | لا | المدينة |
| region | string | لا | المنطقة |
| search | string | لا | نص البحث |
| sortBy | string | لا | الترتيب (rating, popularity, name) |

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "destinations": [
      {
        "id": "clx123",
        "name": "قلعة حلب",
        "slug": "aleppo-citadel",
        "shortDescription": "أحد أقدم القلاع في العالم",
        "type": "HISTORICAL",
        "city": "حلب",
        "featuredImage": "https://cdn.dayf.syria/destinations/abc.jpg",
        "avgRating": 4.8,
        "totalReviews": 256,
        "entryFee": 500
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 150,
      "totalPages": 8,
      "hasNext": true,
      "hasPrev": false
    },
    "filters": {
      "types": ["TOURISM", "CULTURAL", "RELIGIOUS"],
      "cities": ["دمشق", "حلب", "اللاذقية"]
    }
  }
}
```

---

### GET /api/destinations/{id}
تفاصيل وجهة

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "destination": {
      "id": "clx123",
      "name": "قلعة حلب",
      "slug": "aleppo-citadel",
      "description": "قلعة حلب هي واحدة من أقدم وأكبر القلاع في العالم...",
      "type": "HISTORICAL",
      "subTypes": ["FORTRESS", "MONUMENT"],
      "tags": ["آثار", "تاريخ", "تصوير"],
      "city": "حلب",
      "address": "قلعة حلب، حلب، سوريا",
      "latitude": 36.2021,
      "longitude": 37.1343,
      "images": [
        "https://cdn.dayf.syria/destinations/abc1.jpg",
        "https://cdn.dayf.syria/destinations/abc2.jpg"
      ],
      "videoUrl": "https://cdn.dayf.syria/videos/abc.mp4",
      "avgRating": 4.8,
      "totalReviews": 256,
      "viewCount": 15000,
      "bestSeason": ["SPRING", "AUTUMN"],
      "openingHours": {
        "saturday": "09:00-18:00",
        "sunday": "09:00-18:00",
        "monday": "09:00-18:00"
      },
      "entryFee": 500,
      "amenities": ["parking", "guided_tours", "gift_shop"],
      "accessibility": ["wheelchair_access", "audio_guides"]
    },
    "highlights": [
      {
        "id": "clx1",
        "title": "المدخل الرئيسي",
        "description": "البوابة التاريخية...",
        "image": "https://cdn.dayf.syria/highlights/abc.jpg"
      }
    ],
    "relatedListings": [ ... ],
    "relatedActivities": [ ... ]
  }
}
```

---

## 🏨 الإقامات (Listings)

### GET /api/listings
قائمة الإقامات

#### المعاملات
| المعامل | النوع | مطلوب | الوصف |
|---------|-------|--------|--------|
| page | number | لا | رقم الصفحة |
| limit | number | لا | عدد العناصر |
| type | string | لا | نوع الإقامة |
| city | string | لا | المدينة |
| destinationId | string | لا | معرف الوجهة |
| checkIn | date | لا | تاريخ الوصول |
| checkOut | date | لا | تاريخ المغادرة |
| guests | number | لا | عدد الضيوف |
| minPrice | number | لا | الحد الأدنى للسعر |
| maxPrice | number | لا | الحد الأقصى للسعر |
| amenities | string[] | لا | المرافق |
| search | string | لا | نص البحث |
| sortBy | string | لا | الترتيب |

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "listings": [
      {
        "id": "clx123",
        "title": "شقة فاخرة في قلب دمشق",
        "slug": "luxury-apartment-damascus",
        "type": "APARTMENT",
        "city": "دمشق",
        "featuredImage": "https://cdn.dayf.syria/listings/abc.jpg",
        "basePrice": 15000,
        "currency": "SYP",
        "maxGuests": 4,
        "bedrooms": 2,
        "bathrooms": 1,
        "avgRating": 4.9,
        "totalReviews": 45,
        "amenities": ["wifi", "kitchen", "parking", "ac"]
      }
    ],
    "pagination": { ... },
    "priceRange": {
      "min": 5000,
      "max": 150000
    }
  }
}
```

---

### GET /api/listings/{id}
تفاصيل إقامة

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "listing": {
      "id": "clx123",
      "title": "شقة فاخرة في قلب دمشق",
      "slug": "luxury-apartment-damascus",
      "description": "شقة مفروشة بالكامل...",
      "summary": "شقة فاخرة لـ 4 أشخاص",
      "type": "APARTMENT",
      "subTypes": ["LUXURY", "CITY_CENTER"],
      "tags": ["عائلي", "هادئ", "مركزي"],
      "address": {
        "country": "Syria",
        "city": "دمشق",
        "address": "شارع الثورة، المزة",
        "latitude": 33.5138,
        "longitude": 36.2765
      },
      "size": 120,
      "maxGuests": 4,
      "bedrooms": 2,
      "beds": 3,
      "bathrooms": 1,
      "basePrice": 15000,
      "weekendPrice": 20000,
      "weeklyDiscount": 0.1,
      "monthlyDiscount": 0.2,
      "cleaningFee": 2000,
      "serviceFee": 0.05,
      "currency": "SYP",
      "minNights": 2,
      "maxNights": 30,
      "checkInTime": "15:00",
      "checkOutTime": "11:00",
      "amenities": [
        { "id": "wifi", "name": "واي فاي", "available": true },
        { "id": "kitchen", "name": "مطبخ", "available": true },
        { "id": "parking", "name": "موقف سيارات", "available": true }
      ],
      "houseRules": [
        "ممنوع التدخين",
        "ممنوع الحفلات",
        "مسموح بالأطفال"
      ],
      "images": [ ... ],
      "virtualTourUrl": "https://tour.dayf.syria/abc",
      "avgRating": 4.9,
      "totalReviews": 45,
      "instantBook": true
    },
    "host": {
      "id": "clx456",
      "firstName": "محمد",
      "lastName": "أحمد",
      "avatar": "https://cdn.dayf.syria/avatars/host.jpg",
      "responseRate": 95,
      "responseTime": 30,
      "hostingSince": "2020-01-01",
      "totalListings": 3
    },
    "availability": [ ... ],
    "reviews": { ... }
  }
}
```

---

### POST /api/listings/{id}/availability
التحقق من التوفر

#### الطلب
```json
{
  "checkIn": "2025-06-01",
  "checkOut": "2025-06-05",
  "guests": 2
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "available": true,
    "price": {
      "basePrice": 60000,
      "nights": 4,
      "cleaningFee": 2000,
      "serviceFee": 3000,
      "taxes": 5200,
      "total": 70200,
      "currency": "SYP"
    },
    "blockedDates": []
  }
}
```

---

### POST /api/listings
إنشاء إقامة جديدة (مضيف)

#### الطلب
```
Content-Type: multipart/form-data

title: شقة فاخرة في دمشق
description: شقة مفروشة بالكامل...
type: APARTMENT
address: شارع الثورة، المزة
city: دمشق
basePrice: 15000
maxGuests: 4
bedrooms: 2
beds: 3
bathrooms: 1
amenities: ["wifi", "kitchen", "parking"]
images: <files[]>
```

#### الاستجابة (201)
```json
{
  "success": true,
  "data": {
    "listing": {
      "id": "clx123",
      "title": "شقة فاخرة في دمشق",
      "status": "PENDING",
      "createdAt": "2025-01-01T00:00:00Z"
    }
  }
}
```

---

### PUT /api/listings/{id}
تحديث إقامة

#### الطلب
```json
{
  "title": "شقة فاخرة جداً في دمشق",
  "basePrice": 18000,
  "amenities": ["wifi", "kitchen", "parking", "ac"]
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "listing": { ... }
  }
}
```

---

### DELETE /api/listings/{id}
حذف إقامة

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "message": "تم حذف الإقامة بنجاح"
  }
}
```

---

## 📅 الحجوزات (Bookings)

### POST /api/bookings/calculate
حساب السعر

#### الطلب
```json
{
  "listingId": "clx123",
  "checkIn": "2025-06-01",
  "checkOut": "2025-06-05",
  "guests": 2,
  "extras": ["early_checkin", "airport_transfer"]
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "breakdown": {
      "basePrice": 60000,
      "nights": 4,
      "weeklyDiscount": 6000,
      "cleaningFee": 2000,
      "serviceFee": 2700,
      "extras": {
        "early_checkin": 2500,
        "airport_transfer": 5000
      },
      "taxes": 4980,
      "total": 70680,
      "currency": "SYP"
    }
  }
}
```

---

### POST /api/bookings
إنشاء حجز

#### الطلب
```json
{
  "listingId": "clx123",
  "checkIn": "2025-06-01",
  "checkOut": "2025-06-05",
  "guests": [
    {
      "firstName": "أحمد",
      "lastName": "محمد",
      "email": "user@example.com",
      "phone": "+963912345678",
      "isPrimary": true
    }
  ],
  "specialRequests": "أحتاج سرير إضافي للأطفال",
  "paymentMethod": "CREDIT_CARD",
  "promoCode": "SUMMER2025"
}
```

#### الاستجابة (201)
```json
{
  "success": true,
  "data": {
    "booking": {
      "id": "clx789",
      "bookingNumber": "DAY-2025-001234",
      "status": "PENDING",
      "checkIn": "2025-06-01",
      "checkOut": "2025-06-05",
      "totalPrice": 70680,
      "currency": "SYP"
    },
    "payment": {
      "id": "clx890",
      "amount": 70680,
      "status": "PENDING",
      "paymentUrl": "https://payment.dayf.syria/pay/abc123"
    }
  }
}
```

---

### GET /api/bookings
قائمة الحجوزات

#### المعاملات
| المعامل | النوع | الوصف |
|---------|-------|--------|
| status | string | حالة الحجز |
| upcoming | boolean | الحجوزات القادمة |
| past | boolean | الحجوزات السابقة |
| page | number | رقم الصفحة |
| limit | number | عدد العناصر |

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "bookings": [
      {
        "id": "clx789",
        "bookingNumber": "DAY-2025-001234",
        "status": "CONFIRMED",
        "checkIn": "2025-06-01",
        "checkOut": "2025-06-05",
        "guests": 2,
        "totalPrice": 70680,
        "listing": {
          "id": "clx123",
          "title": "شقة فاخرة في دمشق",
          "featuredImage": "https://cdn.dayf.syria/listings/abc.jpg",
          "city": "دمشق"
        }
      }
    ],
    "pagination": { ... }
  }
}
```

---

### GET /api/bookings/{id}
تفاصيل حجز

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "booking": {
      "id": "clx789",
      "bookingNumber": "DAY-2025-001234",
      "status": "CONFIRMED",
      "checkIn": "2025-06-01",
      "checkOut": "2025-06-05",
      "guests": 2,
      "specialRequests": "أحتاج سرير إضافي",
      "totalPrice": 70680,
      "currency": "SYP",
      "createdAt": "2025-05-15T10:00:00Z",
      "confirmedAt": "2025-05-15T10:30:00Z"
    },
    "listing": { ... },
    "host": { ... },
    "payments": [ ... ],
    "escrow": {
      "id": "clx999",
      "status": "FUNDED",
      "amount": 70680
    }
  }
}
```

---

### POST /api/bookings/{id}/cancel
إلغاء حجز

#### الطلب
```json
{
  "reason": "تغيرت خطط السفر"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "booking": {
      "id": "clx789",
      "status": "CANCELLED",
      "cancelledAt": "2025-05-20T15:00:00Z"
    },
    "refund": {
      "id": "clx111",
      "amount": 53010,
      "status": "PROCESSING",
      "reason": "إلغاء قبل 7 أيام"
    },
    "cancellationPolicy": {
      "type": "MODERATE",
      "refundPercentage": 75,
      "description": "استرداد 75% عند الإلغاء قبل 5 أيام"
    }
  }
}
```

---

## 💰 المدفوعات (Payments)

### POST /api/payments
بدء دفع

#### الطلب
```json
{
  "bookingId": "clx789",
  "method": "CREDIT_CARD",
  "amount": 70680
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "payment": {
      "id": "clx890",
      "paymentNumber": "PAY-2025-001234",
      "amount": 70680,
      "currency": "SYP",
      "method": "CREDIT_CARD",
      "status": "PENDING"
    },
    "paymentUrl": "https://payment.dayf.syria/pay/abc123",
    "redirectUrl": "https://dayf.syria/booking/confirmed"
  }
}
```

---

### POST /api/payments/{id}/confirm
تأكيد الدفع

#### الطلب
```json
{
  "transactionId": "TXN123456",
  "providerData": {
    "status": "success",
    "cardLastFour": "4242"
  }
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "payment": {
      "id": "clx890",
      "status": "PAID",
      "paidAt": "2025-05-15T10:00:00Z"
    },
    "booking": {
      "id": "clx789",
      "status": "CONFIRMED"
    },
    "escrow": {
      "id": "clx999",
      "status": "FUNDED"
    }
  }
}
```

---

## ⚖️ المنازعات (Disputes)

### POST /api/disputes
فتح منازعة

#### الطلب
```json
{
  "bookingId": "clx789",
  "type": "LISTING_NOT_AS_DESCRIBED",
  "reason": "الإقامة مختلفة عن الصور",
  "description": "الشقة ليست كما ظهرت في الصور...",
  "evidence": ["https://cdn.dayf.syria/evidence/1.jpg"]
}
```

#### الاستجابة (201)
```json
{
  "success": true,
  "data": {
    "dispute": {
      "id": "clx222",
      "disputeNumber": "DSP-2025-001234",
      "status": "OPENED",
      "type": "LISTING_NOT_AS_DESCRIBED",
      "createdAt": "2025-06-02T10:00:00Z"
    }
  }
}
```

---

### GET /api/disputes/{id}
تفاصيل منازعة

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "dispute": {
      "id": "clx222",
      "disputeNumber": "DSP-2025-001234",
      "status": "NEGOTIATING",
      "type": "LISTING_NOT_AS_DESCRIBED",
      "reason": "الإقامة مختلفة عن الصور",
      "description": "...",
      "disputedAmount": 70680,
      "evidence": [ ... ],
      "createdAt": "2025-06-02T10:00:00Z"
    },
    "messages": [
      {
        "id": "clx333",
        "senderId": "clx123",
        "message": "أقدم اعتذاري عن...",
        "createdAt": "2025-06-02T11:00:00Z"
      }
    ],
    "timeline": [
      {
        "action": "OPENED",
        "date": "2025-06-02T10:00:00Z"
      },
      {
        "action": "NEGOTIATING",
        "date": "2025-06-02T10:30:00Z"
      }
    ]
  }
}
```

---

### POST /api/disputes/{id}/messages
إضافة رسالة

#### الطلب
```json
{
  "message": "أرفقت صوراً إضافية توضح المشكلة",
  "attachments": ["https://cdn.dayf.syria/evidence/2.jpg"]
}
```

#### الاستجابة (201)
```json
{
  "success": true,
  "data": {
    "message": {
      "id": "clx334",
      "message": "أرفقت صوراً إضافية...",
      "createdAt": "2025-06-02T12:00:00Z"
    }
  }
}
```

---

## ⭐ التقييمات (Reviews)

### POST /api/reviews
إنشاء تقييم

#### الطلب
```json
{
  "bookingId": "clx789",
  "rating": 5,
  "ratings": {
    "cleanliness": 5,
    "location": 4,
    "value": 5,
    "communication": 5
  },
  "title": "تجربة رائعة!",
  "content": "كانت الإقامة ممتازة، المضيف متعاون جداً...",
  "images": ["https://cdn.dayf.syria/reviews/1.jpg"]
}
```

#### الاستجابة (201)
```json
{
  "success": true,
  "data": {
    "review": {
      "id": "clx444",
      "reviewNumber": "REV-2025-001234",
      "status": "PENDING",
      "rating": 5,
      "createdAt": "2025-06-06T10:00:00Z"
    }
  }
}
```

---

### GET /api/reviews
قائمة التقييمات

#### المعاملات
| المعامل | النوع | الوصف |
|---------|-------|--------|
| listingId | string | معرف الإقامة |
| activityId | string | معرف النشاط |
| userId | string | معرف المستخدم |
| rating | number | التقييم |
| sortBy | string | recent, rating, helpful |
| page | number | رقم الصفحة |
| limit | number | عدد العناصر |

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "reviews": [
      {
        "id": "clx444",
        "rating": 5,
        "ratings": {
          "cleanliness": 5,
          "location": 4,
          "value": 5,
          "communication": 5
        },
        "title": "تجربة رائعة!",
        "content": "كانت الإقامة ممتازة...",
        "images": [ ... ],
        "user": {
          "id": "clx123",
          "firstName": "أحمد",
          "avatar": "..."
        },
        "reply": {
          "content": "شكراً لتقييمك...",
          "createdAt": "2025-06-07T10:00:00Z"
        },
        "helpfulCount": 15,
        "createdAt": "2025-06-06T10:00:00Z"
      }
    ],
    "summary": {
      "avgRating": 4.8,
      "totalReviews": 45,
      "ratingDistribution": {
        "5": 30,
        "4": 10,
        "3": 3,
        "2": 1,
        "1": 1
      },
      "categoryAverages": {
        "cleanliness": 4.9,
        "location": 4.7,
        "value": 4.8,
        "communication": 4.9
      }
    },
    "pagination": { ... }
  }
}
```

---

## 🔍 البحث (Search)

### GET /api/search
بحث عام

#### المعاملات
| المعامل | النوع | الوصف |
|---------|-------|--------|
| q | string | نص البحث |
| type | string | all, listings, destinations, activities |
| page | number | رقم الصفحة |
| limit | number | عدد العناصر |

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "results": {
      "listings": [ ... ],
      "destinations": [ ... ],
      "activities": [ ... ]
    },
    "total": 250,
    "query": "دمشق",
    "suggestions": ["شقة في دمشق", "فندق دمشق", "جولة في دمشق"]
  }
}
```

---

## 🤖 الذكاء الاصطناعي (AI)

### POST /api/ai/chat
محادثة مع المساعد

#### الطلب
```json
{
  "message": "أبحث عن فندق في دمشق لعائلة من 4 أشخاص",
  "context": {
    "conversationId": "conv123"
  },
  "language": "ar"
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "response": "سأساعدك في العثور على إقامة مناسبة لعائلتك في دمشق. هل تفضل فندق أم شقة مفروشة؟",
    "suggestions": [
      "فندق 4 نجوم",
      "شقة مفروشة",
      "فيلا خاصة"
    ],
    "actions": [
      {
        "type": "search",
        "params": {
          "city": "دمشق",
          "guests": 4
        }
      }
    ]
  }
}
```

---

### POST /api/ai/recommendations
توصيات شخصية

#### الطلب
```json
{
  "preferences": {
    "destination": "دمشق",
    "budget": 50000,
    "interests": ["التاريخ", "الطعام"],
    "travelStyle": "عائلي"
  }
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "recommendations": [
      {
        "type": "listing",
        "id": "clx123",
        "title": "شقة عائلية في دمشق القديمة",
        "matchScore": 95,
        "reasons": ["تناسب الميزانية", "قريبة من المعالم التاريخية"]
      }
    ]
  }
}
```

---

### POST /api/ai/plan-trip
تخطيط رحلة

#### الطلب
```json
{
  "destination": "دمشق",
  "dates": {
    "start": "2025-07-01",
    "end": "2025-07-05"
  },
  "budget": 200000,
  "interests": ["التاريخ", "الطعام", "التسوق"],
  "travelers": {
    "adults": 2,
    "children": 2
  }
}
```

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "plan": {
      "id": "plan123",
      "title": "رحلة عائلية إلى دمشق",
      "days": [
        {
          "date": "2025-07-01",
          "activities": [
            {
              "time": "14:00",
              "activity": "الوصول وتسجيل الدخول",
              "location": "شقة دمشق القديمة"
            },
            {
              "time": "17:00",
              "activity": "جولة في سوق الحميدية",
              "duration": "2 ساعات"
            }
          ]
        }
      ],
      "estimatedCost": 185000
    },
    "alternatives": [ ... ]
  }
}
```

---

## 🔔 الإشعارات (Notifications)

### GET /api/notifications
قائمة الإشعارات

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "notifications": [
      {
        "id": "clx555",
        "type": "BOOKING_CONFIRMED",
        "title": "تم تأكيد الحجز",
        "message": "تم تأكيد حجزك في شقة دمشق",
        "link": "/bookings/clx789",
        "read": false,
        "createdAt": "2025-05-15T10:30:00Z"
      }
    ],
    "unreadCount": 5,
    "pagination": { ... }
  }
}
```

---

### POST /api/notifications/{id}/read
تحديد كمقروء

#### الاستجابة (200)
```json
{
  "success": true,
  "data": {
    "notification": {
      "id": "clx555",
      "read": true,
      "readAt": "2025-05-15T11:00:00Z"
    }
  }
}
```

---

## 📐 أنواع البيانات الشائعة

### Address
```typescript
interface Address {
  country: string;
  region?: string;
  city: string;
  address: string;
  postalCode?: string;
  latitude?: number;
  longitude?: number;
}
```

### PriceBreakdown
```typescript
interface PriceBreakdown {
  basePrice: number;
  nights?: number;
  weeklyDiscount?: number;
  monthlyDiscount?: number;
  cleaningFee?: number;
  serviceFee?: number;
  taxes?: number;
  extras?: Record<string, number>;
  total: number;
  currency: string;
}
```

### Pagination
```typescript
interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}
```

### Error
```typescript
interface APIError {
  code: string;
  message: string;
  details?: Array<{
    field: string;
    message: string;
  }>;
}
```

---

## 🚦 حدود الطلبات (Rate Limits)

| نوع المستخدم | الحد |
|--------------|------|
| غير مصادق | 100 طلب/ساعة |
| مستخدم عادي | 500 طلب/ساعة |
| مضيف | 1000 طلب/ساعة |
| شركة | 2000 طلب/ساعة |
| مدير | 5000 طلب/ساعة |

### رؤوس الاستجابة
```
X-RateLimit-Limit: 500
X-RateLimit-Remaining: 450
X-RateLimit-Reset: 1620000000
```

---

## 🔒 الأمان

### CORS
```
Access-Control-Allow-Origin: https://dayf.syria
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH
Access-Control-Allow-Headers: Authorization, Content-Type
```

### CSP
```
Content-Security-Policy: default-src 'self'; ...
```

### HTTPS
جميع الطلبات يجب أن تكون عبر HTTPS في الإنتاج.

---

*آخر تحديث: 2025*
