# 🎯 الميزات والوظائف - مشروع "ضيف"

## 📋 نظرة عامة

هذا المستند يوضح جميع الميزات والوظائف المتاحة في المنصة، مقسمة حسب الأولوية والحالة.

---

## 🚦 حالات الميزات

| الرمز | الحالة |
|-------|--------|
| 🔴 | مطلوب أساساً - المرحلة الأولى |
| 🟡 | مهم - المرحلة الثانية |
| 🟢 | إضافي - المرحلة الثالثة |
| ⚪ | مخطط للمستقبل |

---

## 🔐 نظام المصادقة

### 🔴 المصادقة الأساسية

#### تسجيل بحساب جديد
```yaml
المسار: /auth/register
الطريقة: POST

البيانات المطلوبة:
  - email: string (اختياري)
  - phone: string (اختياري)
  - password: string (8+ حروف، حرف كبير، رقم)
  - firstName: string
  - lastName: string

الاستجابة:
  - user: User
  - token: string
  - refreshToken: string

التحقق:
  - البريد أو الهاتف على الأقل
  - عدم تكرار البريد/الهاتف
  - إرسال رمز التحقق
```

#### تسجيل الدخول
```yaml
المسار: /auth/login
الطريقة: POST

البيانات المطلوبة:
  - identifier: string (بريد أو هاتف)
  - password: string

الاستجابة:
  - user: User
  - token: string
  - refreshToken: string
```

#### تسجيل الخروج
```yaml
المسار: /auth/logout
الطريقة: POST

الرؤوس:
  - Authorization: Bearer {token}

الاستجابة:
  - success: boolean
```

### 🔴 المصادقة بـ OTP

#### إرسال رمز التحقق
```yaml
المسار: /auth/otp/send
الطريقة: POST

البيانات المطلوبة:
  - phone: string

الاستجابة:
  - success: boolean
  - expiresIn: number (ثواني)

القواعد:
  - صلاحية الرمز: 5 دقائق
  - حد الإرسال: 3 محاولات/ساعة
```

#### التحقق من الرمز
```yaml
المسار: /auth/otp/verify
الطريقة: POST

البيانات المطلوبة:
  - phone: string
  - code: string (6 أرقام)

الاستجابة:
  - verified: boolean
  - user?: User
  - token?: string
```

### 🔴 المصادقة بـ OAuth

#### توجيه للمزود
```yaml
المسار: /auth/oauth/{provider}
الطريقة: GET

المزودين المتاحين:
  - google
  - apple
  - facebook

الاستجابة:
  - redirectUrl: string
  - state: string (للتحقق)
```

#### رد الاتصال
```yaml
المسار: /auth/oauth/callback/{provider}
الطريقة: GET

المعاملات:
  - code: string
  - state: string

الاستجابة:
  - user: User
  - token: string
  - isNewUser: boolean
```

### 🔴 استعادة كلمة المرور

#### طلب إعادة التعيين
```yaml
المسار: /auth/password/reset-request
الطريقة: POST

البيانات المطلوبة:
  - email?: string
  - phone?: string

الاستجابة:
  - success: boolean
  - expiresIn: number
```

#### إعادة تعيين كلمة المرور
```yaml
المسار: /auth/password/reset
الطريقة: POST

البيانات المطلوبة:
  - token: string
  - newPassword: string

الاستجابة:
  - success: boolean
```

---

## 👤 الملف الشخصي

### 🔴 إدارة الملف الشخصي

#### الحصول على الملف
```yaml
المسار: /api/profile
الطريقة: GET

الاستجابة:
  - user: User
  - stats: UserStats
  - preferences: UserPreferences
```

#### تحديث الملف
```yaml
المسار: /api/profile
الطريقة: PUT

البيانات المطلوبة:
  - firstName?: string
  - lastName?: string
  - displayName?: string
  - bio?: string
  - avatar?: File
  - dateOfBirth?: Date
  - gender?: Gender
  - nationality?: string
  - address?: Address

الاستجابة:
  - user: User
```

#### تغيير كلمة المرور
```yaml
المسار: /api/profile/password
الطريقة: PUT

البيانات المطلوبة:
  - currentPassword: string
  - newPassword: string

الاستجابة:
  - success: boolean
```

### 🔴 التحقق من الهوية

#### طلب التحقق
```yaml
المسار: /api/profile/verification
الطريقة: POST

البيانات المطلوبة:
  - type: VerificationType
  - documentType: string
  - documentFile: File
  - documentNumber?: string

الاستجابة:
  - verification: UserVerification
```

#### حالة التحقق
```yaml
المسار: /api/profile/verification
الطريقة: GET

الاستجابة:
  - verifications: UserVerification[]
```

---

## 🏢 إدارة الشركات

### 🔴 إنشاء شركة

#### تسجيل شركة جديدة
```yaml
المسار: /api/companies
الطريقة: POST

البيانات المطلوبة:
  - name: string
  - type: CompanyType
  - description: string
  - email: string
  - phone: string
  - address: Address
  - documents: File[]

الاستجابة:
  - company: Company
```

### 🔴 إدارة الشركة

#### الحصول على الشركة
```yaml
المسار: /api/companies/{id}
الطريقة: GET

الاستجابة:
  - company: Company
  - stats: CompanyStats
```

#### تحديث الشركة
```yaml
المسار: /api/companies/{id}
الطريقة: PUT

البيانات المطلوبة:
  - name?: string
  - description?: string
  - logo?: File
  - coverImage?: File
  - website?: string
  - socialLinks?: SocialLinks

الاستجابة:
  - company: Company
```

### 🟡 إدارة الموظفين

#### دعوة موظف
```yaml
المسار: /api/companies/{id}/employees
الطريقة: POST

البيانات المطلوبة:
  - email: string
  - role: EmployeeRole
  - permissions: string[]

الاستجابة:
  - invitation: EmployeeInvitation
```

#### قبول الدعوة
```yaml
المسار: /api/companies/invitations/{token}/accept
الطريقة: POST

الاستجابة:
  - employee: CompanyEmployee
```

---

## 🌍 السياحة

### 🔴 الوجهات

#### قائمة الوجهات
```yaml
المسار: /api/destinations
الطريقة: GET

المعاملات:
  - page: number (default: 1)
  - limit: number (default: 20)
  - type?: DestinationType
  - city?: string
  - region?: string
  - search?: string
  - sortBy?: 'rating' | 'popularity' | 'name'
  - sortOrder?: 'asc' | 'desc'

الاستجابة:
  - destinations: Destination[]
  - pagination: Pagination
  - filters: AppliedFilters
```

#### تفاصيل وجهة
```yaml
المسار: /api/destinations/{id}
الطريقة: GET

الاستجابة:
  - destination: Destination
  - highlights: DestinationHighlight[]
  - relatedListings: Listing[]
  - relatedActivities: Activity[]
  - reviews: Review[]
```

### 🔴 الإقامات

#### قائمة الإقامات
```yaml
المسار: /api/listings
الطريقة: GET

المعاملات:
  - page: number
  - limit: number
  - type?: ListingType
  - city?: string
  - destinationId?: string
  - checkIn?: Date
  - checkOut?: Date
  - guests?: number
  - minPrice?: number
  - maxPrice?: number
  - amenities?: string[]
  - search?: string
  - sortBy?: 'price' | 'rating' | 'popularity'

الاستجابة:
  - listings: Listing[]
  - pagination: Pagination
  - priceRange: PriceRange
```

#### تفاصيل إقامة
```yaml
المسار: /api/listings/{id}
الطريقة: GET

الاستجابة:
  - listing: Listing
  - host: User
  - availability: AvailabilityCalendar[]
  - reviews: Review[]
  - similarListings: Listing[]
```

#### التحقق من التوفر
```yaml
المسار: /api/listings/{id}/availability
الطريقة: POST

البيانات المطلوبة:
  - checkIn: Date
  - checkOut: Date
  - guests: number

الاستجابة:
  - available: boolean
  - price: PriceBreakdown
  - blockedDates: Date[]
```

### 🔴 إدارة الإقامات (للمضيفين)

#### إنشاء إقامة
```yaml
المسار: /api/listings
الطريقة: POST

البيانات المطلوبة:
  - title: string
  - description: string
  - type: ListingType
  - address: Address
  - basePrice: number
  - amenities: string[]
  - images: File[]
  - maxGuests: number
  - bedrooms: number
  - beds: number
  - bathrooms: number

الاستجابة:
  - listing: Listing
```

#### تحديث إقامة
```yaml
المسار: /api/listings/{id}
الطريقة: PUT

البيانات المطلوبة:
  - (أي حقل قابل للتحديث)

الاستجابة:
  - listing: Listing
```

#### حذف إقامة
```yaml
المسار: /api/listings/{id}
الطريقة: DELETE

الاستجابة:
  - success: boolean
```

#### تحديث التقويم
```yaml
المسار: /api/listings/{id}/calendar
الطريقة: PUT

البيانات المطلوبة:
  - dates: CalendarUpdate[]

الاستجابة:
  - calendar: AvailabilityCalendar[]
```

### 🔴 الأنشطة

#### قائمة الأنشطة
```yaml
المسار: /api/activities
الطريقة: GET

المعاملات:
  - page: number
  - limit: number
  - type?: ActivityType
  - destinationId?: string
  - date?: Date
  - minPrice?: number
  - maxPrice?: number
  - search?: string

الاستجابة:
  - activities: Activity[]
  - pagination: Pagination
```

#### تفاصيل نشاط
```yaml
المسار: /api/activities/{id}
الطريقة: GET

الاستجابة:
  - activity: Activity
  - provider: User | Company
  - reviews: Review[]
  - availableSlots: AvailableSlot[]
```

---

## 📅 الحجوزات

### 🔴 إنشاء حجز

#### حساب السعر
```yaml
المسار: /api/bookings/calculate
الطريقة: POST

البيانات المطلوبة:
  - listingId?: string
  - activityId?: string
  - checkIn?: Date
  - checkOut?: Date
  - guests: number
  - extras?: ExtraService[]

الاستجابة:
  - breakdown: PriceBreakdown
  - total: number
  - currency: string
```

#### إنشاء الحجز
```yaml
المسار: /api/bookings
الطريقة: POST

البيانات المطلوبة:
  - listingId?: string
  - activityId?: string
  - checkIn?: Date
  - checkOut?: Date
  - guests: GuestDetails[]
  - specialRequests?: string
  - paymentMethod: PaymentMethod

الاستجابة:
  - booking: Booking
  - paymentUrl?: string (للدفع الخارجي)
```

### 🔴 إدارة الحجوزات

#### حجوزات المستخدم
```yaml
المسار: /api/bookings
الطريقة: GET

المعاملات:
  - status?: BookingStatus
  - upcoming?: boolean
  - past?: boolean
  - page: number
  - limit: number

الاستجابة:
  - bookings: Booking[]
  - pagination: Pagination
```

#### تفاصيل الحجز
```yaml
المسار: /api/bookings/{id}
الطريقة: GET

الاستجابة:
  - booking: Booking
  - listing?: Listing
  - activity?: Activity
  - payments: Payment[]
  - escrow?: Escrow
```

#### إلغاء الحجز
```yaml
المسار: /api/bookings/{id}/cancel
الطريقة: POST

البيانات المطلوبة:
  - reason: string

الاستجابة:
  - booking: Booking
  - refund?: Refund
  - cancellationPolicy: CancellationPolicy
```

### 🔴 حجوزات المضيف

#### حجوزات الواردة
```yaml
المسار: /api/host/bookings
الطريقة: GET

المعاملات:
  - status?: BookingStatus
  - listingId?: string
  - dateFrom?: Date
  - dateTo?: Date
  - page: number
  - limit: number

الاستجابة:
  - bookings: Booking[]
  - stats: BookingStats
  - pagination: Pagination
```

#### تأكيد/رفض الحجز
```yaml
المسار: /api/host/bookings/{id}/respond
الطريقة: POST

البيانات المطلوبة:
  - action: 'accept' | 'reject'
  - message?: string

الاستجابة:
  - booking: Booking
```

---

## 💰 المدفوعات

### 🔴 الدفع

#### بدء الدفع
```yaml
المسار: /api/payments
الطريقة: POST

البيانات المطلوبة:
  - bookingId: string
  - method: PaymentMethod
  - amount: number

الاستجابة:
  - payment: Payment
  - paymentUrl?: string
  - redirectUrl?: string
```

#### تأكيد الدفع
```yaml
المسار: /api/payments/{id}/confirm
الطريقة: POST

البيانات المطلوبة:
  - transactionId?: string
  - providerData?: any

الاستجابة:
  - payment: Payment
  - booking: Booking
```

### 🟡 الاسترداد

#### طلب استرداد
```yaml
المسار: /api/payments/{id}/refund
الطريقة: POST

البيانات المطلوبة:
  - reason: string
  - amount?: number (استرداد جزئي)

الاستجابة:
  - refund: Refund
```

---

## 💳 نظام الضمان

### 🔴 إنشاء الضمان

```yaml
المسار: /api/escrow
الطريقة: POST

البيانات المطلوبة:
  - bookingId: string
  - amount: number

الاستجابة:
  - escrow: Escrow
```

### 🔴 إدارة الضمان

#### حالة الضمان
```yaml
المسار: /api/escrow/{id}
الطريقة: GET

الاستجابة:
  - escrow: Escrow
  - transactions: EscrowTransaction[]
```

#### إطلاق المبلغ
```yaml
المسار: /api/escrow/{id}/release
الطريقة: POST

البيانات المطلوبة:
  - amount?: number (إطلاق جزئي)

الاستجابة:
  - escrow: Escrow
  - transaction: EscrowTransaction
```

---

## ⚖️ المنازعات

### 🔴 فتح منازعة

```yaml
المسار: /api/disputes
الطريقة: POST

البيانات المطلوبة:
  - bookingId: string
  - type: DisputeType
  - reason: string
  - description: string
  - evidence: File[]

الاستجابة:
  - dispute: Dispute
```

### 🔴 إدارة المنازعة

#### تفاصيل المنازعة
```yaml
المسار: /api/disputes/{id}
الطريقة: GET

الاستجابة:
  - dispute: Dispute
  - messages: DisputeMessage[]
  - timeline: DisputeTimeline
```

#### إضافة رسالة
```yaml
المسار: /api/disputes/{id}/messages
الطريقة: POST

البيانات المطلوبة:
  - message: string
  - attachments?: File[]

الاستجابة:
  - message: DisputeMessage
```

#### تصعيد المنازعة
```yaml
المسار: /api/disputes/{id}/escalate
الطريقة: POST

البيانات المطلوبة:
  - reason: string

الاستجابة:
  - dispute: Dispute
```

### 🟡 حل المنازعة (إدارة)

```yaml
المسار: /api/admin/disputes/{id}/resolve
الطريقة: POST

البيانات المطلوبة:
  - decision: DisputeDecision
  - reasoning: string
  - refundAmount?: number
  - actions?: string[]

الاستجابة:
  - dispute: Dispute
  - resolution: DisputeResolution
```

---

## ⭐ التقييمات

### 🔴 إنشاء تقييم

```yaml
المسار: /api/reviews
الطريقة: POST

البيانات المطلوبة:
  - bookingId: string
  - rating: number (1-5)
  - ratings?: RatingBreakdown
  - title?: string
  - content: string
  - images?: File[]

الاستجابة:
  - review: Review
```

### 🔴 عرض التقييمات

#### تقييمات إقامة
```yaml
المسار: /api/listings/{id}/reviews
الطريقة: GET

المعاملات:
  - page: number
  - limit: number
  - sortBy?: 'recent' | 'rating' | 'helpful'
  - rating?: number

الاستجابة:
  - reviews: Review[]
  - summary: ReviewSummary
  - pagination: Pagination
```

### 🟡 الرد على التقييم

```yaml
المسار: /api/reviews/{id}/reply
الطريقة: POST

البيانات المطلوبة:
  - reply: string

الاستجابة:
  - review: Review
```

### 🟡 تفاعل مع التقييم

```yaml
المسار: /api/reviews/{id}/helpful
الطريقة: POST

البيانات المطلوبة:
  - helpful: boolean

الاستجابة:
  - review: Review
```

---

## 🏆 برنامج الولاء

### 🟡 نقاط الولاء

#### رصيد النقاط
```yaml
المسار: /api/loyalty/balance
الطريقة: GET

الاستجابة:
  - balance: number
  - level: MembershipLevel
  - pointsToNextLevel: number
  - benefits: Benefit[]
```

#### سجل النقاط
```yaml
المسار: /api/loyalty/transactions
الطريقة: GET

المعاملات:
  - type?: LoyaltyTransactionType
  - page: number
  - limit: number

الاستجابة:
  - transactions: LoyaltyTransaction[]
  - pagination: Pagination
```

### 🟡 استبدال النقاط

```yaml
المسار: /api/loyalty/redeem
الطريقة: POST

البيانات المطلوبة:
  - points: number
  - type: 'discount' | 'upgrade' | 'experience'

الاستجابة:
  - redemption: LoyaltyRedemption
  - code?: string (كود الخصم)
```

---

## 🎁 العروض

### 🟡 العروض المتاحة

#### قائمة العروض
```yaml
المسار: /api/offers
الطريقة: GET

المعاملات:
  - type?: OfferType
  - applicableTo?: string
  - page: number
  - limit: number

الاستجابة:
  - offers: Offer[]
  - pagination: Pagination
```

#### التحقق من كود الخصم
```yaml
المسار: /api/offers/validate
الطريقة: POST

البيانات المطلوبة:
  - code: string
  - bookingId?: string
  - amount: number

الاستجابة:
  - valid: boolean
  - discount: number
  - offer: Offer
```

---

## 👥 المجتمع

### 🟢 المنشورات

#### إنشاء منشور
```yaml
المسار: /api/posts
الطريقة: POST

البيانات المطلوبة:
  - content: string
  - images?: File[]
  - video?: File
  - category?: string
  - tags?: string[]
  - location?: string

الاستجابة:
  - post: Post
```

#### قائمة المنشورات
```yaml
المسار: /api/posts
الطريقة: GET

المعاملات:
  - category?: string
  - tag?: string
  - userId?: string
  - sortBy?: 'recent' | 'popular'
  - page: number
  - limit: number

الاستجابة:
  - posts: Post[]
  - pagination: Pagination
```

### 🟢 التعليقات

```yaml
المسار: /api/posts/{id}/comments
الطريقة: POST

البيانات المطلوبة:
  - content: string
  - parentId?: string

الاستجابة:
  - comment: Comment
```

### 🟢 الإعجابات

```yaml
المسار: /api/{type}/{id}/like
الطريقة: POST

البيانات المطلوبة:
  - like: boolean

الاستجابة:
  - likeCount: number
```

---

## 🤖 وكيل الذكاء الاصطناعي

### 🔴 المساعد الذكي

#### المحادثة
```yaml
المسار: /api/ai/chat
الطريقة: POST

البيانات المطلوبة:
  - message: string
  - context?: ChatContext
  - language?: string

الاستجابة:
  - response: string
  - suggestions?: string[]
  - actions?: AIAction[]
```

#### التوصيات
```yaml
المسار: /api/ai/recommendations
الطريقة: POST

البيانات المطلوبة:
  - preferences: UserPreferences
  - context?: RecommendationContext

الاستجابة:
  - recommendations: Recommendation[]
```

#### تخطيط الرحلة
```yaml
المسار: /api/ai/plan-trip
الطريقة: POST

البيانات المطلوبة:
  - destination?: string
  - dates: DateRange
  - budget?: number
  - interests?: string[]
  - travelers: TravelerInfo

الاستجابة:
  - plan: TripPlan
  - alternatives: TripPlan[]
```

---

## 🔔 الإشعارات

### 🔴 الإشعارات

#### قائمة الإشعارات
```yaml
المسار: /api/notifications
الطريقة: GET

المعاملات:
  - unread?: boolean
  - type?: NotificationType
  - page: number
  - limit: number

الاستجابة:
  - notifications: Notification[]
  - unreadCount: number
  - pagination: Pagination
```

#### تحديد كمقروء
```yaml
المسار: /api/notifications/{id}/read
الطريقة: POST

الاستجابة:
  - notification: Notification
```

#### تحديد الكل كمقروء
```yaml
المسار: /api/notifications/read-all
الطريقة: POST

الاستجابة:
  - success: boolean
```

### 🔴 إعدادات الإشعارات

```yaml
المسار: /api/notifications/preferences
الطريقة: GET/PUT

البيانات (PUT):
  - emailEnabled: boolean
  - pushEnabled: boolean
  - smsEnabled: boolean
  - bookingEmails: boolean
  - marketingEmails: boolean
  - reviewEmails: boolean

الاستجابة:
  - preferences: NotificationPreference
```

---

## 🔍 البحث

### 🔴 البحث العام

```yaml
المسار: /api/search
الطريقة: GET

المعاملات:
  - q: string (الاستعلام)
  - type?: 'all' | 'listings' | 'destinations' | 'activities'
  - filters?: SearchFilters
  - page: number
  - limit: number

الاستجابة:
  - results: SearchResult[]
  - facets: SearchFacets
  - pagination: Pagination
```

### 🔴 البحث المتقدم

```yaml
المسار: /api/search/advanced
الطريقة: POST

البيانات المطلوبة:
  - query?: string
  - location?: LocationFilter
  - dates?: DateRange
  - guests?: number
  - price?: PriceRange
  - amenities?: string[]
  - rating?: number
  - type?: string[]

الاستجابة:
  - results: SearchResult[]
  - map?: MapData
```

---

## 📊 التقارير

### 🟡 تقارير المستخدم

#### إحصائيات الحساب
```yaml
المسار: /api/user/stats
الطريقة: GET

الاستجابة:
  - totalBookings: number
  - totalSpent: number
  - totalReviews: number
  - pointsEarned: number
  - pointsUsed: number
  - countriesVisited: number
```

### 🟡 تقارير المضيف

#### لوحة التحكم
```yaml
المسار: /api/host/dashboard
الطريقة: GET

المعاملات:
  - period?: 'day' | 'week' | 'month' | 'year'

الاستجابة:
  - earnings: EarningsStats
  - bookings: BookingStats
  - occupancy: OccupancyStats
  - reviews: ReviewStats
```

#### التقارير المالية
```yaml
المسار: /api/host/reports/financial
الطريقة: GET

المعاملات:
  - from: Date
  - to: Date
  - format?: 'json' | 'csv'

الاستجابة:
  - report: FinancialReport
```

---

## 🔧 الإدارة

### 🔴 إدارة المستخدمين

#### قائمة المستخدمين
```yaml
المسار: /api/admin/users
الطريقة: GET

المعاملات:
  - role?: Role
  - status?: UserStatus
  - search?: string
  - page: number
  - limit: number

الاستجابة:
  - users: User[]
  - pagination: Pagination
```

#### تحديث حالة المستخدم
```yaml
المسار: /api/admin/users/{id}/status
الطريقة: PUT

البيانات المطلوبة:
  - status: UserStatus
  - reason?: string

الاستجابة:
  - user: User
```

### 🔴 إدارة الشركات

#### قائمة الشركات المعلقة
```yaml
المسار: /api/admin/companies/pending
الطريقة: GET

الاستجابة:
  - companies: Company[]
```

#### التحقق من شركة
```yaml
المسار: /api/admin/companies/{id}/verify
الطريقة: POST

البيانات المطلوبة:
  - verified: boolean
  - reason?: string

الاستجابة:
  - company: Company
```

### 🔴 إدارة المحتوى

#### المحتوى المعلق
```yaml
المسار: /api/admin/content/pending
الطريقة: GET

المعاملات:
  - type: 'listings' | 'reviews' | 'posts'
  - page: number
  - limit: number

الاستجابة:
  - items: ContentItem[]
  - pagination: Pagination
```

#### مراجعة المحتوى
```yaml
المسار: /api/admin/content/{type}/{id}/review
الطريقة: POST

البيانات المطلوبة:
  - action: 'approve' | 'reject'
  - reason?: string

الاستجابة:
  - item: ContentItem
```

---

## 🌐 التعدد اللغوي

### 🟡 اللغات

#### الحصول على الترجمات
```yaml
المسار: /api/translations/{language}/{namespace}
الطريقة: GET

الاستجابة:
  - translations: TranslationMap
```

#### تغيير اللغة
```yaml
المسار: /api/user/language
الطريقة: PUT

البيانات المطلوبة:
  - language: string

الاستجابة:
  - success: boolean
```

---

## 📱 WebSocket Events

### 🔴 أحداث الوقت الحقيقي

#### الاتصال
```javascript
// إنشاء اتصال WebSocket
const socket = io('/?XTransformPort=3003');

// أحداث الاتصال
socket.on('connect', () => {});
socket.on('disconnect', () => {});
```

#### الإشعارات
```javascript
// استقبال إشعار جديد
socket.on('notification', (notification) => {});

// تحديث عدد الإشعارات
socket.on('notification:count', (count) => {});
```

#### الرسائل
```javascript
// رسالة جديدة
socket.on('message:new', (message) => {});

// حالة الكتابة
socket.on('message:typing', (data) => {});
```

#### الحجوزات
```javascript
// تحديث حالة الحجز
socket.on('booking:update', (booking) => {});

// حجز جديد (للمضيف)
socket.on('booking:new', (booking) => {});
```

---

## 🔐 الصلاحيات

### 🔴 مصفوفة الصلاحيات

| العملية | GUEST | USER | HOST | COMPANY | ADMIN |
|---------|-------|------|------|---------|-------|
| تصفح المحتوى | ✅ | ✅ | ✅ | ✅ | ✅ |
| البحث | ✅ | ✅ | ✅ | ✅ | ✅ |
| الحجز | ❌ | ✅ | ✅ | ✅ | ✅ |
| إضافة إقامة | ❌ | ❌ | ✅ | ✅ | ✅ |
| إدارة شركة | ❌ | ❌ | ❌ | ✅ | ✅ |
| إدارة المستخدمين | ❌ | ❌ | ❌ | ❌ | ✅ |
| التحقق من الشركات | ❌ | ❌ | ❌ | ❌ | ✅ |
| حل المنازعات | ❌ | ❌ | ❌ | ❌ | ✅ |

---

## 📐 أنواع البيانات

### Address
```typescript
interface Address {
  country: string;
  region?: string;
  city: string;
  address: string;
  postalCode?: string;
  latitude?: number;
  longitude?: number;
}
```

### PriceBreakdown
```typescript
interface PriceBreakdown {
  basePrice: number;
  nights: number;
  cleaningFee: number;
  serviceFee: number;
  taxes: number;
  discount: number;
  total: number;
  currency: string;
}
```

### Pagination
```typescript
interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}
```

### GuestDetails
```typescript
interface GuestDetails {
  firstName: string;
  lastName: string;
  email?: string;
  phone?: string;
  dateOfBirth?: Date;
  nationality?: string;
}
```

---

## 🚨 رموز الأخطاء

| الرمز | الوصف |
|-------|-------|
| 400 | طلب غير صالح |
| 401 | غير مصادق |
| 403 | غير مصرح |
| 404 | غير موجود |
| 409 | تعارض (مثل: حجز مكرر) |
| 422 | بيانات غير صالحة |
| 429 | تجاوز حد الطلبات |
| 500 | خطأ في الخادم |

---

*آخر تحديث: 2025*
