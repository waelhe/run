# 📐 Architecture Document - مشروع "ضيف"

## 🎯 نظرة عامة

مشروع **"ضيف"** هو منصة سياحية سورية شاملة تقدم تجربة متكاملة للزوار، تجمع بين:
- 🏨 حجز الإقامات والفنادق
- 🌍 تنظيم الرحلات السياحية
- 🏥 الخدمات العلاجية
- 📚 الفرص التعليمية
- 💼 فرص العمل والاستثمار

---

## 🏗️ المبادئ المعمارية الأساسية (Architecture Guardian)

### 1. فصل الاهتمامات (Separation of Concerns)
```
كل ميزة لها مساحة خاصة ومستقلة
لا تتداخل الميزات في منطق بعضها البعض
```

### 2. Loose Coupling (الارتباط المفكك)
```
الميزات تتواصل عبر الأحداث والواجهات
لا توجد استيرادات مباشرة بين الميزات
```

### 3. Dependency Inversion (عكس التبعية)
```
الميزات تعتمد على التجريدات وليس التطبيقات
الواجهات تُعرَّف في طبقة domain
```

### 4. Single Responsibility (مسؤولية واحدة)
```
كل مكون له سبب واحد للتغيير
كل خدمة تقوم بمهمة محددة بوضوح
```

### 5. Open/Closed Principle
```
النظام مفتوح للامتداد
مغلق للتعديل على الكود الموجود
```

---

## 📁 هيكلية المشروع

```
src/
├── 📦 core/                          # النواة الأساسية
│   ├── 📂 domain/                    # طبقة المجال
│   │   ├── entities/                 # الكيانات الأساسية
│   │   │   ├── User.ts               # كيان المستخدم
│   │   │   ├── Company.ts            # كيان الشركة
│   │   │   ├── Booking.ts            # كيان الحجز
│   │   │   └── Transaction.ts        # كيان المعاملة
│   │   │
│   │   ├── value-objects/            # كائنات القيمة
│   │   │   ├── Money.ts              # كائن المال
│   │   │   ├── Address.ts            # كائن العنوان
│   │   │   ├── Phone.ts              # كائن الهاتف
│   │   │   └── Rating.ts             # كائن التقييم
│   │   │
│   │   ├── interfaces/               # واجهات المجال
│   │   │   ├── repositories/         # واجهات المستودعات
│   │   │   ├── services/             # واجهات الخدمات
│   │   │   └── events/               # واجهات الأحداث
│   │   │
│   │   └── rules/                    # قواعد العمل
│   │       ├── booking-rules.ts      # قواعد الحجز
│   │       ├── payment-rules.ts      # قواعد الدفع
│   │       └── cancellation-rules.ts # قواعد الإلغاء
│   │
│   ├── 📂 events/                    # نظام الأحداث
│   │   ├── event-bus.ts              # ناقل الأحداث
│   │   ├── event-types.ts            # أنواع الأحداث
│   │   ├── event-handler.ts          # معالج الأحداث
│   │   └── subscribers/              # المشتركين في الأحداث
│   │       ├── booking.subscriber.ts
│   │       ├── payment.subscriber.ts
│   │       └── notification.subscriber.ts
│   │
│   └── 📂 ports/                     # منافذ التكامل
│       ├── payment.port.ts           # منفذ الدفع
│       ├── notification.port.ts      # منفذ الإشعارات
│       └── storage.port.ts           # منفذ التخزين
│
├── 🎨 features/                      # الميزات المستقلة
│   │
│   ├── 🔐 auth/                      # المصادقة
│   │   ├── domain/
│   │   │   ├── entities/
│   │   │   ├── interfaces/
│   │   │   └── rules/
│   │   ├── application/
│   │   │   ├── services/
│   │   │   │   ├── auth.service.ts
│   │   │   │   ├── oauth.service.ts
│   │   │   │   └── otp.service.ts
│   │   │   └── use-cases/
│   │   ├── infrastructure/
│   │   │   ├── repositories/
│   │   │   └── adapters/
│   │   ├── api/
│   │   │   └── routes/
│   │   │       ├── login.route.ts
│   │   │       ├── register.route.ts
│   │   │       ├── oauth.route.ts
│   │   │       └── otp.route.ts
│   │   └── ui/
│   │       ├── components/
│   │       ├── hooks/
│   │       └── pages/
│   │
│   ├── 👤 profile/                   # الملف الشخصي
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 🏢 company/                   # إدارة الشركات
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 🌍 tourism/                   # السياحة
│   │   ├── domain/
│   │   │   ├── entities/
│   │   │   │   ├── Destination.ts
│   │   │   │   ├── Accommodation.ts
│   │   │   │   ├── Activity.ts
│   │   │   │   └── Tour.ts
│   │   │   ├── interfaces/
│   │   │   └── rules/
│   │   ├── application/
│   │   │   ├── services/
│   │   │   │   ├── destination.service.ts
│   │   │   │   ├── accommodation.service.ts
│   │   │   │   └── activity.service.ts
│   │   │   └── use-cases/
│   │   ├── infrastructure/
│   │   │   ├── repositories/
│   │   │   └── adapters/
│   │   ├── api/
│   │   │   └── routes/
│   │   │       ├── destinations.route.ts
│   │   │       ├── accommodations.route.ts
│   │   │       └── activities.route.ts
│   │   └── ui/
│   │       ├── components/
│   │       │   ├── DestinationCard.tsx
│   │       │   ├── AccommodationCard.tsx
│   │       │   └── ActivityCard.tsx
│   │       ├── hooks/
│   │       └── pages/
│   │
│   ├── 🏥 medical/                   # العلاج
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 📚 education/                 # الدراسة
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 💼 business/                  # العمل والاستثمار
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 📅 booking/                   # الحجوزات
│   │   ├── domain/
│   │   │   ├── entities/
│   │   │   │   ├── Booking.ts
│   │   │   │   ├── BookingItem.ts
│   │   │   │   └── BookingStatus.ts
│   │   │   ├── interfaces/
│   │   │   └── rules/
│   │   │       ├── availability.rules.ts
│   │   │       └── pricing.rules.ts
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 💰 escrow/                    # الضمان المالي
│   │   ├── domain/
│   │   ├── application/
│   │   │   ├── services/
│   │   │   │   ├── escrow.service.ts
│   │   │   │   └── release.service.ts
│   │   │   └── use-cases/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── ⚖️ disputes/                  # المنازعات
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── ⭐ reviews/                   # التقييمات
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 👥 community/                 # المجتمع
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 🛒 marketplace/               # السوق
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   ├── 🎁 offers/                    # العروض
│   │   ├── domain/
│   │   ├── application/
│   │   ├── infrastructure/
│   │   ├── api/
│   │   └── ui/
│   │
│   └── 🏆 loyalty/                   # برنامج الولاء
│       ├── domain/
│       ├── application/
│       ├── infrastructure/
│       ├── api/
│       └── ui/
│
├── 🔧 infrastructure/                # البنية التحتية
│   ├── database/
│   │   ├── prisma/
│   │   │   └── schema.prisma
│   │   └── migrations/
│   │
│   ├── services/
│   │   ├── ai/                       # خدمات الذكاء الاصطناعي
│   │   │   ├── assistant.service.ts
│   │   │   ├── recommendation.service.ts
│   │   │   └── chat.service.ts
│   │   │
│   │   ├── payment/                  # خدمات الدفع
│   │   │   ├── payment-gateway.ts
│   │   │   └── payment-processor.ts
│   │   │
│   │   ├── notification/             # خدمات الإشعارات
│   │   │   ├── email.service.ts
│   │   │   ├── sms.service.ts
│   │   │   └── push.service.ts
│   │   │
│   │   └── storage/                  # خدمات التخزين
│   │       ├── file-storage.ts
│   │       └── image-processor.ts
│   │
│   └── adapters/
│       ├── payment.adapter.ts
│       ├── notification.adapter.ts
│       └── storage.adapter.ts
│
├── 🎨 shared/                        # المشتركات
│   ├── components/
│   │   ├── ui/                       # مكونات shadcn/ui
│   │   ├── layout/
│   │   │   ├── Header.tsx
│   │   │   ├── Footer.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   └── Navigation.tsx
│   │   └── common/
│   │       ├── Loading.tsx
│   │       ├── Error.tsx
│   │       ├── Empty.tsx
│   │       └── ConfirmDialog.tsx
│   │
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useToast.ts
│   │   ├── useLoading.ts
│   │   └── usePagination.ts
│   │
│   ├── utils/
│   │   ├── formatters.ts
│   │   ├── validators.ts
│   │   ├── constants.ts
│   │   └── helpers.ts
│   │
│   └── types/
│       ├── common.types.ts
│       ├── api.types.ts
│       └── errors.types.ts
│
├── 📱 app/                           # Next.js App Router
│   ├── (auth)/
│   │   ├── login/
│   │   ├── register/
│   │   └── forgot-password/
│   │
│   ├── (dashboard)/
│   │   ├── dashboard/
│   │   ├── profile/
│   │   ├── bookings/
│   │   └── settings/
│   │
│   ├── (host)/
│   │   ├── host/
│   │   ├── properties/
│   │   └── analytics/
│   │
│   ├── (public)/
│   │   ├── destinations/
│   │   ├── accommodations/
│   │   ├── activities/
│   │   └── search/
│   │
│   ├── api/
│   │   ├── auth/
│   │   ├── bookings/
│   │   ├── accommodations/
│   │   └── [...]/                    # باقي الـ API routes
│   │
│   ├── layout.tsx
│   └── page.tsx
│
└── 🤖 ai-agent/                      # وكيل الذكاء الاصطناعي
    ├── agent.ts                      # الوكيل الرئيسي
    ├── tools/                        # الأدوات
    │   ├── search.tool.ts
    │   ├── booking.tool.ts
    │   └── recommendation.tool.ts
    └── prompts/                      # الـ Prompts
        ├── system-prompt.ts
        └── context-builder.ts
```

---

## 🔄 تدفق البيانات

```
┌─────────────────────────────────────────────────────────────────────┐
│                           تدفق البيانات                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌─────────┐      │
│   │   UI    │────▶│   API   │────▶│Application│───▶│  Domain │      │
│   │ Layer   │     │  Layer  │     │  Layer    │     │  Layer  │      │
│   └─────────┘     └─────────┘     └─────────┘     └─────────┘      │
│        │              │               │               │             │
│        │              │               │               │             │
│        ▼              ▼               ▼               ▼             │
│   ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌─────────┐      │
│   │  Hooks  │     │ Routes  │     │ Services│     │Entities │      │
│   └─────────┘     └─────────┘     └─────────┘     └─────────┘      │
│        │              │               │               │             │
│        └──────────────┴───────────────┴───────────────┘             │
│                                │                                    │
│                                ▼                                    │
│                        ┌─────────────┐                              │
│                        │ Infrastructure│                             │
│                        │    Layer     │                              │
│                        └─────────────┘                              │
│                                │                                    │
│                    ┌───────────┼───────────┐                        │
│                    ▼           ▼           ▼                        │
│              ┌─────────┐ ┌─────────┐ ┌─────────┐                    │
│              │Database │ │External │ │  Cache  │                    │
│              │ (Prisma)│ │ Services│ │ (Memory)│                    │
│              └─────────┘ └─────────┘ └─────────┘                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📡 نظام الأحداث (Event System)

### أنواع الأحداث

```typescript
// core/events/event-types.ts

export enum EventType {
  // المستخدمون
  USER_REGISTERED = 'user.registered',
  USER_LOGIN = 'user.login',
  USER_LOGOUT = 'user.logout',
  USER_PROFILE_UPDATED = 'user.profile.updated',
  
  // الحجوزات
  BOOKING_CREATED = 'booking.created',
  BOOKING_CONFIRMED = 'booking.confirmed',
  BOOKING_CANCELLED = 'booking.cancelled',
  BOOKING_COMPLETED = 'booking.completed',
  
  // المدفوعات
  PAYMENT_INITIATED = 'payment.initiated',
  PAYMENT_COMPLETED = 'payment.completed',
  PAYMENT_FAILED = 'payment.failed',
  PAYMENT_REFUNDED = 'payment.refunded',
  
  // الضمان
  ESCROW_CREATED = 'escrow.created',
  ESCROW_RELEASED = 'escrow.released',
  ESCROW_DISPUTED = 'escrow.disputed',
  
  // التقييمات
  REVIEW_CREATED = 'review.created',
  REVIEW_REPLY = 'review.reply',
  
  // الشركات
  COMPANY_REGISTERED = 'company.registered',
  COMPANY_VERIFIED = 'company.verified',
  COMPANY_SUSPENDED = 'company.suspended',
}
```

### مثال على استخدام الأحداث

```typescript
// في ميزة الحجز
await eventBus.emit(EventType.BOOKING_CREATED, {
  bookingId: booking.id,
  userId: booking.userId,
  amount: booking.totalAmount,
});

// في ميزة الإشعارات (مشترك منفصل)
@Subscribe(EventType.BOOKING_CREATED)
async handleBookingCreated(event: BookingCreatedEvent) {
  await this.notificationService.send({
    userId: event.userId,
    title: 'تم إنشاء حجز جديد',
    body: `حجزك رقم ${event.bookingId} في انتظار التأكيد`,
  });
}

// في ميزة الضمان (مشترك منفصل)
@Subscribe(EventType.BOOKING_CREATED)
async handleBookingCreated(event: BookingCreatedEvent) {
  await this.escrowService.createEscrow({
    bookingId: event.bookingId,
    amount: event.amount,
  });
}
```

---

## 🔒 أمن التطبيق

### المصادقة (Authentication)

```
┌─────────────────────────────────────────────────────────────────┐
│                      خيارات المصادقة                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. البريد الإلكتروني + كلمة المرور                             │
│     └── تسجيل → تأكيد البريد → تسجيل دخول                       │
│                                                                 │
│  2. رقم الهاتف + OTP                                            │
│     └── إدخال الرقم → إرسال OTP → تحقق → تسجيل دخول             │
│                                                                 │
│  3. OAuth (Google, Apple, Facebook)                             │
│     └── توجيه → موافقة → رجوع → تسجيل دخول                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### الصلاحيات (Authorization)

```typescript
// الأدوار
enum Role {
  GUEST = 'guest',           // زائر (غير مسجل)
  USER = 'user',             // مستخدم عادي
  HOST = 'host',             // مضيف (صاحب إقامة)
  COMPANY = 'company',       // شركة
  ADMIN = 'admin',           // مدير
  SUPER_ADMIN = 'super_admin', // مدير عام
}

// الصلاحيات
enum Permission {
  // الحجوزات
  BOOKING_CREATE = 'booking:create',
  BOOKING_READ = 'booking:read',
  BOOKING_UPDATE = 'booking:update',
  BOOKING_CANCEL = 'booking:cancel',
  
  // الإقامات
  ACCOMMODATION_CREATE = 'accommodation:create',
  ACCOMMODATION_MANAGE = 'accommodation:manage',
  
  // الإدارة
  USER_MANAGE = 'user:manage',
  COMPANY_VERIFY = 'company:verify',
  DISPUTE_RESOLVE = 'dispute:resolve',
}
```

---

## 🌐 نقاط الامتداد (Extension Points)

### 1. إضافة ميزة جديدة

```markdown
1. إنشاء مجلد في features/ بالاسم المناسب
2. إنشاء الهيكل الداخلي:
   - domain/ (الكيانات والقواعد)
   - application/ (الخدمات وحالات الاستخدام)
   - infrastructure/ (المستودعات والمحولات)
   - api/ (المسارات)
   - ui/ (المكونات)
3. تعريف الأحداث في core/events/
4. إضافة الـ migrations لقاعدة البيانات
```

### 2. إضافة موفر دفع جديد

```typescript
// infrastructure/adapters/payment.adapter.ts

export interface PaymentProvider {
  name: string;
  initiatePayment(params: PaymentParams): Promise<PaymentResult>;
  verifyPayment(paymentId: string): Promise<PaymentVerification>;
  refundPayment(paymentId: string): Promise<RefundResult>;
}

// إضافة موفر جديد
export class NewPaymentProvider implements PaymentProvider {
  name = 'new-provider';
  // ... تنفيذ الواجهة
}
```

### 3. إضافة نوع رحلة جديد

```typescript
// core/domain/entities/JourneyType.ts

export enum JourneyType {
  TOURISM = 'tourism',
  MEDICAL = 'medical',
  EDUCATION = 'education',
  BUSINESS = 'business',
  // يمكن إضافة أنواع جديدة هنا
  // PILGRIMAGE = 'pilgrimage',
}
```

---

## 📊 مخطط C4 للنظام

### Level 1: System Context

```
┌─────────────────────────────────────────────────────────────────┐
│                      نظام "ضيف"                                 │
│                                                                 │
│  ┌───────────┐     ┌───────────┐     ┌───────────┐            │
│  │  السياح   │     │  المضيفين │     │  الشركات  │            │
│  │  (Users)  │     │  (Hosts)  │     │(Companies)│            │
│  └───────────┘     └───────────┘     └───────────┘            │
│        │                 │                 │                    │
│        └─────────────────┼─────────────────┘                    │
│                          │                                      │
│                          ▼                                      │
│                  ┌───────────────┐                              │
│                  │   منصة ضيف    │                              │
│                  │   (Dayf)      │                              │
│                  └───────────────┘                              │
│                          │                                      │
│         ┌────────────────┼────────────────┐                     │
│         ▼                ▼                ▼                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │بوابات الدفع │  │خدمات الخرائط│  │خدمات الإعلام│             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Level 2: Container

```
┌─────────────────────────────────────────────────────────────────┐
│                      نظام "ضيف"                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                     تطبيق الويب                          │  │
│  │  (Next.js 16 + React + TypeScript + Tailwind)            │  │
│  │                                                          │  │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │  │
│  │  │ صفحات   │  │مكونات UI│  │  Hooks  │  │  State  │     │  │
│  │  │العميل   │  │         │  │         │  │ Zustand │     │  │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          │                                     │
│                          ▼                                     │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                     API Layer                            │  │
│  │  (Next.js API Routes + Prisma)                           │  │
│  │                                                          │  │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │  │
│  │  │  Auth   │  │Booking  │  │ Payment │  │ AI Agent│     │  │
│  │  │ Routes  │  │ Routes  │  │ Routes  │  │ Routes  │     │  │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          │                                     │
│         ┌────────────────┼────────────────┐                    │
│         ▼                ▼                ▼                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │  قاعدة      │  │  خدمة AI    │  │  خدمة       │            │
│  │  البيانات   │  │ (z-ai-sdk)  │  │  البريد     │            │
│  │  (Prisma)   │  │             │  │             │            │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📈 استراتيجية التوسع

### الأفقية (Horizontal Scaling)
- تم تصميم النظام ليكون stateless
- يمكن تشغيل نسخ متعددة من التطبيق
- استخدام Redis للـ sessions (اختياري)

### العمودية (Vertical Scaling)
- تحسين استعلامات قاعدة البيانات
- استخدام indexes بشكل صحيح
- Caching للبيانات المتكررة

---

## 🔧 متطلبات التطوير

### البيئة المحلية
- Node.js 20+
- Bun runtime
- SQLite (تطوير) / PostgreSQL (إنتاج)

### المكتبات الأساسية
```json
{
  "dependencies": {
    "next": "16.x",
    "react": "19.x",
    "typescript": "5.x",
    "prisma": "latest",
    "@prisma/client": "latest",
    "tailwindcss": "4.x",
    "z-ai-web-dev-sdk": "latest",
    "zustand": "latest",
    "zod": "latest"
  }
}
```

---

## 📝 ملاحظات مهمة

1. **لا تقم بتعديل الكود الموجود مباشرة** - استخدم الامتدادات
2. **كل ميزة مستقلة** - لا تستورد من ميزة أخرى مباشرة
3. **استخدم الأحداث للتواصل** - هذا يضمن الفصل
4. **وثق كل تغيير** - في worklog.md
5. **اختبر قبل الرفع** - استخدم `bun run lint`

---

*آخر تحديث: 2025*
