const https = require('https');
const fs = require('fs');
const AdmZip = require('adm-zip');

const url = "https://github.com/waelhe88-coder/my-app/raw/refs/heads/main/dayf.zip";
const dest = "dayf.zip";

function download(url, dest, cb) {
  const file = fs.createWriteStream(dest);
  https.get(url, function(response) {
    if (response.statusCode === 301 || response.statusCode === 302) {
      download(response.headers.location, dest, cb);
    } else {
      response.pipe(file);
      file.on('finish', function() {
        file.close(cb);
      });
    }
  }).on('error', function(err) {
    fs.unlink(dest, () => {});
    if (cb) cb(err.message);
  });
}

download(url, dest, function(err) {
  if (err) {
    console.error("Error downloading:", err);
    return;
  }
  try {
    const zip = new AdmZip(dest);
    zip.extractAllTo("./extracted", true);
    console.log("Extracted successfully");
  } catch (e) {
    console.error("Error extracting:", e);
  }
});
