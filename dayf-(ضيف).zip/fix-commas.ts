import fs from 'fs';
import path from 'path';

function fixCommas(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      fixCommas(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      
      if (content.includes(',,')) {
        content = content.replace(/,\s*,/g, ',');
        content = content.replace(/{\s*,/g, '{');
        content = content.replace(/,\s*}/g, '}');
        fs.writeFileSync(fullPath, content);
      }
    }
  }
}

fixCommas('src');
console.log('Fixed commas in src');
