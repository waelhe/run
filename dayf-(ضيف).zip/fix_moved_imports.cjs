const fs = require('fs');
const path = require('path');

const moves = [
  // Shared Components
  ['src/components/Navbar.tsx', 'src/shared/components/layout/Navbar.tsx'],
  ['src/components/Header.tsx', 'src/shared/components/layout/Header.tsx'],
  ['src/components/BottomNav.tsx', 'src/shared/components/layout/BottomNav.tsx'],
  ['src/components/Footer.tsx', 'src/shared/components/layout/Footer.tsx'],
  ['src/components/Hero.tsx', 'src/shared/components/ui/Hero.tsx'],
  ['src/components/PaymentModal.tsx', 'src/shared/components/ui/PaymentModal.tsx'],
  ['src/components/RecentlyViewed.tsx', 'src/shared/components/ui/RecentlyViewed.tsx'],
  ['src/components/ReviewSection.tsx', 'src/shared/components/ui/ReviewSection.tsx'],
  ['src/components/Skeleton.tsx', 'src/shared/components/ui/Skeleton.tsx'],
  ['src/components/WhyChooseUs.tsx', 'src/shared/components/ui/WhyChooseUs.tsx'],
  ['src/components/Categories.tsx', 'src/shared/components/ui/Categories.tsx'],
  ['src/components/ScrollToTop.tsx', 'src/shared/components/utils/ScrollToTop.tsx'],

  // Features: Services
  ['src/components/ServiceCard.tsx', 'src/features/services/components/ServiceCard.tsx'],
  ['src/components/ServiceSection.tsx', 'src/features/services/components/ServiceSection.tsx'],
  ['src/components/provider/AddServiceModal.tsx', 'src/features/services/components/AddServiceModal.tsx'],
  ['src/components/provider/ServiceManagement.tsx', 'src/features/services/components/ServiceManagement.tsx'],
  ['src/pages/CategoryPage.tsx', 'src/features/services/pages/CategoryPage.tsx'],
  ['src/pages/ListingDetails.tsx', 'src/features/services/pages/ListingDetails.tsx'],
  ['src/pages/AddServicePage.tsx', 'src/features/services/pages/AddServicePage.tsx'],
  ['src/pages/EditServicePage.tsx', 'src/features/services/pages/EditServicePage.tsx'],
  ['src/data/categories.ts', 'src/features/services/data/categories.ts'],
  ['src/data/initialServices.ts', 'src/features/services/data/initialServices.ts'],

  // Features: Bookings
  ['src/components/provider/BookingManagement.tsx', 'src/features/bookings/components/BookingManagement.tsx'],
  ['src/pages/MyBookings.tsx', 'src/features/bookings/pages/MyBookings.tsx'],
  ['src/pages/ProviderDashboard.tsx', 'src/features/bookings/pages/ProviderDashboard.tsx'],

  // Features: Marketplace
  ['src/components/MarketHighlights.tsx', 'src/features/marketplace/components/MarketHighlights.tsx'],
  ['src/pages/MarketplacePage.tsx', 'src/features/marketplace/pages/MarketplacePage.tsx'],
  ['src/pages/ProductDetailsPage.tsx', 'src/features/marketplace/pages/ProductDetailsPage.tsx'],
  ['src/components/CartDrawer.tsx', 'src/features/marketplace/components/CartDrawer.tsx'],
  ['src/contexts/CartContext.tsx', 'src/features/marketplace/contexts/CartContext.tsx'],

  // Features: Community
  ['src/components/CommunityHighlights.tsx', 'src/features/community/components/CommunityHighlights.tsx'],
  ['src/pages/CommunityPage.tsx', 'src/features/community/pages/CommunityPage.tsx'],
  ['src/pages/TopicDetails.tsx', 'src/features/community/pages/TopicDetails.tsx'],
  ['src/pages/GuideDetails.tsx', 'src/features/community/pages/GuideDetails.tsx'],

  // Features: Orders
  ['src/pages/OrdersPage.tsx', 'src/features/orders/pages/OrdersPage.tsx'],

  // Features: Provider
  ['src/components/provider/ProviderSettings.tsx', 'src/features/provider/components/ProviderSettings.tsx'],
  ['src/pages/VendorProfilePage.tsx', 'src/features/provider/pages/VendorProfilePage.tsx'],

  // Features: User
  ['src/pages/Profile.tsx', 'src/features/user/pages/Profile.tsx'],

  // Features: AI
  ['src/components/AIAgent.tsx', 'src/features/ai/components/AIAgent.tsx'],
  ['src/components/GuestServiceCenter.tsx', 'src/features/ai/components/GuestServiceCenter.tsx'],

  // Core & Shared
  ['src/contexts/AuthContext.tsx', 'src/core/contexts/AuthContext.tsx'],
  ['src/contexts/LanguageContext.tsx', 'src/core/contexts/LanguageContext.tsx'],
  ['src/hooks/useScrollDirection.ts', 'src/shared/hooks/useScrollDirection.ts'],
  ['src/utils/firestoreError.ts', 'src/shared/utils/firestoreError.ts'],
  ['src/utils/recentViews.ts', 'src/shared/utils/recentViews.ts'],
];

const moveMap = new Map(moves.map(([oldPath, newPath]) => [newPath, oldPath]));
const newPathMap = new Map(moves.map(([oldPath, newPath]) => [oldPath, newPath]));

function getAllFiles(dir, fileList = []) {
  if (!fs.existsSync(dir)) return fileList;
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      getAllFiles(filePath, fileList);
    } else if (filePath.endsWith('.ts') || filePath.endsWith('.tsx')) {
      fileList.push(filePath);
    }
  }
  return fileList;
}

const allFiles = getAllFiles('src');

for (const file of allFiles) {
  let content = fs.readFileSync(file, 'utf8');
  let changed = false;

  const fileDir = path.dirname(file);
  const importRegex = /(['"])((?:\.\/|\.\.\/)+)(.*?)(['"])/g;
  let match;
  let replacements = [];

  while ((match = importRegex.exec(content)) !== null) {
    const quote = match[1];
    const relPath = match[2];
    const importPath = match[3];
    const fullImport = relPath + importPath;
    
    // Calculate absolute path of the import
    const importedAbsPath = path.resolve(fileDir, fullImport);
    
    // Check if it exists
    const exists = ['.ts', '.tsx', '.js', '.jsx', ''].some(ext => fs.existsSync(importedAbsPath + ext)) ||
                   (fs.existsSync(importedAbsPath) && fs.statSync(importedAbsPath).isDirectory());
                   
    if (!exists) {
      // It doesn't exist. Let's see if it's pointing to an old path that moved.
      // We need to check all possible extensions
      let targetOldPath = null;
      for (const ext of ['.ts', '.tsx', '.js', '.jsx', '']) {
        const potentialOldPath = path.relative(process.cwd(), importedAbsPath + ext).replace(/\\/g, '/');
        if (newPathMap.has(potentialOldPath)) {
          targetOldPath = potentialOldPath;
          break;
        }
      }
      
      if (targetOldPath) {
        const targetNewPath = newPathMap.get(targetOldPath);
        const targetNewAbsPath = path.resolve(process.cwd(), targetNewPath.replace(/\.tsx?$/, ''));
        
        // Calculate new relative path
        let newRelPath = path.relative(fileDir, targetNewAbsPath);
        if (!newRelPath.startsWith('.')) {
          newRelPath = './' + newRelPath;
        }
        newRelPath = newRelPath.replace(/\\\\/g, '/');
        
        replacements.push({
          start: match.index,
          end: match.index + match[0].length,
          newStr: quote + newRelPath + quote
        });
      }
    }
  }

  // Apply replacements from back to front
  for (let i = replacements.length - 1; i >= 0; i--) {
    const r = replacements[i];
    content = content.substring(0, r.start) + r.newStr + content.substring(r.end);
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Fixed moved imports in ${file}`);
  }
}
