const fs = require('fs');

const pkgPath = './package.json';
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

// Remove vite and react-router-dom
delete pkg.dependencies['react-router-dom'];
delete pkg.dependencies['vite'];
delete pkg.dependencies['@vitejs/plugin-react'];
delete pkg.devDependencies['vite'];

// Add next
pkg.dependencies['next'] = '^15.0.0';

// Update scripts
pkg.scripts = {
  "dev": "next dev",
  "build": "next build",
  "start": "next start",
  "lint": "next lint"
};

fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2));
console.log('package.json updated');
