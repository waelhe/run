"use client";
import { AuthProvider } from '../src/core/contexts/AuthContext';
import { LanguageProvider } from '../src/core/contexts/LanguageContext';
import { CartProvider } from '../src/features/marketplace/contexts/CartContext';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <LanguageProvider>
        <CartProvider>
          {children}
        </CartProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
