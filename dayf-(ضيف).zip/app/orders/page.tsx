"use client";
import PageComponent from '../../src/features/orders/pages/OrdersPage';

export default function Page() {
  return <PageComponent />;
}
