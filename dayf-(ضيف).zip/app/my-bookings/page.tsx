"use client";
import PageComponent from '../../src/features/bookings/pages/MyBookings';

export default function Page() {
  return <PageComponent />;
}
