"use client";
import PageComponent from '../../src/features/marketplace/pages/MarketplacePage';

export default function Page() {
  return <PageComponent />;
}
