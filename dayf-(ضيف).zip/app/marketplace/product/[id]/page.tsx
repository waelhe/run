"use client";
import PageComponent from '../../../../src/features/marketplace/pages/ProductDetailsPage';

export default function Page() {
  return <PageComponent />;
}
