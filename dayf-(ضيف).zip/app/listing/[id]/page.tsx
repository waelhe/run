"use client";
import PageComponent from '../../../src/features/services/ui/pages/ListingDetails';

export default function Page() {
  return <PageComponent />;
}
