"use client";
import PageComponent from '../src/features/home/pages/Home';

export default function Page() {
  return <PageComponent />;
}
