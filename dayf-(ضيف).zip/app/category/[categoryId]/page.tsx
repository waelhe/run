"use client";
import PageComponent from '../../../src/features/services/ui/pages/CategoryPage';

export default function Page() {
  return <PageComponent />;
}
