import fs from 'fs';
import path from 'path';
import https from 'https';
import { execSync } from 'child_process';

async function main() {
  // 1. Backup current src
  console.log("Backing up current src to src_backup...");
  if (fs.existsSync('src_backup')) {
    fs.rmSync('src_backup', { recursive: true, force: true });
  }
  fs.cpSync('src', 'src_backup', { recursive: true });
  console.log("Backup complete.");

  // 2. Download zip
  const url = "https://github.com/waelhe/my-project/raw/refs/heads/main/dayf%20(8).zip";
  const zipPath = "user_backup.zip";

  console.log("Downloading backup zip...");
  await new Promise((resolve, reject) => {
    const file = fs.createWriteStream(zipPath);
    const request = https.get(url, function(response) {
      if (response.statusCode === 301 || response.statusCode === 302) {
        https.get(response.headers.location!, function(res) {
          res.pipe(file);
          file.on('finish', () => {
            file.close();
            resolve(true);
          });
        }).on('error', reject);
      } else {
        response.pipe(file);
        file.on('finish', () => {
          file.close();
          resolve(true);
        });
      }
    }).on('error', reject);
  });
  console.log("Download complete. Extracting...");

  try {
    execSync('npx -y extract-zip user_backup.zip user_backup_extracted', { stdio: 'inherit' });
    console.log("Extraction complete.");
  } catch (e) {
    console.error("Extraction failed:", e);
  }
}

main().catch(console.error);
