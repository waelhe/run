const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const zipPath = path.resolve("user_backup.zip");
const extractPath = path.resolve("user_backup_extracted");

try {
  execSync(`npx -y extract-zip ${zipPath} ${extractPath}`, { stdio: 'inherit' });
  console.log("Extraction complete.");
} catch (e) {
  console.error("Extraction failed:", e);
}
