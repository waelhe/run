"use client";
import PageComponent from '../../src/features/bookings/pages/ProviderDashboard';

export default function Page() {
  return <PageComponent />;
}
