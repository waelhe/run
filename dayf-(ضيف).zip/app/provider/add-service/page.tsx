"use client";
import PageComponent from '../../../src/features/services/ui/pages/AddServicePage';

export default function Page() {
  return <PageComponent />;
}
