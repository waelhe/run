"use client";
import PageComponent from '../../../../src/features/services/ui/pages/EditServicePage';

export default function Page() {
  return <PageComponent />;
}
