"use client";
import PageComponent from '../../src/features/community/pages/CommunityPage';

export default function Page() {
  return <PageComponent />;
}
