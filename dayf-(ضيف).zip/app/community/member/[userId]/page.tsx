"use client";
import PageComponent from '../../../../src/features/community/pages/MemberProfilePage';

export default function Page() {
  return <PageComponent />;
}
