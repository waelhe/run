"use client";
import PageComponent from '../../../../src/features/community/pages/GuideDetails';

export default function Page() {
  return <PageComponent />;
}
