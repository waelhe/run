"use client";
import PageComponent from '../../../src/features/community/pages/CategoryTopicsPage';

export default function Page() {
  return <PageComponent />;
}
