"use client";
import PageComponent from '../../../../src/features/community/pages/TopicDetails';

export default function Page() {
  return <PageComponent />;
}
