"use client";
import PageComponent from '../../src/features/user/pages/Profile';

export default function Page() {
  return <PageComponent />;
}
