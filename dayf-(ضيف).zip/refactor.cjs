const fs = require('fs');
const path = require('path');

const moves = [
  // Shared Components
  ['src/components/Navbar.tsx', 'src/shared/components/layout/Navbar.tsx'],
  ['src/components/Header.tsx', 'src/shared/components/layout/Header.tsx'],
  ['src/components/BottomNav.tsx', 'src/shared/components/layout/BottomNav.tsx'],
  ['src/components/Footer.tsx', 'src/shared/components/layout/Footer.tsx'],
  ['src/components/Hero.tsx', 'src/shared/components/ui/Hero.tsx'],
  ['src/components/PaymentModal.tsx', 'src/shared/components/ui/PaymentModal.tsx'],
  ['src/components/RecentlyViewed.tsx', 'src/shared/components/ui/RecentlyViewed.tsx'],
  ['src/components/ReviewSection.tsx', 'src/shared/components/ui/ReviewSection.tsx'],
  ['src/components/Skeleton.tsx', 'src/shared/components/ui/Skeleton.tsx'],
  ['src/components/WhyChooseUs.tsx', 'src/shared/components/ui/WhyChooseUs.tsx'],
  ['src/components/Categories.tsx', 'src/shared/components/ui/Categories.tsx'],
  ['src/components/ScrollToTop.tsx', 'src/shared/components/utils/ScrollToTop.tsx'],

  // Features: Services
  ['src/components/ServiceCard.tsx', 'src/features/services/components/ServiceCard.tsx'],
  ['src/components/ServiceSection.tsx', 'src/features/services/components/ServiceSection.tsx'],
  ['src/components/provider/AddServiceModal.tsx', 'src/features/services/components/AddServiceModal.tsx'],
  ['src/components/provider/ServiceManagement.tsx', 'src/features/services/components/ServiceManagement.tsx'],
  ['src/pages/CategoryPage.tsx', 'src/features/services/pages/CategoryPage.tsx'],
  ['src/pages/ListingDetails.tsx', 'src/features/services/pages/ListingDetails.tsx'],
  ['src/pages/AddServicePage.tsx', 'src/features/services/pages/AddServicePage.tsx'],
  ['src/pages/EditServicePage.tsx', 'src/features/services/pages/EditServicePage.tsx'],
  ['src/data/categories.ts', 'src/features/services/data/categories.ts'],
  ['src/data/initialServices.ts', 'src/features/services/data/initialServices.ts'],

  // Features: Bookings
  ['src/components/provider/BookingManagement.tsx', 'src/features/bookings/components/BookingManagement.tsx'],
  ['src/pages/MyBookings.tsx', 'src/features/bookings/pages/MyBookings.tsx'],
  ['src/pages/ProviderDashboard.tsx', 'src/features/bookings/pages/ProviderDashboard.tsx'],

  // Features: Marketplace
  ['src/components/MarketHighlights.tsx', 'src/features/marketplace/components/MarketHighlights.tsx'],
  ['src/pages/MarketplacePage.tsx', 'src/features/marketplace/pages/MarketplacePage.tsx'],
  ['src/pages/ProductDetailsPage.tsx', 'src/features/marketplace/pages/ProductDetailsPage.tsx'],
  ['src/components/CartDrawer.tsx', 'src/features/marketplace/components/CartDrawer.tsx'],
  ['src/contexts/CartContext.tsx', 'src/features/marketplace/contexts/CartContext.tsx'],

  // Features: Community
  ['src/components/CommunityHighlights.tsx', 'src/features/community/components/CommunityHighlights.tsx'],
  ['src/pages/CommunityPage.tsx', 'src/features/community/pages/CommunityPage.tsx'],
  ['src/pages/TopicDetails.tsx', 'src/features/community/pages/TopicDetails.tsx'],
  ['src/pages/GuideDetails.tsx', 'src/features/community/pages/GuideDetails.tsx'],

  // Features: Orders
  ['src/pages/OrdersPage.tsx', 'src/features/orders/pages/OrdersPage.tsx'],

  // Features: Provider
  ['src/components/provider/ProviderSettings.tsx', 'src/features/provider/components/ProviderSettings.tsx'],
  ['src/pages/VendorProfilePage.tsx', 'src/features/provider/pages/VendorProfilePage.tsx'],

  // Features: User
  ['src/pages/Profile.tsx', 'src/features/user/pages/Profile.tsx'],

  // Features: AI
  ['src/components/AIAgent.tsx', 'src/features/ai/components/AIAgent.tsx'],
  ['src/components/GuestServiceCenter.tsx', 'src/features/ai/components/GuestServiceCenter.tsx'],

  // Core & Shared
  ['src/contexts/AuthContext.tsx', 'src/core/contexts/AuthContext.tsx'],
  ['src/contexts/LanguageContext.tsx', 'src/core/contexts/LanguageContext.tsx'],
  ['src/hooks/useScrollDirection.ts', 'src/shared/hooks/useScrollDirection.ts'],
  ['src/utils/firestoreError.ts', 'src/shared/utils/firestoreError.ts'],
  ['src/utils/recentViews.ts', 'src/shared/utils/recentViews.ts'],
];

function ensureDir(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// 1. Move files
for (const [src, dest] of moves) {
  if (fs.existsSync(src)) {
    ensureDir(dest);
    fs.renameSync(src, dest);
    console.log(`Moved ${src} to ${dest}`);
  } else {
    console.warn(`File not found: ${src}`);
  }
}

// 2. Update imports
function getAllFiles(dir, fileList = []) {
  if (!fs.existsSync(dir)) return fileList;
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      getAllFiles(filePath, fileList);
    } else if (filePath.endsWith('.ts') || filePath.endsWith('.tsx')) {
      fileList.push(filePath);
    }
  }
  return fileList;
}

const allFiles = getAllFiles('src');

for (const file of allFiles) {
  let content = fs.readFileSync(file, 'utf8');
  let changed = false;

  for (const [oldPath, newPath] of moves) {
    const oldImport = oldPath.replace(/^src\//, '').replace(/\.tsx?$/, '');
    const newImport = newPath.replace(/^src\//, '').replace(/\.tsx?$/, '');

    // Replace absolute imports starting with src/
    const regexAbs = new RegExp(`(['"])src\\/${oldImport}(['"])`, 'g');
    if (regexAbs.test(content)) {
      content = content.replace(regexAbs, `$1src/${newImport}$2`);
      changed = true;
    }

    // Replace relative imports
    // Find imports like '../components/Navbar' or './Navbar'
    const importRegex = new RegExp(`(['"])((?:\\.\\/|\\.\\.\\/)+)${path.basename(oldImport)}(['"])`, 'g');
    
    let match;
    while ((match = importRegex.exec(content)) !== null) {
      const quote = match[1];
      const relPath = match[2];
      const baseName = path.basename(oldImport);
      
      // Calculate absolute path of the old import
      const fileDir = path.dirname(file);
      const oldAbsPath = path.resolve(fileDir, relPath + baseName);
      const expectedOldAbsPath = path.resolve(process.cwd(), oldPath.replace(/\.tsx?$/, ''));

      if (oldAbsPath === expectedOldAbsPath) {
        // Calculate new relative path
        let newRelPath = path.relative(fileDir, path.resolve(process.cwd(), newPath.replace(/\.tsx?$/, '')));
        if (!newRelPath.startsWith('.')) {
          newRelPath = './' + newRelPath;
        }
        newRelPath = newRelPath.replace(/\\\\/g, '/');
        
        content = content.substring(0, match.index) + quote + newRelPath + quote + content.substring(match.index + match[0].length);
        importRegex.lastIndex = match.index + quote.length + newRelPath.length + quote.length;
        changed = true;
      }
    }
  }

  if (changed) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated imports in ${file}`);
  }
}
