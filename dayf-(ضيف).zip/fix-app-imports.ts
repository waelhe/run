import fs from 'fs';
import path from 'path';

function fixImports(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      fixImports(fullPath);
    } else if (fullPath.endsWith('page.tsx')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      
      // Calculate depth from app/
      // e.g. app/page.tsx -> depth 0
      // app/category/[categoryId]/page.tsx -> depth 2
      const relativePath = path.relative('app', fullPath);
      const depth = relativePath.split(path.sep).length - 1;
      
      const importPrefix = depth === 0 ? '../' : '../'.repeat(depth + 1);
      
      content = content.replace(/import PageComponent from '([^']+)';/, (match, p1) => {
          // p1 is something like ../../src/...
          // We want to replace it with the correct prefix + src/...
          const srcPath = p1.substring(p1.indexOf('src/'));
          return `import PageComponent from '${importPrefix}${srcPath}';`;
      });
      
      fs.writeFileSync(fullPath, content);
    }
  }
}

fixImports('app');
console.log('Fixed imports in app pages');
