# 📘 دليل البناء - منصة "ضيف"

## 🏗️ الهيكل

```
src/
├── core/                    # النواة (لا تُعدّل إلا للأساسيات)
│   ├── domain/             # الكيانات والقواعد
│   │   ├── entities/       # User, Booking, Listing, Payment...
│   │   ├── value-objects/  # Money, Address, Rating...
│   │   ├── rules/          # قواعد العمل
│   │   └── authorization/  # الصلاحيات والأدوار
│   ├── events/             # نظام الأحداث
│   ├── interfaces/         # واجهات المستودعات والخدمات
│   └── types/              # أنواع TypeScript مشتركة
│
├── application/             # طبقة التطبيق
│   ├── services/           # الخدمات
│   ├── use-cases/          # حالات الاستخدام
│   └── mappers/            # محولات البيانات
│
├── infrastructure/          # البنية التحتية
│   ├── repositories/       # الوصول للبيانات
│   ├── services/           # خدمات (Auth, Audit...)
│   └── providers/          # مزودين (AI, Storage, Payment...)
│
├── app/                     # Next.js App Router
│   ├── api/                # API Routes
│   └── (routes)/           # الصفحات
│
└── shared/                  # المشتركات
    ├── components/         # مكونات UI (shadcn/ui)
    ├── hooks/              # React Hooks
    └── contexts/           # React Contexts
```

---

## 🔄 تدفق العمل

لكل ميزة جديدة:

```
1. SPEC  ← ماذا نريد؟ (اكتب في STATUS.md)
2. BUILD ← ابنِ مباشرة
```

**قاعدة: لا كود بدون مواصفات**

---

## 🚌 التواصل بين الوحدات

### ✅ مسموح:
- عبر الأحداث فقط (Event Bus)
- `eventBus.publish('booking.created', data)`
- `eventBus.subscribe('booking.created', handler)`

### ❌ ممنوع:
- استدعاء مباشر بين الوحدات
- `import { BookingService } from '../bookings'`

---

## 🔐 الأمان الأساسي

### المصادقة:
| العنصر | القاعدة |
|--------|---------|
| كلمات المرور | bcrypt + 12 rounds |
| الجلسات | JWT + httpOnly Cookie |
| انتهاء الصلاحية | Access: 15 دقيقة / Refresh: 7 أيام |

### الصلاحيات:
| المبدأ | التطبيق |
|--------|---------|
| Deny by Default | لا أحد يملك صلاحية إلا إذا مُنحت |
| التحقق | Middleware في كل API |
| الملكية | المستخدم يرى/يعدل بياناته فقط |

### المدخلات:
| القاعدة | الأداة |
|---------|--------|
| تحقق دائماً | Zod schemas |
| فلترة | sanitize-html |
| ترميز | encodeURIComponent |

---

## 👥 الأدوار والصلاحيات

| الدور | الصلاحيات |
|-------|----------|
| **Guest** | يتصفح فقط |
| **User** | يحجز + يقيّم + يعدل ملفه |
| **Host** | يضيف إقامات + يؤكد الحجوزات |
| **Admin** | يدير المستخدمين + التقارير |

---

## 📡 الأحداث الرئيسية

### أحداث الحجز:
```
booking.created    → بدء الحجز
booking.confirmed  → تأكيد المضيف
booking.cancelled  → إلغاء الحجز
booking.completed  → انتهت الإقامة
```

### أحداث الدفع:
```
payment.initiated  → بدء الدفع
payment.completed  → دفع ناجح
payment.failed     → دفع فاشل
payment.refunded   → استرداد
```

### أحداث الضمان:
```
escrow.created     → إنشاء حساب ضمان
escrow.funded      → تمويل الضمان
escrow.released    → إطلاق للمضيف
escrow.disputed    → نزاع
```

---

## 🛠️ التقنيات المستخدمة

| الفئة | التقنية |
|-------|---------|
| Framework | Next.js 16 + TypeScript |
| Database | Prisma + SQLite |
| Styling | Tailwind CSS 4 + shadcn/ui |
| Validation | Zod |
| Auth | NextAuth.js + JWT |
| State | Zustand + TanStack Query |
| Real-time | Socket.io |

---

## 📂 هيكل الوحدة

كل وحدة تتبع هذا الهيكل:

```
modules/example/
├── domain/
│   ├── entities/
│   └── rules/
├── application/
│   ├── services/
│   └── use-cases/
├── infrastructure/
│   └── repositories/
└── index.ts          # الواجهة العامة
```

---

## 🎯 نصائح مهمة

1. **اقرأ STATUS.md أولاً** - لمعرفة أين نحن
2. **راجع RULES.md** - لمعرفة الممنوعات
3. **استخدم الموجود** - لا تعيد اختراع العجلة
4. **اكتب SPEC** - قبل أي كود
5. **حدّث STATUS.md** - بعد أي إنجاز
