# 📕 المحظورات

## ❌ ممنوع تماماً

---

### 🏗️ البنية المعمارية

| ❌ ممنوع | السبب |
|----------|-------|
| Business Logic في Infrastructure | يخلط المسؤوليات |
| استدعاء مباشر بين modules | يقتل الاستقلالية |
| كود بدون TypeScript | يفقد الأمان |
| تعديل core/ بدون ضرورة | يكسر الأساس |

**البديل:**
- Business Logic → `src/core/domain/` أو `src/application/`
- التواصل → Event Bus
- TypeScript → دائماً

---

### 🔐 الأمان

| ❌ ممنوع | الخطر |
|----------|-------|
| تخزين كلمة مرور غير مشفرة | تسريب البيانات |
| إرسال بيانات حساسة في Response | expose sensitive data |
| ثقة بمدخلات المستخدم | Injection attacks |
| SQL خام `${input}` | SQL Injection |
| تخزين secrets في الكود | تسريب المفاتيح |

**البديل:**
- كلمات المرور → bcrypt.hash(password, 12)
- Response → { id, name, email } فقط
- المدخلات → Zod validation
- SQL → Prisma queries
- Secrets → .env فقط

---

### 💻 الكود

| ❌ ممنوع | السبب |
|----------|-------|
| `any` في TypeScript | يفقد الفائدة |
| `console.log` في الإنتاج | أداء + أمان |
| كود مكرر | صعوبة الصيانة |
| دالة أطول من 50 سطر | صعوبة القراءة |
| ملف أكبر من 300 سطر | صعوبة التتبع |
| مجلد بدون `index.ts` | imports فوضوية |

**البديل:**
- `any` → `unknown` + type guard
- `console.log` → `logger.info()` service
- كود مكرر → استخرج دالة
- دالة طويلة → قسمها
- ملف كبير → قسمه
- مجلد → أضف `index.ts`

---

### 📁 الملفات

| ❌ ممنوع | السبب |
|----------|-------|
| import من خارج الوحدة | يقترن |
| ملفات متفرقة | فوضى |
| أسماء غير واضحة | صعوبة الفهم |
| تعليقات بالإنجليزية فقط | المشروع عربي |

**البديل:**
- import → من `index.ts` فقط
- ملفات → تنظيم في مجلدات
- أسماء → واضحة ومعبرة
- تعليقات → عربي + إنجليزي

---

### 🌐 API

| ❌ ممنوع | السبب |
|----------|-------|
| API بدون تحقق | ثغرة |
| إرجاع خطأ تفصيلي | تسريب معلومات |
| DELETE بدون تأكيد | حذف خطأ |
| GET يغير بيانات | ليس idempotent |

**البديل:**
- كل API → validation middleware
- خطأ → رسالة عامة + سجل تفصيلي
- DELETE → Soft Delete + تأكيد
- GET → قراءة فقط

---

### 📱 Frontend

| ❌ ممنوع | السبب |
|----------|-------|
| `dangerouslySetInnerHTML` | XSS |
| تخزين token في localStorage | XSS theft |
| كود بدون loading state | تجربة سيئة |
| نسيان RTL | المشروع عربي |

**البديل:**
- HTML → sanitize أولاً
- token → httpOnly Cookie
- API call → loading + error states
- RTL → `dir="rtl"` دائماً

---

## ✅ جدول البدائل السريع

| ❌ ممنوع | ✅ البديل |
|----------|----------|
| Business Logic في Infra | في Domain/Application |
| استدعاء مباشر | Event Bus |
| `any` | `unknown` + type guard |
| `console.log` | logger service |
| كود مكرر | استخرج دالة |
| SQL خام | Prisma queries |
| `dangerouslySetInnerHTML` | sanitize-html |
| token في localStorage | httpOnly Cookie |
| API بدون تحقق | Zod + middleware |
| إرجاع خطأ تفصيلي | رسالة عامة + سجل |

---

## 🚨 علامات تحذيرية

إذا رأيت أي من هذه، **توقف وفكر**:

```
⚠️ "سأستخدم any لأن..."
⚠️ "هذا مؤقت فقط..."
⚠️ "سأعدل core لأن..."
⚠️ "لا حاجة للتحقق هنا..."
⚠️ "سأنسخ هذا الكود..."
```

---

## 📋 قائمة تحقق قبل كل Commit

```
□ لا يوجد any
□ لا يوجد console.log
□ المدخلات موثقة (Zod)
□ الأخطاء مُعالجة
□ لا كود مكرر
□ الملفات منظمة
□ لا استدعاء مباشر بين الوحدات
□ الواجهة RTL
```

---

**تذكر: هذه القواعد لحماية المشروع، وليست لتعقيد العمل.**
