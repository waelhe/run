import React from 'react';
import {
  Menu, User, Search, Home, Grid, Heart, MapPin, Calendar,
  Plane, Stethoscope, GraduationCap, ArrowLeft, Star, Users,
  Bed, Bath, Landmark, Utensils, ScrollText, Globe, Mail, Twitter, Share2, ChevronRight, ChevronLeft
} from 'lucide-react';

function Navbar() {
  return (
    <nav className="flex justify-between items-center p-4 md:px-8 bg-white/90 backdrop-blur-md fixed w-full top-0 z-50 border-b border-gray-100">
      <div className="flex items-center gap-8">
        <div className="text-2xl font-bold text-primary">ضيف</div>
        <div className="hidden md:flex gap-8 text-gray-500 text-sm font-medium">
          <a href="#" className="text-primary font-bold border-b-2 border-primary pb-1">الرئيسية</a>
          <a href="#" className="hover:text-primary transition-colors">استكشاف</a>
          <a href="#" className="hover:text-primary transition-colors">الخدمات</a>
          <a href="#" className="hover:text-primary transition-colors">المفضلة</a>
          <a href="#" className="hover:text-primary transition-colors">حسابي</a>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <span className="hidden md:block text-sm font-medium text-gray-500 hover:text-primary cursor-pointer">EN</span>
        <button className="hidden md:block text-gray-500 hover:text-primary transition-colors">
          <Menu size={20} />
        </button>
        <button className="p-2 rounded-full bg-primary text-white hover:bg-primary-light transition-colors">
          <User size={18} />
        </button>
        {/* Mobile menu button */}
        <button className="md:hidden text-gray-600">
          <Menu size={24} />
        </button>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <div className="relative h-[85vh] md:h-[90vh] flex items-center justify-center pt-16">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1572085313466-6710de8d7ba3?q=80&w=2000&auto=format&fit=crop" 
          alt="Coast" 
          className="w-full h-full object-cover" 
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 w-full max-w-5xl mt-8 md:mt-16">
        <p className="text-sm md:text-lg mb-2 opacity-90 font-medium">لؤلؤة الساحل السوري</p>
        <h1 className="text-5xl md:text-7xl font-bold mb-4 drop-shadow-lg">اللاذقية</h1>
        <p className="text-lg md:text-2xl mb-8 opacity-90 drop-shadow-md max-w-2xl mx-auto">
          شواطئ ذهبية وريف أخضر ساحر، بوابة البحر المتوسط إلى قلب سوريا
        </p>

        {/* Desktop Search Bar */}
        <div className="hidden md:flex bg-white rounded-full p-2 items-center shadow-xl max-w-3xl mx-auto w-full">
          <div className="flex items-center px-4 py-2 flex-1">
            <MapPin className="text-gray-400 ml-3" size={22} />
            <input type="text" placeholder="إلى أين؟" className="bg-transparent outline-none w-full text-gray-800 placeholder-gray-500 text-lg" />
          </div>
          <div className="w-px h-10 bg-gray-200 mx-2"></div>
          <div className="flex items-center px-4 py-2 flex-1">
            <Calendar className="text-gray-400 ml-3" size={22} />
            <input type="text" placeholder="تاريخ" className="bg-transparent outline-none w-full text-gray-800 placeholder-gray-500 text-lg" />
          </div>
          <button className="bg-[#215e4f] hover:bg-primary text-white rounded-full px-10 py-4 flex items-center justify-center gap-2 transition-colors mr-2 shadow-md">
            <Search size={20} />
            <span className="font-bold text-lg">بحث</span>
          </button>
        </div>

        {/* Mobile Search Bar */}
        <div className="md:hidden flex flex-col gap-3 w-full max-w-md mx-auto mt-8">
          <div className="bg-white rounded-2xl p-4 flex items-center shadow-lg">
            <MapPin className="text-gray-400 ml-3" size={22} />
            <input type="text" placeholder="إلى أين؟" className="bg-transparent outline-none w-full text-gray-800 text-lg" />
          </div>
          <div className="bg-white rounded-2xl p-4 flex items-center shadow-lg">
            <Calendar className="text-gray-400 ml-3" size={22} />
            <input type="text" placeholder="تاريخ" className="bg-transparent outline-none w-full text-gray-800 text-lg" />
          </div>
          <div className="bg-[#e6d5b8]/90 backdrop-blur-sm rounded-2xl p-4 flex items-center justify-between shadow-lg text-primary mt-2">
            <button className="p-1 hover:bg-white/20 rounded-full transition-colors"><ChevronRight size={24} /></button>
            <div className="flex flex-col items-center">
              <span className="font-bold text-lg">اللاذقية</span>
              <span className="text-xs opacity-80 font-medium tracking-widest">4 / 4</span>
            </div>
            <button className="p-1 hover:bg-white/20 rounded-full transition-colors"><Search size={24} /></button>
          </div>
          {/* Pagination dots */}
          <div className="flex justify-center gap-2 mt-4">
            <div className="w-2 h-2 rounded-full bg-white/50"></div>
            <div className="w-2 h-2 rounded-full bg-white/50"></div>
            <div className="w-2 h-2 rounded-full bg-white/50"></div>
            <div className="w-6 h-2 rounded-full bg-white"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Services() {
  const services = [
    { title: 'سياحة وسفر', desc: 'اكتشف أجمل الوجهات السياحية في سوريا', icon: <Plane size={36} strokeWidth={1.5} />, color: 'bg-[#215e4f] text-white', btnClass: 'bg-[#e6d5b8] text-gray-900 hover:bg-[#d5c4a7]' },
    { title: 'سياحة علاجية', desc: 'أفضل المراكز الطبية والمستشفيات', icon: <Stethoscope size={36} strokeWidth={1.5} />, color: 'bg-[#c47b7b] text-white', btnClass: 'bg-[#e6d5b8] text-gray-900 hover:bg-[#d5c4a7]' },
    { title: 'تعليم', desc: 'جامعات ومعاهد ومركزات تدريب', icon: <GraduationCap size={36} strokeWidth={1.5} />, color: 'bg-[#a8cde4] text-gray-900', btnClass: 'bg-[#114232] text-white hover:bg-[#0a2a20]' },
    { title: 'عقارات', desc: 'شقق ومنازل وفلل للإيجار والبيع', icon: <Home size={36} strokeWidth={1.5} />, color: 'bg-[#f1e6d0] text-gray-900', btnClass: 'bg-[#114232] text-white hover:bg-[#0a2a20]' },
  ];

  return (
    <div className="py-12 md:py-20 px-4 md:px-8 max-w-7xl mx-auto">
      <div className="text-center md:text-right mb-8 md:mb-12">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">خدماتنا</h2>
        <p className="text-gray-500 md:hidden">نقدم لك مجموعة متكاملة من الخدمات لتجعل رحلتك في سوريا لا تُنسى</p>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {services.map((s, i) => (
          <div key={i} className={`rounded-3xl p-6 md:p-8 flex flex-col items-center text-center gap-4 ${s.color} shadow-sm hover:shadow-md transition-shadow`}>
            <div className="p-4 bg-white/20 rounded-2xl backdrop-blur-sm mb-2">
              {s.icon}
            </div>
            <h3 className="text-xl font-bold">{s.title}</h3>
            <p className="text-sm opacity-90 leading-relaxed min-h-[40px]">{s.desc}</p>
            <button className={`mt-auto px-6 py-2.5 rounded-full transition-colors flex items-center gap-2 text-sm font-bold w-fit ${s.btnClass}`}>
              استكشف <ArrowLeft size={16} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function RecommendedStays() {
  const stays = [
    { title: 'فيلا فاخرة في طرطوس', price: '400,000', rating: 4.9, reviews: 32, guests: 10, beds: 5, baths: 5, image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=800&auto=format&fit=crop', type: 'فيلا' },
    { title: 'شقة عصرية في وسط حمص', price: '80,000', rating: 4.5, reviews: 15, guests: 4, beds: 2, baths: 1, image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=800&auto=format&fit=crop', type: 'شقة' },
    { title: 'بيت دمشقي قديم', price: '150,000', rating: 4.8, reviews: 24, guests: 6, beds: 3, baths: 2, image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?q=80&w=800&auto=format&fit=crop', type: 'بيت عربي' },
  ];

  return (
    <div className="py-8 md:py-12 px-4 md:px-8 max-w-7xl mx-auto overflow-hidden">
      <div className="flex justify-between items-end mb-8">
        <div>
          <p className="text-gray-500 text-sm mb-1 font-medium">الأكثر طلباً</p>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">إقامات مقترحة</h2>
        </div>
        <a href="#" className="text-primary font-bold flex items-center gap-1 hover:underline">
          عرض الكل <ArrowLeft size={18} />
        </a>
      </div>

      <div className="flex overflow-x-auto md:grid md:grid-cols-3 gap-6 pb-8 hide-scrollbar snap-x">
        {stays.map((stay, i) => (
          <div key={i} className="min-w-[85vw] md:min-w-0 snap-start group cursor-pointer">
            <div className="relative rounded-3xl overflow-hidden aspect-[4/3] mb-4 shadow-sm">
              <img src={stay.image} alt={stay.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <button className="absolute top-4 left-4 p-2.5 bg-white/90 rounded-full text-gray-400 hover:text-red-500 backdrop-blur-sm shadow-sm transition-colors">
                <Heart size={20} />
              </button>
              <span className="absolute top-4 right-4 bg-white/90 px-4 py-1.5 rounded-full text-xs font-bold text-gray-700 backdrop-blur-sm shadow-sm">
                {stay.type}
              </span>
            </div>
            
            <div className="flex justify-between items-start mb-2 px-1">
              <h3 className="font-bold text-gray-900 text-lg md:text-xl">{stay.title}</h3>
              <div className="flex items-center gap-1 text-sm bg-gray-100 px-2 py-1 rounded-lg">
                <Star className="text-yellow-500 fill-yellow-500" size={14} />
                <span className="font-bold text-gray-700">{stay.rating}</span>
                <span className="text-gray-400">({stay.reviews})</span>
              </div>
            </div>
            
            <div className="flex gap-4 text-gray-500 text-sm mb-4 px-1">
              <span className="flex items-center gap-1.5"><Users size={16}/> {stay.guests}</span>
              <span className="flex items-center gap-1.5"><Bed size={16}/> {stay.beds}</span>
              <span className="flex items-center gap-1.5"><Bath size={16}/> {stay.baths}</span>
            </div>
            
            <div className="flex justify-between items-center mt-2 px-1 border-t border-gray-100 pt-4">
              <p className="font-bold text-xl text-gray-900">{stay.price} <span className="text-sm font-normal text-gray-500">SYP / ليلة</span></p>
              <span className="text-primary text-sm font-bold hover:underline">تفاصيل</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CuratedTrips() {
  return (
    <div className="py-8 md:py-16 px-4 md:px-8 max-w-7xl mx-auto">
      <div className="bg-[#114232] rounded-[2.5rem] p-6 md:p-12 text-white flex flex-col md:flex-row gap-8 md:gap-16 items-center shadow-xl relative overflow-hidden">
        {/* Decorative background element */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
        
        <div className="flex-1 space-y-8 relative z-10 w-full">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-3">رحلات مختارة بعناية</h2>
            <p className="text-gray-300 text-base md:text-lg leading-relaxed">
              رحلاتنا الخاصة مصممة بعناية لتتجاوز المألوف. الوصول إلى مواقع أثرية خاصة، تناول الطعام في حدائق القصور الدمشقية السرية.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              <Landmark className="text-[#e6d5b8] mt-1 shrink-0" size={28} strokeWidth={1.5} />
              <div>
                <h4 className="font-bold text-lg mb-1">دخول تراثي خاص</h4>
                <p className="text-sm text-gray-400 leading-relaxed">دخول بعد ساعات العمل إلى المسجد الأموي وقاعات القلعة.</p>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              <Utensils className="text-[#e6d5b8] mt-1 shrink-0" size={28} strokeWidth={1.5} />
              <div>
                <h4 className="font-bold text-lg mb-1">إرث الطعام</h4>
                <p className="text-sm text-gray-400 leading-relaxed">تجارب طعام شامية تقليدية في قصور دمشق القديمة.</p>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              <ScrollText className="text-[#e6d5b8] mt-1 shrink-0" size={28} strokeWidth={1.5} />
              <div>
                <h4 className="font-bold text-lg mb-1">مرشدون مؤرخون</h4>
                <p className="text-sm text-gray-400 leading-relaxed">سفر مع خبراء يجعلون طريق الحرير حياً أمام عينيك.</p>
              </div>
            </div>
          </div>

          <button className="bg-[#e6d5b8] text-[#114232] font-bold px-8 py-4 rounded-full hover:bg-white transition-colors flex items-center justify-center gap-2 w-full md:w-auto shadow-lg">
            عرض الرحلات <ArrowLeft size={20} />
          </button>
        </div>

        <div className="flex-1 grid grid-cols-2 gap-4 w-full relative z-10">
          <img 
            src="https://images.unsplash.com/photo-1548013146-72479768bada?q=80&w=800&auto=format&fit=crop" 
            alt="Old Damascus" 
            className="rounded-3xl w-full h-48 md:h-[400px] object-cover shadow-lg" 
          />
          <img 
            src="https://images.unsplash.com/photo-1564507004663-b6dfb3c824d5?q=80&w=800&auto=format&fit=crop" 
            alt="Umayyad Mosque" 
            className="rounded-3xl w-full h-48 md:h-[400px] object-cover mt-8 md:mt-12 shadow-lg" 
          />
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="bg-white pt-16 pb-24 md:pb-12 border-t border-gray-100 mt-12">
      <div className="max-w-7xl mx-auto px-6 md:px-8 grid grid-cols-1 md:grid-cols-5 gap-12 md:gap-8">
        <div className="col-span-1 md:col-span-2 text-center md:text-right">
          <div className="text-4xl font-bold text-primary mb-4">ضيف</div>
          <p className="text-gray-500 mb-8 max-w-sm mx-auto md:mx-0">منصة سياحية سورية لاكتشاف جمال سوريا</p>
          <div className="flex justify-center md:justify-start gap-6 text-gray-400">
            <Globe size={24} className="hover:text-primary cursor-pointer transition-colors" />
            <Mail size={24} className="hover:text-primary cursor-pointer transition-colors" />
            <Twitter size={24} className="hover:text-primary cursor-pointer transition-colors" />
            <Share2 size={24} className="hover:text-primary cursor-pointer transition-colors" />
          </div>
        </div>
        
        <div className="text-center md:text-right">
          <h4 className="font-bold text-gray-900 mb-6 text-lg">خدمات</h4>
          <ul className="space-y-4 text-gray-500">
            <li><a href="#" className="hover:text-primary transition-colors">جولات سياحية</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">سياحة علاجية</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">عقارات</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">تعليم</a></li>
          </ul>
        </div>
        
        <div className="text-center md:text-right">
          <h4 className="font-bold text-gray-900 mb-6 text-lg">اكتشف</h4>
          <ul className="space-y-4 text-gray-500">
            <li><a href="#" className="hover:text-primary transition-colors">دمشق</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">حلب</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">تدمر</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">اللاذقية</a></li>
          </ul>
        </div>
        
        <div className="text-center md:text-right">
          <h4 className="font-bold text-gray-900 mb-6 text-lg">قانوني</h4>
          <ul className="space-y-4 text-gray-500">
            <li><a href="#" className="hover:text-primary transition-colors">الشروط</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">الخصوصية</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">اتصل بنا</a></li>
          </ul>
        </div>
      </div>
    </footer>
  );
}

function MobileBottomNav() {
  return (
    <div className="md:hidden fixed bottom-0 w-full bg-white border-t border-gray-100 flex justify-between px-6 py-2 pb-safe z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
      <button className="flex flex-col items-center gap-1 text-primary">
        <Home size={24} strokeWidth={2} />
        <span className="text-[10px] font-bold">الرئيسية</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-primary transition-colors">
        <Search size={24} strokeWidth={2} />
        <span className="text-[10px] font-medium">استكشاف</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-primary transition-colors">
        <Grid size={24} strokeWidth={2} />
        <span className="text-[10px] font-medium">الخدمات</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-primary transition-colors">
        <Heart size={24} strokeWidth={2} />
        <span className="text-[10px] font-medium">المفضلة</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-primary transition-colors">
        <User size={24} strokeWidth={2} />
        <span className="text-[10px] font-medium">حسابي</span>
      </button>
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <Navbar />
      <Hero />
      <Services />
      <RecommendedStays />
      <CuratedTrips />
      <Footer />
      <MobileBottomNav />
    </div>
  );
}

