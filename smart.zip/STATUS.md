# 📗 حالة مشروع ضيف

> **هذا الملف يعكس الواقع — وليس الحالة المثالية.**
> **حدّثه بعد كل جلسة عمل.**

---

## 🎯 المشروع
**منصة "ضيف"** — منصة سياحية سورية متكاملة  
**Stack:** Next.js 16 + TypeScript + Prisma + SQLite + Bun  
**Port:** 3000

---

## 📊 حالة الأنظمة الخمسة

| النظام | البنية | التنفيذ | الذكاء | الأولوية |
|--------|--------|---------|--------|---------|
| **1. المراجعة الذكية** | 85% | 30% | ❌ | 🔴 التالي |
| **2. تخطيط السفر الذكي** | 60% | 20% | ❌ | 🟠 Phase 2 |
| **3. الأدلة السياحية** | 75% | 55% | ❌ | 🟡 Phase 3 |
| **4. التجربة المتكاملة** | 90% | 70% | جزئي | 🟢 الأقوى |
| **5. المجتمع والسوق** | 80% | 50% | ❌ | 🟡 Phase 3 |

---

## ✅ ما تم بناؤه (الأساس)

### Core Layer — مكتمل
- ✅ كيانات الدومين: User, Booking, Listing, Payment
- ✅ نظام الأحداث (Event Bus)
- ✅ نظام الصلاحيات (Authorization)
- ✅ أنواع TypeScript المشتركة

### نظام التجربة المتكاملة (الأقوى)
- ✅ Listings: بحث، تفاصيل، توفر، أسعار
- ✅ Bookings: نموذج حجز كامل
- ✅ Escrow: نظام ضمان مالي ✨
- ✅ Disputes: حل نزاعات ✨
- ✅ Payments: معالجة مدفوعات
- ✅ Notifications: نظام إشعارات (أساسي)

### نظام المجتمع والسوق (القاعدة)
- ✅ Topics + Replies (منتديات)
- ✅ Products + Cart + Orders (Marketplace)
- ✅ Companies + موظفين
- ✅ UserVerification

### نظام الأدلة السياحية (البيانات)
- ✅ Destinations (وجهات + صور + تفاصيل)
- ✅ Activities (أنشطة + شروط + أسعار)
- ✅ Tours + TourDays
- ✅ دعم اللغة العربية

### البنية التحتية
- ✅ Prisma + SQLite
- ✅ NextAuth.js + JWT
- ✅ Zustand + TanStack Query
- ✅ shadcn/ui مع RTL
- ✅ z-ai-web-dev-sdk (جاهز، غير مُفعّل)
- ✅ نظام التوجيه (6 ملفات .specify/)

---

## 🔴 ما يحتاج بناء (بالأولوية)

### Phase التالية: نظام المراجعة الذكي

**النماذج المطلوبة:**
- [ ] `ReviewCriteria` (cleanliness, accuracy, location, value, service)
- [ ] `ReviewHelpful` (تصويت مفيد/غير مفيد)
- [ ] `ReviewerBadge` (TOP_REVIEWER, EXPERT, VERIFIED_TRAVELER)

**الخدمات المطلوبة:**
- [ ] Review creation بعد `booking.completed`
- [ ] عرض المراجعات على Listings
- [ ] خوارزمية ترتيب كلاسيكية
- [ ] نظام التصويت على المفيد
- [ ] (AI لاحقاً) Sentiment Analysis
- [ ] (AI لاحقاً) AI Summary

**الأحداث المطلوبة:**
- [ ] `review.created` → يُغذي TrustScore, Gamification
- [ ] `review.helpful_voted` → يُغذي ReviewerLevel

---

### فجوات نظام التجربة المتكاملة
- [ ] Chat/Messaging (Socket.io)
- [ ] Check-in System (QR)
- [ ] Smart Notifications (تذكيرات ذكية بالتوقيت)
- [ ] Post-booking Journey (Review prompt → Loyalty flow)

### فجوات نظام التخطيط (Phase 2)
- [ ] `Itinerary` + `ItineraryDay` models
- [ ] `ViewTracking` (سجل المشاهدات)
- [ ] Recommendation Engine (كلاسيكي أولاً)
- [ ] AI Trip Planner

### فجوات نظام المجتمع
- [ ] Trust Score (مبني على المراجعات)
- [ ] Gamification (نقاط + شارات + مستويات)
- [ ] Community Content (Tips/Photos)

---

## 📍 الحالة الآن

### نعمل على:
نظام التوجيه الذكي (.specify/) — اكتمل ✅

### الملف/الوحدة الحالية:
`.specify/` — نظام السياق

### العقبات:
لا توجد

---

## ⏭️ الخطوات التالية

1. **Phase 15 — نظام المراجعة:**
   - Prisma models (ReviewCriteria, ReviewHelpful, ReviewerBadge)
   - Review creation use-case
   - Review listing page

2. **Phase 16 — نظام Gamification:**
   - Trust Score calculation
   - Points + Badges

3. **Phase 17 — Chat System:**
   - Socket.io setup
   - Booking chat channel

---

## 🔧 معلومات تقنية

| العنصر | القيمة |
|--------|--------|
| Framework | Next.js 16 |
| Runtime | Bun |
| Database | SQLite (Prisma) — راجع ADR-002 |
| Port | 3000 |
| AI SDK | z-ai-web-dev-sdk (جاهز) |

---

## 📝 سجل الإنجازات الأخيرة

### [2025-03 — اليوم]
- ✅ بناء نظام التوجيه الذكي (.specify/ — 6 ملفات)
- ✅ تشخيص شامل للأنظمة الخمسة
- ✅ توثيق الفجوات والأولويات

### [سابقاً]
- ✅ Core كامل (entities, events, authorization)
- ✅ Infrastructure كامل (repositories, services, providers)
- ✅ Application layer كامل
- ✅ جميع APIs الأساسية
- ✅ نظام Escrow + Disputes ✨
- ✅ واجهة المستخدم (shadcn/ui + RTL)
- ✅ الهجرة من React Native → Next.js 16
