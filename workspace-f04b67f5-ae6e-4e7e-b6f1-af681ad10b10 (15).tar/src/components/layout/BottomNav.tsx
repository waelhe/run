/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Bottom Navigation Component
 * 
 * شريط التنقل السفلي للموبايل - نبض الضاحية
 */

'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, ShoppingBag, Users, User, Phone, LayoutGrid } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function BottomNav() {
  const pathname = usePathname();
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  const navItems = [
    { name: isArabic ? 'الرئيسية' : 'Home', path: '/', icon: Home },
    { name: isArabic ? 'السوق' : 'Market', path: '/marketplace', icon: ShoppingBag },
    { name: isArabic ? 'خدمات' : 'Services', path: '/services', icon: LayoutGrid },
    { name: isArabic ? 'طوارئ' : 'Emergency', path: 'tel:112', icon: Phone, isTel: true },
    { name: isArabic ? 'مجتمع' : 'Community', path: '/community', icon: Users },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-gray-200 z-50 md:hidden pb-safe">
      <div className="flex justify-around items-center h-14 px-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.path;
          
          if (item.isTel) {
            return (
              <a
                key={item.path}
                href={item.path}
                className="flex flex-col items-center justify-center w-full h-full gap-0.5 text-red-500 hover:text-red-600 transition-all"
              >
                <div className="flex items-center justify-center h-5 w-5 bg-red-100 rounded-full">
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <span className="font-bold whitespace-nowrap text-[9px]">{item.name}</span>
              </a>
            );
          }

          return (
            <Link
              key={item.path}
              href={item.path}
              className={`flex flex-col items-center justify-center w-full h-full gap-0.5 transition-all ${
                isActive ? 'text-emerald-600' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center justify-center h-5 w-5">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[2]'}`} />
              </div>
              <span className="font-bold whitespace-nowrap text-[9px]">{item.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
