'use client';

import React from 'react';
import { Heart, Users, Gift, HandHeart, Phone, MapPin, Clock, Droplets } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface Charity {
  id: string;
  name: string;
  nameEn: string;
  type: string;
  typeEn: string;
  icon: React.ElementType;
  color: string;
  description: string;
  descriptionEn: string;
  phone: string;
  location: string;
}

interface Campaign {
  id: string;
  title: string;
  titleEn: string;
  icon: React.ElementType;
  target: string;
  current: string;
  progress: number;
}

const qudsayaCenterCharities: Charity[] = [
  {
    id: '1',
    name: 'جمعية البر الخيرية',
    nameEn: 'Al-Birr Charity',
    type: 'إغاثة',
    typeEn: 'Relief',
    icon: HandHeart,
    color: 'bg-rose-600',
    description: 'مساعدة الأسر المحتاجة واليتامى في قدسيا',
    descriptionEn: 'Helping needy families and orphans in Qudsaya',
    phone: '011-1234567',
    location: 'قدسيا - الحي الرئيسي'
  },
  {
    id: '2',
    name: 'بنك الطعام قدسيا',
    nameEn: 'Qudsaya Food Bank',
    type: 'غذائي',
    typeEn: 'Food',
    icon: Gift,
    color: 'bg-orange-600',
    description: 'توزيع الطعام على المحتاجين',
    descriptionEn: 'Food distribution to the needy',
    phone: '011-2345678',
    location: 'قدسيا - الساحة'
  },
  {
    id: '3',
    name: 'مؤسسة الأمل',
    nameEn: 'Al-Amal Foundation',
    type: 'صحي',
    typeEn: 'Health',
    icon: Heart,
    color: 'bg-red-600',
    description: 'علاج المرضى المحتاجين',
    descriptionEn: 'Treating needy patients',
    phone: '011-3456789',
    location: 'قدسيا'
  },
  {
    id: '4',
    name: 'جمعية التعليم الخيري',
    nameEn: 'Charity Education Association',
    type: 'تعليم',
    typeEn: 'Education',
    icon: Users,
    color: 'bg-blue-600',
    description: 'دعم تعليم الطلاب المحتاجين',
    descriptionEn: 'Supporting needy students education',
    phone: '011-4567890',
    location: 'قدسيا'
  }
];

const qudsayaDahiaCharities: Charity[] = [
  {
    id: '1',
    name: 'جمعية الخير الخيرية',
    nameEn: 'Al-Kheir Charity',
    type: 'إغاثة',
    typeEn: 'Relief',
    icon: HandHeart,
    color: 'bg-rose-600',
    description: 'مساعدة الأسر المحتاجة في الضاحية',
    descriptionEn: 'Helping needy families in Dahia',
    phone: '011-2234567',
    location: 'الضاحية - الحي الرئيسي'
  },
  {
    id: '2',
    name: 'بنك الطعام الضاحية',
    nameEn: 'Dahia Food Bank',
    type: 'غذائي',
    typeEn: 'Food',
    icon: Gift,
    color: 'bg-orange-600',
    description: 'توزيع الطعام على المحتاجين',
    descriptionEn: 'Food distribution to the needy',
    phone: '011-3345678',
    location: 'الضاحية - المركز'
  },
  {
    id: '3',
    name: 'جمعية الشفاء',
    nameEn: 'Al-Shifa Association',
    type: 'صحي',
    typeEn: 'Health',
    icon: Heart,
    color: 'bg-red-600',
    description: 'رعاية صحية مجانية',
    descriptionEn: 'Free healthcare',
    phone: '011-4456789',
    location: 'الضاحية'
  },
  {
    id: '4',
    name: 'جمعية النور التعليمية',
    nameEn: 'Al-Noor Education',
    type: 'تعليم',
    typeEn: 'Education',
    icon: Users,
    color: 'bg-blue-600',
    description: 'دروس مجانية للطلاب',
    descriptionEn: 'Free tutoring for students',
    phone: '011-5567890',
    location: 'الضاحية'
  }
];

const qudsayaCenterCampaigns: Campaign[] = [
  {
    id: '1',
    title: 'سقيا الماء',
    titleEn: 'Water Wells',
    icon: Droplets,
    target: '50,000$',
    current: '35,000$',
    progress: 70
  },
  {
    id: '2',
    title: 'كسوة العيد',
    titleEn: 'Eid Clothing',
    icon: Gift,
    target: '20,000$',
    current: '16,000$',
    progress: 80
  }
];

const qudsayaDahiaCampaigns: Campaign[] = [
  {
    id: '1',
    title: 'إفطار صائم',
    titleEn: 'Ramadan Iftar',
    icon: Gift,
    target: '30,000$',
    current: '22,000$',
    progress: 73
  },
  {
    id: '2',
    title: 'علاج المرضى',
    titleEn: 'Medical Treatment',
    icon: Heart,
    target: '40,000$',
    current: '28,000$',
    progress: 70
  }
];

const dataByRegion: Record<Region, { charities: Charity[]; campaigns: Campaign[] }> = {
  'qudsaya-center': { charities: qudsayaCenterCharities, campaigns: qudsayaCenterCampaigns },
  'qudsaya-dahia': { charities: qudsayaDahiaCharities, campaigns: qudsayaDahiaCampaigns }
};

export default function Charity() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const { charities, campaigns } = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-pink-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-pink-600 rounded-2xl shadow-lg">
              <HandHeart className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'المؤسسات الخيرية' : 'Charity Organizations'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `ساعد المحتاجين في ${regionName}` : `Help the needy in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {charities.map((charity, index) => {
            const Icon = charity.icon;
            return (
              <motion.div
                key={charity.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
              >
                <div className="p-4">
                  <div className={`w-12 h-12 ${charity.color} rounded-xl flex items-center justify-center mb-3`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-[10px] px-2 py-0.5 bg-pink-100 text-pink-700 rounded-full">
                    {isArabic ? charity.type : charity.typeEn}
                  </span>
                  <h3 className="text-sm font-bold text-gray-900 mt-2 mb-1">
                    {isArabic ? charity.name : charity.nameEn}
                  </h3>
                  <p className="text-xs text-gray-500 mb-3 line-clamp-1">
                    {isArabic ? charity.description : charity.descriptionEn}
                  </p>
                  <div className="flex items-center gap-2">
                    <button className="flex-1 flex items-center justify-center gap-1 bg-pink-600 hover:bg-pink-700 text-white py-1.5 rounded-lg text-xs font-medium transition-colors">
                      <Phone className="w-3 h-3" />
                      {isArabic ? 'اتصل' : 'Call'}
                    </button>
                    <button className="flex-1 flex items-center justify-center gap-1 bg-white border border-pink-600 text-pink-600 hover:bg-pink-50 py-1.5 rounded-lg text-xs font-medium transition-colors">
                      <HandHeart className="w-3 h-3" />
                      {isArabic ? 'تبرع' : 'Donate'}
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Active Campaigns */}
        <div className="bg-gradient-to-r from-pink-600 to-rose-600 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <Gift className="w-5 h-5 text-white" />
            <span className="text-white font-bold">{isArabic ? 'حملات نشطة' : 'Active Campaigns'}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {campaigns.map((campaign) => {
              const Icon = campaign.icon;
              return (
                <div key={campaign.id} className="bg-white/20 backdrop-blur rounded-xl p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 bg-white/30 rounded-lg flex items-center justify-center">
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-white font-medium text-sm">
                      {isArabic ? campaign.title : campaign.titleEn}
                    </span>
                  </div>
                  <div className="h-2 bg-white/30 rounded-full overflow-hidden mb-1">
                    <div className="h-full bg-white rounded-full" style={{ width: `${campaign.progress}%` }} />
                  </div>
                  <div className="flex justify-between text-xs text-white/80">
                    <span>{campaign.current}</span>
                    <span>{isArabic ? 'الهدف:' : 'Target:'} {campaign.target}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
