'use client';

import React from 'react';
import { Sun, Cloud, CloudRain, Droplets, Wind, Thermometer, MapPin, Eye, Gauge } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface WeatherData {
  temperature: number;
  feelsLike: number;
  condition: string;
  conditionEn: string;
  humidity: number;
  windSpeed: number;
  visibility: number;
  pressure: number;
  high: number;
  low: number;
  location: string;
  locationEn: string;
}

const qudsayaCenterWeather: WeatherData = {
  temperature: 27,
  feelsLike: 29,
  condition: 'مشمس',
  conditionEn: 'Sunny',
  humidity: 42,
  windSpeed: 10,
  visibility: 12,
  pressure: 1018,
  high: 31,
  low: 21,
  location: 'قدسيا، دمشق، سوريا',
  locationEn: 'Qudsaya, Damascus, Syria'
};

const qudsayaDahiaWeather: WeatherData = {
  temperature: 28,
  feelsLike: 30,
  condition: 'مشمس',
  conditionEn: 'Sunny',
  humidity: 45,
  windSpeed: 12,
  visibility: 10,
  pressure: 1015,
  high: 32,
  low: 22,
  location: 'ضاحية قدسيا، دمشق، سوريا',
  locationEn: 'Qudsaya Dahia, Damascus, Syria'
};

const dataByRegion: Record<Region, WeatherData> = {
  'qudsaya-center': qudsayaCenterWeather,
  'qudsaya-dahia': qudsayaDahiaWeather
};

export default function WeatherWidget() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const weatherData = dataByRegion[region];

  return (
    <section className="py-5 bg-gradient-to-b from-sky-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-sky-500 via-blue-500 to-indigo-600 rounded-3xl p-6 text-white shadow-2xl shadow-blue-200/50"
        >
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Main Weather Info */}
            <div className="flex items-center gap-6 flex-1">
              <div className="p-5 bg-white/20 rounded-3xl backdrop-blur-sm border border-white/30">
                <Sun className="w-20 h-20 text-yellow-300" />
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-7xl font-black">{weatherData.temperature}</span>
                  <span className="text-3xl font-bold">°C</span>
                </div>
                <p className="text-sky-100 text-2xl font-medium mt-1">
                  {isArabic ? weatherData.condition : weatherData.conditionEn}
                </p>
                <p className="text-sky-200 text-lg mt-1">
                  {isArabic 
                    ? `تشعر كـ ${weatherData.feelsLike}°`
                    : `Feels like ${weatherData.feelsLike}°`}
                </p>
              </div>
            </div>

            {/* Weather Details */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 flex-1">
              <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <Thermometer className="w-5 h-5 text-sky-200" />
                  <span className="text-sm text-sky-200 font-medium">
                    {isArabic ? 'العظمى / الصغرى' : 'High / Low'}
                  </span>
                </div>
                <p className="text-2xl font-bold">
                  {weatherData.high}° / {weatherData.low}°
                </p>
              </div>

              <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <Droplets className="w-5 h-5 text-sky-200" />
                  <span className="text-sm text-sky-200 font-medium">
                    {isArabic ? 'الرطوبة' : 'Humidity'}
                  </span>
                </div>
                <p className="text-2xl font-bold">{weatherData.humidity}%</p>
              </div>

              <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <Wind className="w-5 h-5 text-sky-200" />
                  <span className="text-sm text-sky-200 font-medium">
                    {isArabic ? 'الرياح' : 'Wind'}
                  </span>
                </div>
                <p className="text-2xl font-bold">{weatherData.windSpeed} km/h</p>
              </div>

              <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm border border-white/20">
                <div className="flex items-center gap-2 mb-2">
                  <Eye className="w-5 h-5 text-sky-200" />
                  <span className="text-sm text-sky-200 font-medium">
                    {isArabic ? 'الرؤية' : 'Visibility'}
                  </span>
                </div>
                <p className="text-2xl font-bold">{weatherData.visibility} km</p>
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="mt-5 pt-5 border-t border-white/20 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sky-100">
              <MapPin className="w-5 h-5" />
              <span className="text-lg font-medium">
                {isArabic ? weatherData.location : weatherData.locationEn}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sky-200 text-sm">
                {isArabic ? 'آخر تحديث: الآن' : 'Last updated: now'}
              </span>
              <RegionSelector />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
