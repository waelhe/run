'use client';

import React from 'react';
import { Tag, MapPin, Clock, DollarSign, Megaphone } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface Classified {
  id: string;
  title: string;
  titleEn: string;
  price: string;
  category: string;
  categoryEn: string;
  image: string;
  location: string;
  time: string;
  timeEn: string;
}

const qudsayaCenterClassifieds: Classified[] = [
  {
    id: '1',
    title: 'سيارة تويوتا كامري 2020',
    titleEn: 'Toyota Camry 2020',
    price: '35,000',
    category: 'سيارات',
    categoryEn: 'Cars',
    image: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ ساعتين',
    timeEn: '2 hours ago'
  },
  {
    id: '2',
    title: 'أريكة جلدية فاخرة',
    titleEn: 'Luxury Leather Sofa',
    price: '1,200',
    category: 'أثاث',
    categoryEn: 'Furniture',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ يوم',
    timeEn: '1 day ago'
  },
  {
    id: '3',
    title: 'آيفون 15 برو ماكس',
    titleEn: 'iPhone 15 Pro Max',
    price: '1,800',
    category: 'إلكترونيات',
    categoryEn: 'Electronics',
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ 3 ساعات',
    timeEn: '3 hours ago'
  },
  {
    id: '4',
    title: 'غسالة سامسونج جديدة',
    titleEn: 'Samsung Washing Machine',
    price: '650',
    category: 'أجهزة',
    categoryEn: 'Appliances',
    image: 'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ 5 ساعات',
    timeEn: '5 hours ago'
  }
];

const qudsayaDahiaClassifieds: Classified[] = [
  {
    id: '1',
    title: 'سيارة هيونداي سوناتا 2019',
    titleEn: 'Hyundai Sonata 2019',
    price: '28,000',
    category: 'سيارات',
    categoryEn: 'Cars',
    image: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ ساعة',
    timeEn: '1 hour ago'
  },
  {
    id: '2',
    title: 'طقم كنب مودرن',
    titleEn: 'Modern Sofa Set',
    price: '950',
    category: 'أثاث',
    categoryEn: 'Furniture',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ يومين',
    timeEn: '2 days ago'
  },
  {
    id: '3',
    title: 'لابتوب ديل XPS',
    titleEn: 'Dell XPS Laptop',
    price: '1,200',
    category: 'إلكترونيات',
    categoryEn: 'Electronics',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ 4 ساعات',
    timeEn: '4 hours ago'
  },
  {
    id: '4',
    title: 'ثلاجة ال جي جديدة',
    titleEn: 'LG Refrigerator New',
    price: '700',
    category: 'أجهزة',
    categoryEn: 'Appliances',
    image: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ 6 ساعات',
    timeEn: '6 hours ago'
  }
];

const dataByRegion: Record<Region, Classified[]> = {
  'qudsaya-center': qudsayaCenterClassifieds,
  'qudsaya-dahia': qudsayaDahiaClassifieds
};

export default function Classifieds() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const classifieds = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-violet-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-violet-600 rounded-2xl shadow-lg">
              <Megaphone className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'الإعلانات المبوبة' : 'Classifieds'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `بيع وشراء في ${regionName}` : `Buy and sell in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {classifieds.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-32 overflow-hidden">
                <img src={item.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <span className="absolute top-2 right-2 px-2 py-1 bg-violet-600 text-white text-[10px] font-bold rounded-full">
                  {isArabic ? item.category : item.categoryEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1 line-clamp-1">
                  {isArabic ? item.title : item.titleEn}
                </h3>
                <div className="flex items-center gap-1 mb-2">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span className="text-sm font-black text-emerald-600">{item.price}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    <span>{item.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{isArabic ? item.time : item.timeEn}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
