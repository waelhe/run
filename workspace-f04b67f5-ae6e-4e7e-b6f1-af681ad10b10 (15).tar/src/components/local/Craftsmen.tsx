'use client';

import React from 'react';
import { Wrench, Phone, Star, MapPin, Clock, Shield } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface Craftsman {
  id: string;
  name: string;
  nameEn: string;
  profession: string;
  professionEn: string;
  rating: number;
  reviews: number;
  image: string;
  available: boolean;
  phone: string;
}

const qudsayaCenterCraftsmen: Craftsman[] = [
  {
    id: '1',
    name: 'أحمد الكهربائي',
    nameEn: 'Ahmed Electrician',
    profession: 'كهربائي',
    professionEn: 'Electrician',
    rating: 4.9,
    reviews: 160,
    image: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80',
    available: true,
    phone: '0999123456'
  },
  {
    id: '2',
    name: 'محمود السباك',
    nameEn: 'Mahmoud Plumber',
    profession: 'سباك',
    professionEn: 'Plumber',
    rating: 4.7,
    reviews: 95,
    image: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=600&q=80',
    available: true,
    phone: '0998765432'
  },
  {
    id: '3',
    name: 'خالد النجار',
    nameEn: 'Khaled Carpenter',
    profession: 'نجار',
    professionEn: 'Carpenter',
    rating: 4.8,
    reviews: 70,
    image: 'https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=600&q=80',
    available: false,
    phone: '0997654321'
  },
  {
    id: '4',
    name: 'يوسف الدهان',
    nameEn: 'Youssef Painter',
    profession: 'دهان',
    professionEn: 'Painter',
    rating: 4.6,
    reviews: 50,
    image: 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&w=600&q=80',
    available: true,
    phone: '0996543210'
  }
];

const qudsayaDahiaCraftsmen: Craftsman[] = [
  {
    id: '1',
    name: 'سامي الكهربائي',
    nameEn: 'Sami Electrician',
    profession: 'كهربائي',
    professionEn: 'Electrician',
    rating: 4.8,
    reviews: 145,
    image: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80',
    available: true,
    phone: '0999234567'
  },
  {
    id: '2',
    name: 'عمر السباك',
    nameEn: 'Omar Plumber',
    profession: 'سباك',
    professionEn: 'Plumber',
    rating: 4.9,
    reviews: 110,
    image: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=600&q=80',
    available: true,
    phone: '0998345678'
  },
  {
    id: '3',
    name: 'فادي النجار',
    nameEn: 'Fadi Carpenter',
    profession: 'نجار',
    professionEn: 'Carpenter',
    rating: 4.7,
    reviews: 85,
    image: 'https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=600&q=80',
    available: true,
    phone: '0997456789'
  },
  {
    id: '4',
    name: 'رامي الدهان',
    nameEn: 'Rami Painter',
    profession: 'دهان',
    professionEn: 'Painter',
    rating: 4.5,
    reviews: 60,
    image: 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&w=600&q=80',
    available: false,
    phone: '0996567890'
  }
];

const dataByRegion: Record<Region, Craftsman[]> = {
  'qudsaya-center': qudsayaCenterCraftsmen,
  'qudsaya-dahia': qudsayaDahiaCraftsmen
};

export default function Craftsmen() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const craftsmen = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-stone-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-stone-600 rounded-2xl shadow-lg">
              <Wrench className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'الحرفيين' : 'Craftsmen'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `أفضل الحرفيين في ${regionName}` : `Best craftsmen in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {craftsmen.map((craftsman, index) => (
            <motion.div
              key={craftsman.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-28 overflow-hidden">
                <img src={craftsman.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <span className={`absolute top-2 right-2 px-2 py-1 text-[10px] font-bold rounded-full ${
                  craftsman.available ? 'bg-emerald-500 text-white' : 'bg-gray-500 text-white'
                }`}>
                  {craftsman.available ? (isArabic ? 'متاح' : 'Available') : (isArabic ? 'مشغول' : 'Busy')}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1">
                  {isArabic ? craftsman.name : craftsman.nameEn}
                </h3>
                <span className="text-xs px-2 py-0.5 bg-stone-100 text-stone-700 rounded-full">
                  {isArabic ? craftsman.profession : craftsman.professionEn}
                </span>
                <div className="flex items-center gap-1 mt-2">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-bold text-gray-900">{craftsman.rating}</span>
                  <span className="text-xs text-gray-400">({craftsman.reviews})</span>
                </div>
                <button className="w-full mt-3 flex items-center justify-center gap-2 bg-stone-600 hover:bg-stone-700 text-white py-2 rounded-xl text-sm font-medium transition-colors">
                  <Phone className="w-4 h-4" />
                  {isArabic ? 'اتصل' : 'Call'}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
