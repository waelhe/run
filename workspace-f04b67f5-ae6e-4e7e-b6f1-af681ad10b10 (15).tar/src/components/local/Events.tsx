'use client';

import React from 'react';
import { Calendar, MapPin, Clock, Users, ArrowLeft, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface Event {
  id: string;
  title: string;
  titleEn: string;
  date: string;
  time: string;
  location: string;
  locationEn: string;
  attendees: number;
  image: string;
}

const qudsayaCenterEvents: Event[] = [
  {
    id: '1',
    title: 'مهرجان الربيع الثقافي',
    titleEn: 'Spring Cultural Festival',
    date: '25 مارس 2025',
    time: '4:00 مساءً',
    location: 'ساحة قدسيا',
    locationEn: 'Qudsaya Square',
    attendees: 300,
    image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '2',
    title: 'بطولة كرة القدم',
    titleEn: 'Football Championship',
    date: '27 مارس 2025',
    time: '5:00 مساءً',
    location: 'ملعب قدسيا',
    locationEn: 'Qudsaya Stadium',
    attendees: 600,
    image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=600&q=80'
  }
];

const qudsayaDahiaEvents: Event[] = [
  {
    id: '1',
    title: 'مهرجان الربيع الثقافي',
    titleEn: 'Spring Cultural Festival',
    date: '25 مارس 2025',
    time: '4:00 مساءً',
    location: 'ساحة الضاحية',
    locationEn: 'Dahia Square',
    attendees: 250,
    image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '2',
    title: 'بطولة كرة القدم',
    titleEn: 'Football Championship',
    date: '27 مارس 2025',
    time: '5:00 مساءً',
    location: 'ملعب الضاحية',
    locationEn: 'Dahia Stadium',
    attendees: 500,
    image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=600&q=80'
  }
];

const dataByRegion: Record<Region, Event[]> = {
  'qudsaya-center': qudsayaCenterEvents,
  'qudsaya-dahia': qudsayaDahiaEvents
};

export default function Events() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const events = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-purple-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-600 rounded-2xl shadow-lg">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'الفعاليات القادمة' : 'Upcoming Events'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `أنشطة وفعاليات في ${regionName}` : `Activities and events in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden"
            >
              <div className="relative h-40 overflow-hidden">
                <img src={event.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-3 right-3 left-3">
                  <h3 className="text-lg font-bold text-white">
                    {isArabic ? event.title : event.titleEn}
                  </h3>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-center gap-3 text-sm text-gray-600 mb-2">
                  <Calendar className="w-4 h-4 text-purple-500" />
                  <span>{event.date}</span>
                  <Clock className="w-4 h-4 text-purple-500" />
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <MapPin className="w-4 h-4 text-purple-500" />
                    <span>{isArabic ? event.location : event.locationEn}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-purple-600 font-medium">
                    <Users className="w-4 h-4" />
                    <span>{event.attendees}+</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
