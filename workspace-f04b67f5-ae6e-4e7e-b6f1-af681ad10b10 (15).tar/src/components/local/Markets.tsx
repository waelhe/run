'use client';

import React from 'react';
import { ShoppingCart, MapPin, Clock, Truck, Star, Store } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRegion, Region } from '@/contexts/RegionContext';
import RegionSelector from './RegionSelector';

interface Market {
  id: string;
  name: string;
  nameEn: string;
  type: string;
  typeEn: string;
  image: string;
  location: string;
  hours: string;
  rating: number;
}

interface Supermarket {
  name: string;
  nameEn: string;
  delivery: boolean;
}

// بيانات ضاحية قدسيا
const qudsayaDahiaMarkets: Market[] = [
  {
    id: '1',
    name: 'سوق الخضار - الضاحية',
    nameEn: 'Vegetable Market - Dahia',
    type: 'خضار وفواكه',
    typeEn: 'Vegetables & Fruits',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية - الساحة',
    hours: '5:00 - 14:00',
    rating: 4.5
  },
  {
    id: '2',
    name: 'سوق اللحوم',
    nameEn: 'Meat Market',
    type: 'لحوم',
    typeEn: 'Meat',
    image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية - الشمال',
    hours: '6:00 - 16:00',
    rating: 4.7
  },
  {
    id: '3',
    name: 'سوق الأسماك',
    nameEn: 'Fish Market',
    type: 'أسماك',
    typeEn: 'Fish',
    image: 'https://images.unsplash.com/photo-1534604973900-c43ab4c2e0ab?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية - الجنوب',
    hours: '6:00 - 14:00',
    rating: 4.4
  },
  {
    id: '4',
    name: 'سوق الملابس',
    nameEn: 'Clothes Market',
    type: 'ملابس',
    typeEn: 'Clothes',
    image: 'https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية - الساحة',
    hours: '8:00 - 20:00',
    rating: 4.3
  }
];

const qudsayaDahiaSupermarkets: Supermarket[] = [
  { name: 'سوبرماركت الأهلية', nameEn: 'Ahliya Supermarket', delivery: true },
  { name: 'ماركت الضاحية', nameEn: 'Dahia Market', delivery: true },
  { name: 'سوبر ستور', nameEn: 'Super Store', delivery: true }
];

// بيانات قدسيا المركز
const qudsayaCenterMarkets: Market[] = [
  {
    id: 'q1',
    name: 'سوق الخضار - قدسيا',
    nameEn: 'Vegetable Market - Qudsaya',
    type: 'خضار وفواكه',
    typeEn: 'Vegetables & Fruits',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا - الساحة الرئيسية',
    hours: '5:00 - 15:00',
    rating: 4.6
  },
  {
    id: 'q2',
    name: 'سوق اللحوم',
    nameEn: 'Meat Market',
    type: 'لحوم',
    typeEn: 'Meat',
    image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا - المدخل',
    hours: '6:00 - 17:00',
    rating: 4.8
  },
  {
    id: 'q3',
    name: 'سوق الأسماك الطازجة',
    nameEn: 'Fresh Fish Market',
    type: 'أسماك',
    typeEn: 'Fish',
    image: 'https://images.unsplash.com/photo-1534604973900-c43ab4c2e0ab?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا - الشرق',
    hours: '6:00 - 13:00',
    rating: 4.5
  },
  {
    id: 'q4',
    name: 'سوق الملابس الشعبي',
    nameEn: 'Popular Clothes Market',
    type: 'ملابس',
    typeEn: 'Clothes',
    image: 'https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا - الساحة',
    hours: '9:00 - 21:00',
    rating: 4.4
  }
];

const qudsayaCenterSupermarkets: Supermarket[] = [
  { name: 'سوبرماركت قدسيا', nameEn: 'Qudsaya Supermarket', delivery: true },
  { name: 'ماركت الجبل', nameEn: 'Mountain Market', delivery: true },
  { name: 'ميني ماركت', nameEn: 'Mini Mart', delivery: false }
];

const dataByRegion: Record<Region, { markets: Market[]; supermarkets: Supermarket[] }> = {
  'qudsaya-center': { markets: qudsayaCenterMarkets, supermarkets: qudsayaCenterSupermarkets },
  'qudsaya-dahia': { markets: qudsayaDahiaMarkets, supermarkets: qudsayaDahiaSupermarkets }
};

export default function Markets() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const { markets, supermarkets } = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-lime-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-lime-600 rounded-2xl shadow-lg">
              <ShoppingCart className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'الأسواق' : 'Markets'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `أسواق ${regionName} الشعبية` : `Popular markets in ${regionName}`}
              </p>
            </div>
          </div>
          
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {markets.map((market, index) => (
            <motion.div
              key={market.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-28 overflow-hidden">
                <img src={market.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <span className="absolute top-2 right-2 px-2 py-1 bg-lime-600 text-white text-[10px] font-bold rounded-full">
                  {isArabic ? market.type : market.typeEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1">
                  {isArabic ? market.name : market.nameEn}
                </h3>
                <div className="flex items-center gap-1 mb-1">
                  <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span className="text-xs font-medium text-gray-900">{market.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500 mb-1">
                  <MapPin className="w-3 h-3" />
                  <span className="line-clamp-1">{market.location}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{market.hours}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Supermarkets with delivery */}
        <div className="bg-gradient-to-r from-lime-600 to-green-600 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <Store className="w-5 h-5 text-white" />
            <span className="text-white font-bold">{isArabic ? 'سوبرماركت مع توصيل' : 'Supermarkets with Delivery'}</span>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {supermarkets.map((market, index) => (
              <div key={index} className="bg-white/20 backdrop-blur rounded-xl p-3 flex items-center justify-between">
                <span className="text-white font-medium text-sm">{isArabic ? market.name : market.nameEn}</span>
                {market.delivery && (
                  <div className="flex items-center gap-1 text-white/80 text-xs">
                    <Truck className="w-3 h-3" />
                    <span>{isArabic ? 'توصيل' : 'Delivery'}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
