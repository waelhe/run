'use client';

import React from 'react';
import { Heart, Users, HandHeart, Gift, Calendar, MapPin, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface CommunityService {
  id: string;
  name: string;
  nameEn: string;
  type: string;
  typeEn: string;
  icon: React.ElementType;
  color: string;
  description: string;
  descriptionEn: string;
}

interface VolunteerOpp {
  id: string;
  title: string;
  titleEn: string;
  date: string;
  location: string;
}

const qudsayaCenterServices: CommunityService[] = [
  {
    id: '1',
    name: 'جمعية البر الخيرية - قدسيا',
    nameEn: 'Al-Birr Charity - Qudsaya',
    type: 'خيري',
    typeEn: 'Charity',
    icon: HandHeart,
    color: 'bg-rose-600',
    description: 'مساعدة الأسر المحتاجة في قدسيا',
    descriptionEn: 'Helping needy families in Qudsaya'
  },
  {
    id: '2',
    name: 'مركز شباب قدسيا',
    nameEn: 'Qudsaya Youth Center',
    type: 'شبابي',
    typeEn: 'Youth',
    icon: Users,
    color: 'bg-indigo-600',
    description: 'أنشطة وبرامج شبابية',
    descriptionEn: 'Youth activities and programs'
  },
  {
    id: '3',
    name: 'بنك طعام قدسيا',
    nameEn: 'Qudsaya Food Bank',
    type: 'إنساني',
    typeEn: 'Humanitarian',
    icon: Gift,
    color: 'bg-orange-600',
    description: 'توزيع الطعام للمحتاجين',
    descriptionEn: 'Food distribution for needy'
  },
  {
    id: '4',
    name: 'جمعية الأمل - قدسيا',
    nameEn: 'Al-Amal Association - Qudsaya',
    type: 'اجتماعي',
    typeEn: 'Social',
    icon: Heart,
    color: 'bg-pink-600',
    description: 'دعم ذوي الاحتياجات الخاصة',
    descriptionEn: 'Support for special needs'
  }
];

const qudsayaDahiaServices: CommunityService[] = [
  {
    id: '1',
    name: 'جمعية البر الخيرية - الضاحية',
    nameEn: 'Al-Birr Charity - Dahia',
    type: 'خيري',
    typeEn: 'Charity',
    icon: HandHeart,
    color: 'bg-rose-600',
    description: 'مساعدة الأسر المحتاجة في الضاحية',
    descriptionEn: 'Helping needy families in Dahia'
  },
  {
    id: '2',
    name: 'مركز شباب الضاحية',
    nameEn: 'Dahia Youth Center',
    type: 'شبابي',
    typeEn: 'Youth',
    icon: Users,
    color: 'bg-indigo-600',
    description: 'أنشطة وبرامج شبابية',
    descriptionEn: 'Youth activities and programs'
  },
  {
    id: '3',
    name: 'بنك طعام الضاحية',
    nameEn: 'Dahia Food Bank',
    type: 'إنساني',
    typeEn: 'Humanitarian',
    icon: Gift,
    color: 'bg-orange-600',
    description: 'توزيع الطعام للمحتاجين',
    descriptionEn: 'Food distribution for needy'
  },
  {
    id: '4',
    name: 'جمعية الأمل - الضاحية',
    nameEn: 'Al-Amal Association - Dahia',
    type: 'اجتماعي',
    typeEn: 'Social',
    icon: Heart,
    color: 'bg-pink-600',
    description: 'دعم ذوي الاحتياجات الخاصة',
    descriptionEn: 'Support for special needs'
  }
];

const volunteerOpportunities: VolunteerOpp[] = [
  {
    id: '1',
    title: 'توزيع طرود غذائية',
    titleEn: 'Food Package Distribution',
    date: 'كل سبت',
    location: 'مركز الجمعية'
  },
  {
    id: '2',
    title: 'دروس تقوية مجانية',
    titleEn: 'Free Tutoring',
    date: 'يومياً',
    location: 'المركز الثقافي'
  }
];

const dataByRegion: Record<Region, CommunityService[]> = {
  'qudsaya-center': qudsayaCenterServices,
  'qudsaya-dahia': qudsayaDahiaServices
};

export default function Community() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const communityServices = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-rose-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-rose-600 rounded-2xl shadow-lg">
              <Heart className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'المجتمع' : 'Community'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `خدمات المجتمع في ${regionName}` : `Community services in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {communityServices.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
              >
                <div className="p-4">
                  <div className={`w-14 h-14 ${service.color} rounded-2xl flex items-center justify-center mb-3`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <span className="text-[10px] px-2 py-0.5 bg-rose-100 text-rose-700 rounded-full">
                    {isArabic ? service.type : service.typeEn}
                  </span>
                  <h3 className="text-base font-bold text-gray-900 mt-2 mb-1">
                    {isArabic ? service.name : service.nameEn}
                  </h3>
                  <p className="text-xs text-gray-500">
                    {isArabic ? service.description : service.descriptionEn}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Volunteer Opportunities */}
        <div className="bg-gradient-to-r from-rose-600 to-pink-600 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <HandHeart className="w-5 h-5 text-white" />
            <span className="text-white font-bold">{isArabic ? 'فرص تطوعية' : 'Volunteer Opportunities'}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {volunteerOpportunities.map((opp) => (
              <div key={opp.id} className="bg-white/20 backdrop-blur rounded-xl p-3">
                <h4 className="text-white font-medium text-sm mb-2">{isArabic ? opp.title : opp.titleEn}</h4>
                <div className="flex items-center gap-3 text-xs text-white/80">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{opp.date}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    <span>{opp.location}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
