'use client';

import React from 'react';
import { UtensilsCrossed, MapPin, Star, Clock, Flame, ChefHat } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRegion, Region } from '@/contexts/RegionContext';
import RegionSelector from './RegionSelector';

interface Restaurant {
  id: string;
  name: string;
  nameEn: string;
  cuisine: string;
  rating: number;
  deliveryTime: string;
  image: string;
  isOpen: boolean;
}

// بيانات ضاحية قدسيا
const qudsayaDahiaRestaurants: Restaurant[] = [
  {
    id: 'd1',
    name: 'مطعم الشام - ضاحية قدسيا',
    nameEn: 'Al-Sham Restaurant - Qudsaya Dahia',
    cuisine: 'شامي',
    rating: 4.8,
    deliveryTime: '30-45',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  },
  {
    id: 'd2',
    name: 'بيتزا الضاحية',
    nameEn: 'Dahia Pizza',
    cuisine: 'بيتزا',
    rating: 4.5,
    deliveryTime: '25-35',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  },
  {
    id: 'd3',
    name: 'مشاوي البيك',
    nameEn: 'Al-Baik Grills',
    cuisine: 'مشاوي',
    rating: 4.9,
    deliveryTime: '20-30',
    image: 'https://images.unsplash.com/photo-1603360946369-dc9bb6258143?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  },
  {
    id: 'd4',
    name: 'كافيه النخيل',
    nameEn: 'Palm Cafe',
    cuisine: 'حلويات',
    rating: 4.6,
    deliveryTime: '15-25',
    image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  }
];

// بيانات قدسيا المركز
const qudsayaCenterRestaurants: Restaurant[] = [
  {
    id: 'c1',
    name: 'مطعم القدس',
    nameEn: 'Al-Quds Restaurant',
    cuisine: 'شامي',
    rating: 4.7,
    deliveryTime: '25-40',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  },
  {
    id: 'c2',
    name: 'بيتزا الجبل',
    nameEn: 'Mountain Pizza',
    cuisine: 'بيتزا',
    rating: 4.6,
    deliveryTime: '30-40',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  },
  {
    id: 'c3',
    name: 'مشاوي الصفاء',
    nameEn: 'Al-Safa Grills',
    cuisine: 'مشاوي',
    rating: 4.8,
    deliveryTime: '20-35',
    image: 'https://images.unsplash.com/photo-1603360946369-dc9bb6258143?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  },
  {
    id: 'c4',
    name: 'كافيه الجبل',
    nameEn: 'Mountain Cafe',
    cuisine: 'حلويات',
    rating: 4.5,
    deliveryTime: '15-25',
    image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=600&q=80',
    isOpen: true
  }
];

const restaurantsByRegion: Record<Region, Restaurant[]> = {
  'qudsaya-center': qudsayaCenterRestaurants,
  'qudsaya-dahia': qudsayaDahiaRestaurants
};

export default function Restaurants() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const restaurants = restaurantsByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-orange-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-600 rounded-2xl shadow-lg">
              <ChefHat className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'المطاعم والمأكولات' : 'Restaurants & Food'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `أشهى المأكولات في ${regionName}` : `Delicious food in ${regionName}`}
              </p>
            </div>
          </div>
          
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {restaurants.map((restaurant, index) => (
            <motion.div
              key={restaurant.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-32 overflow-hidden">
                <img src={restaurant.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <span className={`absolute top-2 right-2 px-2 py-1 text-[10px] font-bold rounded-full ${
                  restaurant.isOpen ? 'bg-emerald-500 text-white' : 'bg-gray-500 text-white'
                }`}>
                  {restaurant.isOpen ? (isArabic ? 'مفتوح' : 'Open') : (isArabic ? 'مغلق' : 'Closed')}
                </span>
                <span className="absolute top-2 left-2 px-2 py-1 bg-white/90 text-gray-700 text-[10px] font-bold rounded-full">
                  {restaurant.cuisine}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-base font-bold text-gray-900 mb-1">
                  {isArabic ? restaurant.name : restaurant.nameEn}
                </h3>
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-bold text-gray-900">{restaurant.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Clock className="w-3.5 h-3.5 text-orange-500" />
                  <span>{restaurant.deliveryTime} {isArabic ? 'دقيقة' : 'min'}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
