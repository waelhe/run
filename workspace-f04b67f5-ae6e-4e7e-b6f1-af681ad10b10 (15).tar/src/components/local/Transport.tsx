'use client';

import React from 'react';
import { Bus, MapPin, Clock, Users, AlertCircle, CheckCircle, Route } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface RouteData {
  id: string;
  number: string;
  name: string;
  nameEn: string;
  from: string;
  fromEn: string;
  to: string;
  toEn: string;
  stops: number;
  nextBus: string;
  status: string;
}

interface TaxiStation {
  id: string;
  name: string;
  nameEn: string;
  cars: number;
}

const qudsayaCenterRoutes: RouteData[] = [
  {
    id: '1',
    number: 'Q1',
    name: 'خط قدسيا - دمشق',
    nameEn: 'Qudsaya - Damascus Line',
    from: 'قدسيا',
    fromEn: 'Qudsaya',
    to: 'ساحة العباسيين',
    toEn: 'Abbasid Square',
    stops: 10,
    nextBus: '5 دقائق',
    status: 'active'
  },
  {
    id: '2',
    number: 'Q2',
    name: 'خط قدسيا - المزة',
    nameEn: 'Qudsaya - Mezzeh Line',
    from: 'قدسيا',
    fromEn: 'Qudsaya',
    to: 'المزة',
    toEn: 'Mezzeh',
    stops: 8,
    nextBus: '8 دقائق',
    status: 'active'
  },
  {
    id: '3',
    number: 'Q3',
    name: 'خط قدسيا - البرامكة',
    nameEn: 'Qudsaya - Barameka Line',
    from: 'قدسيا',
    fromEn: 'Qudsaya',
    to: 'البرامكة',
    toEn: 'Barameka',
    stops: 12,
    nextBus: '15 دقيقة',
    status: 'delayed'
  }
];

const qudsayaDahiaRoutes: RouteData[] = [
  {
    id: '1',
    number: 'D1',
    name: 'خط الضاحية - دمشق',
    nameEn: 'Dahia - Damascus Line',
    from: 'الضاحية',
    fromEn: 'Dahia',
    to: 'ساحة العباسيين',
    toEn: 'Abbasid Square',
    stops: 15,
    nextBus: '7 دقائق',
    status: 'active'
  },
  {
    id: '2',
    number: 'D2',
    name: 'خط الضاحية - قدسيا',
    nameEn: 'Dahia - Qudsaya Line',
    from: 'الضاحية',
    fromEn: 'Dahia',
    to: 'قدسيا',
    toEn: 'Qudsaya',
    stops: 5,
    nextBus: '3 دقائق',
    status: 'active'
  },
  {
    id: '3',
    number: 'D3',
    name: 'خط الضاحية - المزة',
    nameEn: 'Dahia - Mezzeh Line',
    from: 'الضاحية',
    fromEn: 'Dahia',
    to: 'المزة',
    toEn: 'Mezzeh',
    stops: 10,
    nextBus: '12 دقيقة',
    status: 'active'
  }
];

const qudsayaCenterTaxi: TaxiStation[] = [
  { id: '1', name: 'محطة قدسيا المركزية', nameEn: 'Qudsaya Central Station', cars: 10 },
  { id: '2', name: 'محطة الساحة', nameEn: 'Square Station', cars: 6 },
  { id: '3', name: 'محطة المدخل', nameEn: 'Entrance Station', cars: 8 }
];

const qudsayaDahiaTaxi: TaxiStation[] = [
  { id: '1', name: 'محطة الضاحية المركزية', nameEn: 'Dahia Central Station', cars: 12 },
  { id: '2', name: 'محطة الحي الشمالي', nameEn: 'North District Station', cars: 5 },
  { id: '3', name: 'محطة السوق', nameEn: 'Market Station', cars: 7 }
];

const dataByRegion = {
  'qudsaya-center': { routes: qudsayaCenterRoutes, taxi: qudsayaCenterTaxi },
  'qudsaya-dahia': { routes: qudsayaDahiaRoutes, taxi: qudsayaDahiaTaxi }
};

export default function Transport() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const regionData = dataByRegion[region];
  const routes = regionData?.routes || [];
  const taxiStations = regionData?.taxi || [];

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'active':
        return { icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-100', text: isArabic ? 'نشط' : 'Active' };
      case 'delayed':
        return { icon: AlertCircle, color: 'text-amber-600', bg: 'bg-amber-100', text: isArabic ? 'متأخر' : 'Delayed' };
      default:
        return { icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-100', text: isArabic ? 'متوقف' : 'Stopped' };
    }
  };

  return (
    <section className="py-6 bg-gradient-to-b from-teal-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-teal-600 rounded-2xl shadow-lg">
              <Bus className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'المواصلات والنقل' : 'Transportation'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `باصات وتاكسي في ${regionName}` : `Buses and taxis in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        {/* Bus Routes */}
        <div className="mb-6">
          <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
            <Route className="w-5 h-5 text-teal-600" />
            {isArabic ? 'خطوط الباصات' : 'Bus Routes'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {routes.map((route, index) => {
              const statusConfig = getStatusConfig(route.status);
              const StatusIcon = statusConfig.icon;

              return (
                <motion.div
                  key={route.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-2xl border border-gray-200 hover:shadow-lg p-4"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
                      <span className="text-lg font-black text-teal-600">{route.number}</span>
                    </div>
                    <div className={`px-2 py-1 rounded-full ${statusConfig.bg} flex items-center gap-1`}>
                      <StatusIcon className={`w-3.5 h-3.5 ${statusConfig.color}`} />
                      <span className={`text-xs font-bold ${statusConfig.color}`}>{statusConfig.text}</span>
                    </div>
                  </div>
                  <h4 className="text-base font-bold text-gray-900 mb-2">
                    {isArabic ? route.name : route.nameEn}
                  </h4>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                    <MapPin className="w-4 h-4 text-teal-500" />
                    <span>{isArabic ? route.from : route.fromEn}</span>
                    <span>→</span>
                    <span>{isArabic ? route.to : route.toEn}</span>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                    <span className="text-sm text-gray-500">{route.stops} {isArabic ? 'محطة' : 'stops'}</span>
                    <div className="flex items-center gap-1 text-sm font-bold text-teal-600">
                      <Clock className="w-4 h-4" />
                      <span>{route.nextBus}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Taxi Stations */}
        <div>
          <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-600" />
            {isArabic ? 'محطات التاكسي الجماعي' : 'Shared Taxi Stations'}
          </h3>

          <div className="grid grid-cols-3 gap-3">
            {taxiStations.map((station, index) => (
              <motion.div
                key={station.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="p-4 bg-amber-50 rounded-xl border border-amber-200 hover:shadow-md transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-gray-900">{isArabic ? station.name : station.nameEn}</h4>
                    <p className="text-sm text-gray-500">{station.cars} {isArabic ? 'سيارة متاحة' : 'cars available'}</p>
                  </div>
                  <div className="w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">{station.cars}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
