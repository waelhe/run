'use client';

import React from 'react';
import { MapPin } from 'lucide-react';
import { motion } from 'framer-motion';
import { useRegion, Region } from '@/contexts/RegionContext';
import { useLanguage } from '@/contexts/LanguageContext';

interface RegionSelectorProps {
  className?: string;
  variant?: 'default' | 'light';
}

export default function RegionSelector({ className = '', variant = 'default' }: RegionSelectorProps) {
  const { region, setRegion } = useRegion();
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  const regions: { id: Region; name: string; nameEn: string }[] = [
    { id: 'qudsaya-center', name: 'قدسيا', nameEn: 'Qudsaya' },
    { id: 'qudsaya-dahia', name: 'ضاحية قدسيا', nameEn: 'Dahia' }
  ];

  if (variant === 'light') {
    return (
      <div className={`inline-flex items-center rounded-full overflow-hidden border-2 border-white/30 bg-white/10 backdrop-blur-sm ${className}`}>
        {regions.map((r) => {
          const isActive = region === r.id;
          return (
            <button
              key={r.id}
              onClick={() => setRegion(r.id)}
              className={`relative flex items-center gap-1.5 px-4 py-2.5 text-sm font-bold transition-all duration-200 ${
                isActive 
                  ? 'bg-white text-emerald-600' 
                  : 'text-white hover:bg-white/20'
              }`}
            >
              <MapPin className={`w-4 h-4 ${isActive ? 'text-emerald-500' : 'text-white/70'}`} />
              <span className="whitespace-nowrap">{isArabic ? r.name : r.nameEn}</span>
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center rounded-full overflow-hidden border-2 border-emerald-500 shadow-md ${className}`}>
      {regions.map((r) => {
        const isActive = region === r.id;
        return (
          <button
            key={r.id}
            onClick={() => setRegion(r.id)}
            className={`relative flex items-center gap-1.5 px-4 py-2.5 text-sm font-bold transition-all duration-200 ${
              isActive 
                ? 'bg-emerald-500 text-white' 
                : 'bg-white text-emerald-600 hover:bg-emerald-50'
            }`}
          >
            <MapPin className={`w-4 h-4 ${isActive ? 'text-white' : 'text-emerald-500'}`} />
            <span className="whitespace-nowrap">{isArabic ? r.name : r.nameEn}</span>
          </button>
        );
      })}
    </div>
  );
}
