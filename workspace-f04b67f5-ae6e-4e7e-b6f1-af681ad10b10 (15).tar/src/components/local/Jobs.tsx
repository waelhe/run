'use client';

import React, { useState } from 'react';
import { Briefcase, MapPin, Clock, DollarSign, Building, ArrowLeft, Sparkles, Flame, CheckCircle, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface Job {
  id: string;
  title: string;
  titleEn: string;
  company: string;
  companyEn: string;
  location: string;
  type: 'full-time' | 'part-time' | 'remote';
  typeAr: string;
  typeEn: string;
  salary: string;
  posted: string;
  urgent?: boolean;
  featured?: boolean;
  requirements?: string;
  requirementsEn?: string;
}

const qudsayaCenterJobs: Job[] = [
  {
    id: '1',
    title: 'مهندس برمجيات',
    titleEn: 'Software Engineer',
    company: 'شركة تقنية المعلومات',
    companyEn: 'IT Company',
    location: 'قدسيا - المركز',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '500-800$',
    posted: 'منذ يوم',
    featured: true,
    requirements: 'خبرة 3+ سنوات'
  },
  {
    id: '2',
    title: 'محاسب',
    titleEn: 'Accountant',
    company: 'مؤسسة تجارية',
    companyEn: 'Trading Company',
    location: 'قدسيا',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '300-450$',
    posted: 'منذ يومين'
  },
  {
    id: '3',
    title: 'معلم لغة إنجليزية',
    titleEn: 'English Teacher',
    company: 'معهد لغات',
    companyEn: 'Language Institute',
    location: 'قدسيا',
    type: 'part-time',
    typeAr: 'دوام جزئي',
    typeEn: 'Part-time',
    salary: '200-350$',
    posted: 'منذ 3 أيام',
    urgent: true
  },
  {
    id: '4',
    title: 'مصمم جرافيك',
    titleEn: 'Graphic Designer',
    company: 'وكالة إعلانات',
    companyEn: 'Advertising Agency',
    location: 'قدسيا',
    type: 'remote',
    typeAr: 'عن بعد',
    typeEn: 'Remote',
    salary: '250-400$',
    posted: 'منذ أسبوع'
  },
  {
    id: '5',
    title: 'طبيب أسنان',
    titleEn: 'Dentist',
    company: 'عيادة خاصة',
    companyEn: 'Private Clinic',
    location: 'قدسيا',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: 'حسب الخبرة',
    posted: 'منذ 5 أيام',
    featured: true
  },
  {
    id: '6',
    title: 'سائق توصيل',
    titleEn: 'Delivery Driver',
    company: 'مطعم',
    companyEn: 'Restaurant',
    location: 'قدسيا',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '150$ + نسبة',
    posted: 'منذ ساعتين',
    urgent: true
  }
];

const qudsayaDahiaJobs: Job[] = [
  {
    id: '1',
    title: 'مهندس مدني',
    titleEn: 'Civil Engineer',
    company: 'شركة مقاولات',
    companyEn: 'Construction Company',
    location: 'الضاحية',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '600-900$',
    posted: 'منذ يوم',
    featured: true
  },
  {
    id: '2',
    title: 'محاسب',
    titleEn: 'Accountant',
    company: 'مؤسسة تجارية',
    companyEn: 'Trading Company',
    location: 'الضاحية',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '350-500$',
    posted: 'منذ يومين'
  },
  {
    id: '3',
    title: 'معلم رياضيات',
    titleEn: 'Math Teacher',
    company: 'مدرسة خاصة',
    companyEn: 'Private School',
    location: 'الضاحية',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '300-450$',
    posted: 'منذ 4 أيام'
  },
  {
    id: '4',
    title: 'مصمم ويب',
    titleEn: 'Web Designer',
    company: 'شركة تقنية',
    companyEn: 'Tech Company',
    location: 'الضاحية',
    type: 'remote',
    typeAr: 'عن بعد',
    typeEn: 'Remote',
    salary: '300-500$',
    posted: 'منذ أسبوع'
  },
  {
    id: '5',
    title: 'صيدلي',
    titleEn: 'Pharmacist',
    company: 'صيدلية',
    companyEn: 'Pharmacy',
    location: 'الضاحية',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '400-600$',
    posted: 'منذ 3 أيام',
    featured: true
  },
  {
    id: '6',
    title: 'سائق توصيل',
    titleEn: 'Delivery Driver',
    company: 'سوبر ماركت',
    companyEn: 'Supermarket',
    location: 'الضاحية',
    type: 'full-time',
    typeAr: 'دوام كامل',
    typeEn: 'Full-time',
    salary: '180$ + نسبة',
    posted: 'منذ ساعة',
    urgent: true
  }
];

const dataByRegion: Record<Region, Job[]> = {
  'qudsaya-center': qudsayaCenterJobs,
  'qudsaya-dahia': qudsayaDahiaJobs
};

const typeFilters = [
  { id: 'all', name: 'الكل', nameEn: 'All' },
  { id: 'full-time', name: 'دوام كامل', nameEn: 'Full-time' },
  { id: 'part-time', name: 'جزئي', nameEn: 'Part-time' },
  { id: 'remote', name: 'عن بعد', nameEn: 'Remote' }
];

const typeStyles = {
  'full-time': { bg: 'bg-blue-100', text: 'text-blue-700', border: 'border-blue-200' },
  'part-time': { bg: 'bg-purple-100', text: 'text-purple-700', border: 'border-purple-200' },
  'remote': { bg: 'bg-teal-100', text: 'text-teal-700', border: 'border-teal-200' }
};

export default function Jobs() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const [activeFilter, setActiveFilter] = useState('all');
  const jobs = dataByRegion[region];

  const filteredJobs = activeFilter === 'all' 
    ? jobs 
    : jobs.filter(job => job.type === activeFilter);

  const urgentJobs = jobs.filter(j => j.urgent);
  const featuredJobs = jobs.filter(j => j.featured);

  return (
    <section className="py-6 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl shadow-lg shadow-blue-200">
              <Briefcase className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'الوظائف الشاغرة' : 'Job Openings'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `${jobs.length} فرصة عمل في ${regionName}` : `${jobs.length} jobs in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-5 overflow-x-auto pb-2">
          {typeFilters.map((filter) => {
            const isActive = activeFilter === filter.id;
            const count = filter.id === 'all' 
              ? jobs.length 
              : jobs.filter(j => j.type === filter.id).length;

            return (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap text-sm font-bold transition-all ${
                  isActive 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' 
                    : 'bg-white border border-gray-200 text-gray-600 hover:border-blue-300 hover:text-blue-600'
                }`}
              >
                <span>{isArabic ? filter.name : filter.nameEn}</span>
                <span className={`px-2 py-0.5 rounded-full text-xs ${isActive ? 'bg-white/20' : 'bg-gray-100'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Urgent Jobs Banner */}
        {urgentJobs.length > 0 && activeFilter === 'all' && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-5 p-4 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl text-white"
          >
            <div className="flex items-center gap-2 mb-3">
              <Flame className="w-5 h-5 animate-pulse" />
              <span className="font-bold">{isArabic ? 'وظائف عاجلة!' : 'Urgent Jobs!'}</span>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-1">
              {urgentJobs.map(job => (
                <div key={job.id} className="flex-shrink-0 bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2">
                  <p className="font-bold text-sm">{isArabic ? job.title : job.titleEn}</p>
                  <p className="text-xs text-white/80">{job.salary}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Jobs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {filteredJobs.map((job, index) => {
              const styles = typeStyles[job.type];
              
              return (
                <motion.div
                  key={job.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: index * 0.05 }}
                  className={`group relative bg-white rounded-2xl border-2 overflow-hidden cursor-pointer transition-all hover:shadow-xl hover:-translate-y-1 ${
                    job.featured ? 'border-amber-300 shadow-lg shadow-amber-100' : 'border-gray-100 hover:border-blue-200'
                  }`}
                >
                  {/* Featured Badge */}
                  {job.featured && (
                    <div className="absolute top-3 left-3 z-10">
                      <div className="flex items-center gap-1 px-2 py-1 bg-gradient-to-r from-amber-400 to-orange-400 text-white text-xs font-bold rounded-full shadow-md">
                        <Sparkles className="w-3.5 h-3.5" />
                        {isArabic ? 'مميز' : 'Featured'}
                      </div>
                    </div>
                  )}

                  {/* Urgent Badge */}
                  {job.urgent && (
                    <div className="absolute top-3 left-3 z-10">
                      <div className="flex items-center gap-1 px-2 py-1 bg-gradient-to-r from-red-500 to-rose-500 text-white text-xs font-bold rounded-full shadow-md animate-pulse">
                        <Flame className="w-3.5 h-3.5" />
                        {isArabic ? 'عاجل' : 'Urgent'}
                      </div>
                    </div>
                  )}

                  <div className="p-5">
                    {/* Company Logo Placeholder */}
                    <div className="flex items-start gap-4 mb-4">
                      <div className={`w-14 h-14 rounded-xl flex items-center justify-center shrink-0 ${
                        job.featured ? 'bg-gradient-to-br from-amber-100 to-orange-100' : 'bg-gray-100'
                      }`}>
                        <Building className={`w-7 h-7 ${job.featured ? 'text-amber-600' : 'text-gray-400'}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-bold text-gray-900 mb-1 line-clamp-1">
                          {isArabic ? job.title : job.titleEn}
                        </h3>
                        <p className="text-sm text-gray-500 line-clamp-1">
                          {isArabic ? job.company : job.companyEn}
                        </p>
                      </div>
                    </div>

                    {/* Type Badge */}
                    <div className="flex items-center gap-2 mb-4">
                      <span className={`text-xs font-bold px-3 py-1.5 rounded-full ${styles.bg} ${styles.text}`}>
                        {isArabic ? job.typeAr : job.typeEn}
                      </span>
                      <span className="flex items-center gap-1 text-xs text-gray-400">
                        <Clock className="w-3.5 h-3.5" />
                        {job.posted}
                      </span>
                    </div>

                    {/* Details */}
                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="flex items-center gap-1.5 text-sm text-gray-500">
                        <MapPin className="w-4 h-4 text-blue-500" />
                        <span>{job.location}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
                        <DollarSign className="w-4 h-4" />
                        <span>{job.salary}</span>
                      </div>
                    </div>

                    {/* Requirements */}
                    {job.requirements && (
                      <div className="mt-3 pt-3 border-t border-gray-100">
                        <div className="flex items-center gap-1.5 text-xs text-gray-500">
                          <CheckCircle className="w-3.5 h-3.5 text-blue-500" />
                          <span>{isArabic ? job.requirements : job.requirementsEn}</span>
                        </div>
                      </div>
                    )}

                    {/* Apply Button (shows on hover) */}
                    <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-colors">
                        {isArabic ? 'تقديم الآن' : 'Apply Now'}
                        <ArrowLeft className="w-4 h-4 rotate-180" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Empty State */}
        {filteredJobs.length === 0 && (
          <div className="text-center py-12">
            <Briefcase className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 font-medium">
              {isArabic ? 'لا توجد وظائف بهذا التصنيف' : 'No jobs in this category'}
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
