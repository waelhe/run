'use client';

import React from 'react';
import { Heart, MapPin, Star, Clock, Calendar, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRegion, Region } from '@/contexts/RegionContext';
import RegionSelector from './RegionSelector';

interface Doctor {
  id: string;
  name: string;
  nameEn: string;
  specialty: string;
  specialtyEn: string;
  rating: number;
  nextAvailable: string;
  image: string;
  isAvailable: boolean;
}

// بيانات ضاحية قدسيا
const qudsayaDahiaDoctors: Doctor[] = [
  {
    id: '1',
    name: 'د. أحمد العمري',
    nameEn: 'Dr. Ahmed Al-Omari',
    specialty: 'طب عام',
    specialtyEn: 'General Medicine',
    rating: 4.9,
    nextAvailable: '10:00 ص',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  },
  {
    id: '2',
    name: 'د. سارة الخالد',
    nameEn: 'Dr. Sara Al-Khaled',
    specialty: 'طب أطفال',
    specialtyEn: 'Pediatrics',
    rating: 4.8,
    nextAvailable: '11:30 ص',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  },
  {
    id: '3',
    name: 'د. محمد العلي',
    nameEn: 'Dr. Mohammad Al-Ali',
    specialty: 'طب أسنان',
    specialtyEn: 'Dentistry',
    rating: 4.7,
    nextAvailable: '2:00 م',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  },
  {
    id: '4',
    name: 'د. ليلى حسن',
    nameEn: 'Dr. Laila Hassan',
    specialty: 'أمراض جلدية',
    specialtyEn: 'Dermatology',
    rating: 4.6,
    nextAvailable: '4:00 م',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  }
];

// بيانات قدسيا المركز
const qudsayaCenterDoctors: Doctor[] = [
  {
    id: 'q1',
    name: 'د. محمود القدسي',
    nameEn: 'Dr. Mahmoud Al-Qudsi',
    specialty: 'طب عام',
    specialtyEn: 'General Medicine',
    rating: 4.8,
    nextAvailable: '9:30 ص',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  },
  {
    id: 'q2',
    name: 'د. نورة الأحمد',
    nameEn: 'Dr. Noura Al-Ahmad',
    specialty: 'طب أطفال',
    specialtyEn: 'Pediatrics',
    rating: 4.9,
    nextAvailable: '10:00 ص',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  },
  {
    id: 'q3',
    name: 'د. خالد المحمود',
    nameEn: 'Dr. Khaled Al-Mahmoud',
    specialty: 'طب أسنان',
    specialtyEn: 'Dentistry',
    rating: 4.7,
    nextAvailable: '1:00 م',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  },
  {
    id: 'q4',
    name: 'د. رنا السيد',
    nameEn: 'Dr. Rana Al-Sayed',
    specialty: 'طب نسائية',
    specialtyEn: 'Gynecology',
    rating: 4.8,
    nextAvailable: '3:30 م',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=600&q=80',
    isAvailable: true
  }
];

const doctorsByRegion: Record<Region, Doctor[]> = {
  'qudsaya-center': qudsayaCenterDoctors,
  'qudsaya-dahia': qudsayaDahiaDoctors
};

export default function Doctors() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const doctors = doctorsByRegion[region];

  return (
    <section className="py-6 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-rose-600 rounded-2xl shadow-lg">
              <Heart className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'الأطباء والعيادات' : 'Doctors & Clinics'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `احجز موعدك في ${regionName}` : `Book appointments in ${regionName}`}
              </p>
            </div>
          </div>
          
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {doctors.map((doctor, index) => (
            <motion.div
              key={doctor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-36 overflow-hidden">
                <img src={doctor.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                {doctor.isAvailable && (
                  <span className="absolute top-2 right-2 px-2 py-1 bg-emerald-500 text-white text-[10px] font-bold rounded-full flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                    {isArabic ? 'متاح' : 'Available'}
                  </span>
                )}
                <span className="absolute bottom-2 left-2 px-2 py-1 bg-white/90 text-gray-700 text-[10px] font-bold rounded-full">
                  {isArabic ? doctor.specialty : doctor.specialtyEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-base font-bold text-gray-900 mb-1">
                  {isArabic ? doctor.name : doctor.nameEn}
                </h3>
                <div className="flex items-center gap-1 mb-3">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-bold text-gray-900">{doctor.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Calendar className="w-3.5 h-3.5 text-rose-500" />
                  <span>{doctor.nextAvailable}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
