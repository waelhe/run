'use client';

import React from 'react';
import { Building, Bed, Bath, Maximize, MapPin, DollarSign, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface Property {
  id: string;
  title: string;
  titleEn: string;
  type: string;
  typeEn: string;
  price: string;
  location: string;
  locationEn: string;
  image: string;
  beds: number;
  baths: number;
  area: number;
}

const qudsayaCenterProperties: Property[] = [
  {
    id: '1',
    title: 'شقة فاخرة 180م²',
    titleEn: 'Luxury Apartment 180m²',
    type: 'للبيع',
    typeEn: 'For Sale',
    price: '280,000',
    location: 'قدسيا - الحي الغربي',
    locationEn: 'Qudsaya - West District',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=600&q=80',
    beds: 4,
    baths: 2,
    area: 180
  },
  {
    id: '2',
    title: 'شقة للإيجار 120م²',
    titleEn: 'Apartment for Rent 120m²',
    type: 'للإيجار',
    typeEn: 'For Rent',
    price: '450/شهر',
    location: 'قدسيا - المركز',
    locationEn: 'Qudsaya - Center',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=600&q=80',
    beds: 3,
    baths: 2,
    area: 120
  },
  {
    id: '3',
    title: 'فيلا مع حديقة',
    titleEn: 'Villa with Garden',
    type: 'للبيع',
    typeEn: 'For Sale',
    price: '950,000',
    location: 'قدسيا - الحي الجنوبي',
    locationEn: 'Qudsaya - South District',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
    beds: 6,
    baths: 4,
    area: 380
  },
  {
    id: '4',
    title: 'مكتب تجاري 80م²',
    titleEn: 'Commercial Office 80m²',
    type: 'للإيجار',
    typeEn: 'For Rent',
    price: '700/شهر',
    location: 'قدسيا - الساحة',
    locationEn: 'Qudsaya - Square',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=600&q=80',
    beds: 0,
    baths: 1,
    area: 80
  }
];

const qudsayaDahiaProperties: Property[] = [
  {
    id: '1',
    title: 'شقة فاخرة 180م²',
    titleEn: 'Luxury Apartment 180m²',
    type: 'للبيع',
    typeEn: 'For Sale',
    price: '250,000',
    location: 'الضاحية - الحي الغربي',
    locationEn: 'Dahia - West District',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=600&q=80',
    beds: 4,
    baths: 2,
    area: 180
  },
  {
    id: '2',
    title: 'شقة للإيجار 120م²',
    titleEn: 'Apartment for Rent 120m²',
    type: 'للإيجار',
    typeEn: 'For Rent',
    price: '500/شهر',
    location: 'الضاحية - الحي الرئيسي',
    locationEn: 'Dahia - Main District',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=600&q=80',
    beds: 3,
    baths: 2,
    area: 120
  },
  {
    id: '3',
    title: 'فيلا مع حديقة',
    titleEn: 'Villa with Garden',
    type: 'للبيع',
    typeEn: 'For Sale',
    price: '850,000',
    location: 'الضاحية - الحي الجنوبي',
    locationEn: 'Dahia - South District',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
    beds: 6,
    baths: 4,
    area: 350
  },
  {
    id: '4',
    title: 'مكتب تجاري 80م²',
    titleEn: 'Commercial Office 80m²',
    type: 'للإيجار',
    typeEn: 'For Rent',
    price: '800/شهر',
    location: 'الضاحية - المركز التجاري',
    locationEn: 'Dahia - Commercial Center',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=600&q=80',
    beds: 0,
    baths: 1,
    area: 80
  }
];

const dataByRegion: Record<Region, Property[]> = {
  'qudsaya-center': qudsayaCenterProperties,
  'qudsaya-dahia': qudsayaDahiaProperties
};

export default function RealEstate() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const properties = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-cyan-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-cyan-600 rounded-2xl shadow-lg">
              <Building className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'العقارات' : 'Real Estate'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `بيع وإيجار العقارات في ${regionName}` : `Buy, sell and rent properties in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {properties.map((property, index) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-28 overflow-hidden">
                <img src={property.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <span className={`absolute top-2 right-2 px-2 py-1 text-[10px] font-bold rounded-full ${
                  property.type === 'للبيع' ? 'bg-cyan-600 text-white' : 'bg-amber-500 text-white'
                }`}>
                  {isArabic ? property.type : property.typeEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1 line-clamp-1">
                  {isArabic ? property.title : property.titleEn}
                </h3>
                <div className="flex items-center gap-1 mb-2">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span className="text-sm font-black text-emerald-600">{property.price}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500 mb-2">
                  <MapPin className="w-3 h-3" />
                  <span className="line-clamp-1">{isArabic ? property.location : property.locationEn}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-gray-400">
                  {property.beds > 0 && (
                    <div className="flex items-center gap-1">
                      <Bed className="w-3 h-3" />
                      <span>{property.beds}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <Bath className="w-3 h-3" />
                    <span>{property.baths}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Maximize className="w-3 h-3" />
                    <span>{property.area}م²</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
