'use client';

import React from 'react';
import { Dumbbell, Trophy, Calendar, MapPin, Users, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface Sport {
  id: string;
  name: string;
  nameEn: string;
  type: string;
  typeEn: string;
  image: string;
  facilities: string[];
  facilitiesEn: string[];
}

interface SportEvent {
  id: string;
  title: string;
  titleEn: string;
  date: string;
  dateEn: string;
}

const qudsayaCenterSports: Sport[] = [
  {
    id: '1',
    name: 'نادي قدسيا الرياضي',
    nameEn: 'Qudsaya Sports Club',
    type: 'نادي رياضي',
    typeEn: 'Sports Club',
    image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?auto=format&fit=crop&w=600&q=80',
    facilities: ['كرة قدم', 'سباحة', 'تنس'],
    facilitiesEn: ['Football', 'Swimming', 'Tennis']
  },
  {
    id: '2',
    name: 'صالة اللياقة البدنية',
    nameEn: 'Fitness Gym',
    type: 'نادي لياقة',
    typeEn: 'Gym',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=600&q=80',
    facilities: ['أجهزة حديثة', 'مدربين', 'ساونا'],
    facilitiesEn: ['Modern Equipment', 'Trainers', 'Sauna']
  },
  {
    id: '3',
    name: 'ملاعب كرة القدم',
    nameEn: 'Football Fields',
    type: 'ملاعب',
    typeEn: 'Fields',
    image: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=600&q=80',
    facilities: ['عشب صناعي', 'إضاءة ليلية'],
    facilitiesEn: ['Artificial Grass', 'Night Lighting']
  },
  {
    id: '4',
    name: 'مركز السباحة',
    nameEn: 'Swimming Center',
    type: 'سباحة',
    typeEn: 'Swimming',
    image: 'https://images.unsplash.com/photo-1519315901367-f34ff9154487?auto=format&fit=crop&w=600&q=80',
    facilities: ['مساحة كبيرة', 'دروس سباحة'],
    facilitiesEn: ['Large Pool', 'Swimming Lessons']
  }
];

const qudsayaDahiaSports: Sport[] = [
  {
    id: '1',
    name: 'نادي الضاحية الرياضي',
    nameEn: 'Dahia Sports Club',
    type: 'نادي رياضي',
    typeEn: 'Sports Club',
    image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?auto=format&fit=crop&w=600&q=80',
    facilities: ['كرة قدم', 'سباحة', 'تنس'],
    facilitiesEn: ['Football', 'Swimming', 'Tennis']
  },
  {
    id: '2',
    name: 'صالة اللياقة البدنية',
    nameEn: 'Fitness Gym',
    type: 'نادي لياقة',
    typeEn: 'Gym',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=600&q=80',
    facilities: ['أجهزة حديثة', 'مدربين', 'ساونا'],
    facilitiesEn: ['Modern Equipment', 'Trainers', 'Sauna']
  },
  {
    id: '3',
    name: 'ملاعب كرة القدم',
    nameEn: 'Football Fields',
    type: 'ملاعب',
    typeEn: 'Fields',
    image: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=600&q=80',
    facilities: ['عشب صناعي', 'إضاءة ليلية'],
    facilitiesEn: ['Artificial Grass', 'Night Lighting']
  },
  {
    id: '4',
    name: 'مركز السباحة',
    nameEn: 'Swimming Center',
    type: 'سباحة',
    typeEn: 'Swimming',
    image: 'https://images.unsplash.com/photo-1519315901367-f34ff9154487?auto=format&fit=crop&w=600&q=80',
    facilities: ['مساحة كبيرة', 'دروس سباحة'],
    facilitiesEn: ['Large Pool', 'Swimming Lessons']
  }
];

const qudsayaCenterEvents: SportEvent[] = [
  {
    id: '1',
    title: 'بطولة كرة القدم',
    titleEn: 'Football Championship',
    date: '15 فبراير',
    dateEn: 'Feb 15'
  },
  {
    id: '2',
    title: 'ماراثون قدسيا',
    titleEn: 'Qudsaya Marathon',
    date: '20 فبراير',
    dateEn: 'Feb 20'
  }
];

const qudsayaDahiaEvents: SportEvent[] = [
  {
    id: '1',
    title: 'بطولة كرة القدم',
    titleEn: 'Football Championship',
    date: '18 فبراير',
    dateEn: 'Feb 18'
  },
  {
    id: '2',
    title: 'ماراثون الضاحية',
    titleEn: 'Dahia Marathon',
    date: '25 فبراير',
    dateEn: 'Feb 25'
  }
];

const dataByRegion: Record<Region, { sports: Sport[]; events: SportEvent[] }> = {
  'qudsaya-center': { sports: qudsayaCenterSports, events: qudsayaCenterEvents },
  'qudsaya-dahia': { sports: qudsayaDahiaSports, events: qudsayaDahiaEvents }
};

export default function Sports() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const { sports, events } = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-green-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-600 rounded-2xl shadow-lg">
              <Trophy className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'الرياضة والترفيه' : 'Sports & Entertainment'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `أنشطة رياضية في ${regionName}` : `Sports activities in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {sports.map((sport, index) => (
            <motion.div
              key={sport.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-28 overflow-hidden">
                <img src={sport.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <span className="absolute top-2 right-2 px-2 py-1 bg-green-600 text-white text-[10px] font-bold rounded-full">
                  {isArabic ? sport.type : sport.typeEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1">
                  {isArabic ? sport.name : sport.nameEn}
                </h3>
                <div className="flex flex-wrap gap-1">
                  {(isArabic ? sport.facilities : sport.facilitiesEn).map((f, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 bg-green-100 text-green-700 rounded-full">
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Upcoming Events */}
        <div className="bg-green-600 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-5 h-5 text-white" />
            <span className="text-white font-bold">{isArabic ? 'الفعاليات القادمة' : 'Upcoming Events'}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {events.map((event) => (
              <div key={event.id} className="bg-white/20 backdrop-blur rounded-xl p-3 flex items-center gap-3">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center">
                  <span className="text-green-600 font-black text-xs">{isArabic ? event.date : event.dateEn}</span>
                </div>
                <span className="text-white font-medium text-sm">{isArabic ? event.title : event.titleEn}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
