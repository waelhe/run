'use client';

import React from 'react';
import { Newspaper, Clock, ArrowLeft, TrendingUp, AlertCircle, Info, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface NewsItem {
  id: string;
  title: string;
  titleEn: string;
  summary: string;
  summaryEn: string;
  time: string;
  type: 'alert' | 'success' | 'info';
  image: string;
}

const qudsayaCenterNews: NewsItem[] = [
  {
    id: '1',
    title: 'انقطاع الكهرباء عن حي المركز',
    titleEn: 'Power outage in Center district',
    summary: 'لأعمال صيانة طارئة حتى الساعة 6 مساءً',
    summaryEn: 'Emergency maintenance until 6 PM',
    time: 'منذ 30 دقيقة',
    type: 'alert',
    image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '2',
    title: 'افتتاح مركز خدمات جديد في قدسيا',
    titleEn: 'New service center opened in Qudsaya',
    summary: 'مركز خدمات إلكترونية في منطقة الساحة',
    summaryEn: 'Electronic services center in Square area',
    time: 'منذ ساعة',
    type: 'success',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '3',
    title: 'تحديث: عودة الماء لجميع الأحياء',
    titleEn: 'Update: Water restored',
    summary: 'بعد انتهاء أعمال الصيانة المقررة',
    summaryEn: 'After scheduled maintenance completed',
    time: 'منذ ساعتين',
    type: 'info',
    image: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=600&q=80'
  }
];

const qudsayaDahiaNews: NewsItem[] = [
  {
    id: '1',
    title: 'إعلان عن إغلاق طريق رئيسي للصيانة',
    titleEn: 'Main road closure for maintenance',
    summary: 'طريق الضاحية الرئيسي مغلق حتى إشعار آخر',
    summaryEn: 'Main Dahia road closed until further notice',
    time: 'منذ 15 دقيقة',
    type: 'alert',
    image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '2',
    title: 'فعالية ثقافية في مركز الضاحية',
    titleEn: 'Cultural event at Dahia Center',
    summary: 'أمسية شعرية وموسيقية يوم الجمعة',
    summaryEn: 'Poetry and music evening on Friday',
    time: 'منذ ساعتين',
    type: 'success',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '3',
    title: 'تحديث: افتتاح مدرسة جديدة',
    titleEn: 'Update: New school opened',
    summary: 'مدرسة نموذجية في الحي الغربي',
    summaryEn: 'Model school in West district',
    time: 'منذ 3 ساعات',
    type: 'info',
    image: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=600&q=80'
  }
];

const dataByRegion: Record<Region, NewsItem[]> = {
  'qudsaya-center': qudsayaCenterNews,
  'qudsaya-dahia': qudsayaDahiaNews
};

export default function LocalNews() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const newsItems = dataByRegion[region];

  return (
    <section className="py-6 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-600 rounded-2xl shadow-lg">
              <Newspaper className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? `أخبار ${regionName}` : `${regionName} News`}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? 'آخر الأخبار والتحديثات' : 'Latest news and updates'}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {newsItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl transition-all overflow-hidden cursor-pointer"
            >
              <div className="relative h-36 overflow-hidden">
                <img src={item.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">
                  {isArabic ? item.title : item.titleEn}
                </h3>
                <p className="text-sm text-gray-600 mb-2">
                  {isArabic ? item.summary : item.summaryEn}
                </p>
                <div className="flex items-center gap-1 text-xs text-gray-400">
                  <Clock className="w-3.5 h-3.5" />
                  {item.time}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
