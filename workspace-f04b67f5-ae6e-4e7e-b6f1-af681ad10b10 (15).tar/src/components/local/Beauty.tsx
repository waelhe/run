'use client';

import React from 'react';
import { Scissors, Sparkles, Star, MapPin, Clock, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface BeautyPlace {
  id: string;
  name: string;
  nameEn: string;
  type: string;
  typeEn: string;
  rating: number;
  image: string;
  services: string[];
  servicesEn: string[];
  location: string;
  phone: string;
}

const qudsayaCenterBeauty: BeautyPlace[] = [
  {
    id: '1',
    name: 'صالون الأناقة',
    nameEn: 'Elegance Salon',
    type: 'صالون نسائي',
    typeEn: 'Women\'s Salon',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80',
    services: ['قص شعر', 'صبغة', 'مانيكير'],
    servicesEn: ['Haircut', 'Dye', 'Manicure'],
    location: 'قدسيا - الحي الرئيسي',
    phone: '0999123456'
  },
  {
    id: '2',
    name: 'حلاق الفارس',
    nameEn: 'Al-Fares Barber',
    type: 'حلاقة رجالية',
    typeEn: 'Men\'s Barber',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=600&q=80',
    services: ['حلاقة', 'تقصير', 'حلاقة لحية'],
    servicesEn: ['Shave', 'Haircut', 'Beard'],
    location: 'قدسيا',
    phone: '0998765432'
  },
  {
    id: '3',
    name: 'سبا الاسترخاء',
    nameEn: 'Relaxation Spa',
    type: 'مركز سبا',
    typeEn: 'Spa Center',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=600&q=80',
    services: ['مساج', 'ساونا', 'جاكوزي'],
    servicesEn: ['Massage', 'Sauna', 'Jacuzzi'],
    location: 'قدسيا - المركز',
    phone: '0111234567'
  },
  {
    id: '4',
    name: 'مركز التجميل',
    nameEn: 'Beauty Center',
    type: 'تجميل',
    typeEn: 'Beauty',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80',
    services: ['مكياج', 'عناية بالبشرة', 'تنظيف'],
    servicesEn: ['Makeup', 'Skincare', 'Cleaning'],
    location: 'قدسيا',
    phone: '0997654321'
  }
];

const qudsayaDahiaBeauty: BeautyPlace[] = [
  {
    id: '1',
    name: 'صالون الجمال',
    nameEn: 'Beauty Salon',
    type: 'صالون نسائي',
    typeEn: 'Women\'s Salon',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80',
    services: ['قص شعر', 'صبغة', 'مانيكير'],
    servicesEn: ['Haircut', 'Dye', 'Manicure'],
    location: 'الضاحية - الحي الرئيسي',
    phone: '0999234567'
  },
  {
    id: '2',
    name: 'حلاق النجوم',
    nameEn: 'Stars Barber',
    type: 'حلاقة رجالية',
    typeEn: 'Men\'s Barber',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=600&q=80',
    services: ['حلاقة', 'تقصير', 'حلاقة لحية'],
    servicesEn: ['Shave', 'Haircut', 'Beard'],
    location: 'الضاحية',
    phone: '0998345678'
  },
  {
    id: '3',
    name: 'سبا الراحة',
    nameEn: 'Comfort Spa',
    type: 'مركز سبا',
    typeEn: 'Spa Center',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=600&q=80',
    services: ['مساج', 'ساونا', 'جاكوزي'],
    servicesEn: ['Massage', 'Sauna', 'Jacuzzi'],
    location: 'الضاحية - المركز',
    phone: '0112345678'
  },
  {
    id: '4',
    name: 'مركز الأنوثة',
    nameEn: 'Femininity Center',
    type: 'تجميل',
    typeEn: 'Beauty',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80',
    services: ['مكياج', 'عناية بالبشرة', 'تنظيف'],
    servicesEn: ['Makeup', 'Skincare', 'Cleaning'],
    location: 'الضاحية',
    phone: '0997456789'
  }
];

const dataByRegion: Record<Region, BeautyPlace[]> = {
  'qudsaya-center': qudsayaCenterBeauty,
  'qudsaya-dahia': qudsayaDahiaBeauty
};

export default function Beauty() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const beautyPlaces = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-fuchsia-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-fuchsia-600 rounded-2xl shadow-lg">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'مراكز التجميل' : 'Beauty Centers'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `صالونات ومراكز العناية في ${regionName}` : `Salons and beauty care in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {beautyPlaces.map((place, index) => (
            <motion.div
              key={place.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-28 overflow-hidden">
                <img src={place.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <span className="absolute top-2 right-2 px-2 py-1 bg-fuchsia-600 text-white text-[10px] font-bold rounded-full">
                  {isArabic ? place.type : place.typeEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1">
                  {isArabic ? place.name : place.nameEn}
                </h3>
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-bold text-gray-900">{place.rating}</span>
                </div>
                <div className="flex flex-wrap gap-1 mb-2">
                  {(isArabic ? place.services : place.servicesEn).slice(0, 2).map((service, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 bg-fuchsia-100 text-fuchsia-700 rounded-full">
                      {service}
                    </span>
                  ))}
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500 mb-2">
                  <MapPin className="w-3 h-3" />
                  <span className="line-clamp-1">{place.location}</span>
                </div>
                <button className="w-full flex items-center justify-center gap-2 bg-fuchsia-600 hover:bg-fuchsia-700 text-white py-2 rounded-xl text-xs font-medium transition-colors">
                  <Phone className="w-3 h-3" />
                  {isArabic ? 'احجز موعد' : 'Book Now'}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
