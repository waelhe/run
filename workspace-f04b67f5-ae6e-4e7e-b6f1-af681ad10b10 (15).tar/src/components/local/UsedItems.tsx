'use client';

import React from 'react';
import { Package, Tag, MapPin, Clock, Percent, ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface UsedItem {
  id: string;
  title: string;
  titleEn: string;
  price: string;
  originalPrice: string;
  condition: string;
  conditionEn: string;
  image: string;
  location: string;
  time: string;
}

const qudsayaCenterItems: UsedItem[] = [
  {
    id: '1',
    title: 'ثلاجة سامسونج مستعملة',
    titleEn: 'Used Samsung Fridge',
    price: '380',
    originalPrice: '650',
    condition: 'جيدة جداً',
    conditionEn: 'Very Good',
    image: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ يوم'
  },
  {
    id: '2',
    title: 'طقم كنب مودرن',
    titleEn: 'Modern Sofa Set',
    price: '850',
    originalPrice: '1,600',
    condition: 'ممتاز',
    conditionEn: 'Excellent',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ 3 أيام'
  },
  {
    id: '3',
    title: 'لابتوب HP برو',
    titleEn: 'HP Pro Laptop',
    price: '420',
    originalPrice: '850',
    condition: 'جيد',
    conditionEn: 'Good',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ ساعتين'
  },
  {
    id: '4',
    title: 'دراجة هوائية جبلية',
    titleEn: 'Mountain Bike',
    price: '160',
    originalPrice: '320',
    condition: 'جيدة',
    conditionEn: 'Good',
    image: 'https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?auto=format&fit=crop&w=600&q=80',
    location: 'قدسيا',
    time: 'منذ أسبوع'
  }
];

const qudsayaDahiaItems: UsedItem[] = [
  {
    id: '1',
    title: 'ثلاجة سامسونج مستعملة',
    titleEn: 'Used Samsung Fridge',
    price: '350',
    originalPrice: '600',
    condition: 'جيدة جداً',
    conditionEn: 'Very Good',
    image: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ يوم'
  },
  {
    id: '2',
    title: 'طقم كنب مودرن',
    titleEn: 'Modern Sofa Set',
    price: '800',
    originalPrice: '1,500',
    condition: 'ممتاز',
    conditionEn: 'Excellent',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ 3 أيام'
  },
  {
    id: '3',
    title: 'لابتوب HP برو',
    titleEn: 'HP Pro Laptop',
    price: '400',
    originalPrice: '800',
    condition: 'جيد',
    conditionEn: 'Good',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ ساعتين'
  },
  {
    id: '4',
    title: 'دراجة هوائية جبلية',
    titleEn: 'Mountain Bike',
    price: '150',
    originalPrice: '300',
    condition: 'جيدة',
    conditionEn: 'Good',
    image: 'https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?auto=format&fit=crop&w=600&q=80',
    location: 'الضاحية',
    time: 'منذ أسبوع'
  }
];

const dataByRegion: Record<Region, UsedItem[]> = {
  'qudsaya-center': qudsayaCenterItems,
  'qudsaya-dahia': qudsayaDahiaItems
};

export default function UsedItems() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const items = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-amber-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-600 rounded-2xl shadow-lg">
              <Package className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'المستعمل' : 'Used Items'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `بيع وشراء المستعمل في ${regionName}` : `Buy and sell used items in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {items.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-28 overflow-hidden">
                <img src={item.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <span className={`absolute top-2 right-2 px-2 py-1 text-[10px] font-bold rounded-full ${
                  item.condition === 'ممتاز' ? 'bg-emerald-500 text-white' : 
                  item.condition === 'جيدة جداً' ? 'bg-blue-500 text-white' : 
                  'bg-gray-500 text-white'
                }`}>
                  {isArabic ? item.condition : item.conditionEn}
                </span>
                <div className="absolute top-2 left-2 px-2 py-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center gap-1">
                  <Percent className="w-3 h-3" />
                  <span>خصم</span>
                </div>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1 line-clamp-1">
                  {isArabic ? item.title : item.titleEn}
                </h3>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-black text-amber-600">{item.price}$</span>
                  <span className="text-xs text-gray-400 line-through">{item.originalPrice}$</span>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    <span>{item.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{item.time}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
