'use client';

import React from 'react';
import { 
  DollarSign, 
  Fuel, 
  Bus, 
  UtensilsCrossed, 
  Stethoscope,
  GraduationCap,
  Wrench,
  Home,
  Flame,
  ArrowLeft
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface QuickService {
  id: string;
  title: string;
  titleEn: string;
  subtitle: string;
  subtitleEn: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  iconBg: string;
  badge?: string;
}

const qudsayaCenterServices: QuickService[] = [
  {
    id: 'prices',
    title: 'أسعار قدسيا',
    titleEn: 'Qudsaya Prices',
    subtitle: 'أسعار يومية',
    subtitleEn: 'Daily prices',
    icon: DollarSign,
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    iconBg: 'bg-green-100'
  },
  {
    id: 'fuel',
    title: 'محطات الوقود',
    titleEn: 'Fuel Stations',
    subtitle: 'المازوت والبنزين',
    subtitleEn: 'Diesel & Gas',
    icon: Fuel,
    color: 'text-amber-600',
    bgColor: 'bg-amber-50',
    iconBg: 'bg-amber-100'
  },
  {
    id: 'transport',
    title: 'مواصلات قدسيا',
    titleEn: 'Qudsaya Transport',
    subtitle: 'حافلات وتاكسي',
    subtitleEn: 'Buses & Taxis',
    icon: Bus,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    iconBg: 'bg-blue-100'
  },
  {
    id: 'restaurants',
    title: 'مطاعم قدسيا',
    titleEn: 'Qudsaya Restaurants',
    subtitle: 'توصيل وجبات',
    subtitleEn: 'Food delivery',
    icon: UtensilsCrossed,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    iconBg: 'bg-orange-100',
    badge: 'جديد'
  },
  {
    id: 'doctors',
    title: 'أطباء قدسيا',
    titleEn: 'Qudsaya Doctors',
    subtitle: 'حجز مواعيد',
    subtitleEn: 'Appointments',
    icon: Stethoscope,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    iconBg: 'bg-red-100'
  },
  {
    id: 'education',
    title: 'تعليم قدسيا',
    titleEn: 'Qudsaya Education',
    subtitle: 'دروس ودورات',
    subtitleEn: 'Courses',
    icon: GraduationCap,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    iconBg: 'bg-purple-100'
  },
  {
    id: 'workshops',
    title: 'ورشات قدسيا',
    titleEn: 'Qudsaya Workshops',
    subtitle: 'تصليحات',
    subtitleEn: 'Repairs',
    icon: Wrench,
    color: 'text-gray-600',
    bgColor: 'bg-gray-50',
    iconBg: 'bg-gray-100'
  },
  {
    id: 'realestate',
    title: 'عقارات قدسيا',
    titleEn: 'Qudsaya Real Estate',
    subtitle: 'إيجار وبيع',
    subtitleEn: 'Rent & Sale',
    icon: Home,
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
    iconBg: 'bg-emerald-100'
  }
];

const qudsayaDahiaServices: QuickService[] = [
  {
    id: 'prices',
    title: 'أسعار الضاحية',
    titleEn: 'Dahia Prices',
    subtitle: 'أسعار يومية',
    subtitleEn: 'Daily prices',
    icon: DollarSign,
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    iconBg: 'bg-green-100'
  },
  {
    id: 'fuel',
    title: 'محطات الوقود',
    titleEn: 'Fuel Stations',
    subtitle: 'المازوت والبنزين',
    subtitleEn: 'Diesel & Gas',
    icon: Fuel,
    color: 'text-amber-600',
    bgColor: 'bg-amber-50',
    iconBg: 'bg-amber-100'
  },
  {
    id: 'transport',
    title: 'مواصلات الضاحية',
    titleEn: 'Dahia Transport',
    subtitle: 'حافلات وتاكسي',
    subtitleEn: 'Buses & Taxis',
    icon: Bus,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    iconBg: 'bg-blue-100'
  },
  {
    id: 'restaurants',
    title: 'مطاعم الضاحية',
    titleEn: 'Dahia Restaurants',
    subtitle: 'توصيل وجبات',
    subtitleEn: 'Food delivery',
    icon: UtensilsCrossed,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    iconBg: 'bg-orange-100',
    badge: 'جديد'
  },
  {
    id: 'doctors',
    title: 'أطباء الضاحية',
    titleEn: 'Dahia Doctors',
    subtitle: 'حجز مواعيد',
    subtitleEn: 'Appointments',
    icon: Stethoscope,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    iconBg: 'bg-red-100'
  },
  {
    id: 'education',
    title: 'تعليم الضاحية',
    titleEn: 'Dahia Education',
    subtitle: 'دروس ودورات',
    subtitleEn: 'Courses',
    icon: GraduationCap,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    iconBg: 'bg-purple-100'
  },
  {
    id: 'workshops',
    title: 'ورشات الضاحية',
    titleEn: 'Dahia Workshops',
    subtitle: 'تصليحات',
    subtitleEn: 'Repairs',
    icon: Wrench,
    color: 'text-gray-600',
    bgColor: 'bg-gray-50',
    iconBg: 'bg-gray-100'
  },
  {
    id: 'realestate',
    title: 'عقارات الضاحية',
    titleEn: 'Dahia Real Estate',
    subtitle: 'إيجار وبيع',
    subtitleEn: 'Rent & Sale',
    icon: Home,
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
    iconBg: 'bg-emerald-100'
  }
];

const dataByRegion: Record<Region, QuickService[]> = {
  'qudsaya-center': qudsayaCenterServices,
  'qudsaya-dahia': qudsayaDahiaServices
};

export default function QuickServices() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const quickServices = dataByRegion[region];

  return (
    <section className="py-5 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'خدمات سريعة' : 'Quick Services'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `كل ما تحتاجه في ${regionName}` : `Everything you need in ${regionName}`}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="hidden sm:flex items-center gap-1 text-emerald-600 font-bold hover:text-emerald-700">
              {isArabic ? 'عرض الكل' : 'View All'}
              <ArrowLeft className={`w-5 h-5 ${isArabic ? '' : 'rotate-180'}`} />
            </button>
            <RegionSelector />
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {quickServices.map((service, index) => {
            const Icon = service.icon;

            return (
              <motion.button
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="group relative bg-white rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-lg transition-all p-4"
              >
                {/* Badge */}
                {service.badge && (
                  <span className="absolute -top-1 -right-1 px-2 py-0.5 text-[10px] font-bold bg-red-500 text-white rounded-full shadow-sm">
                    {service.badge}
                  </span>
                )}

                <div className="flex flex-col items-center text-center">
                  <div className={`p-3 rounded-2xl ${service.iconBg} group-hover:scale-110 transition-transform mb-3`}>
                    <Icon className={`w-7 h-7 ${service.color}`} />
                  </div>
                  <h3 className="font-bold text-gray-900 text-sm mb-0.5">
                    {isArabic ? service.title : service.titleEn}
                  </h3>
                  <p className="text-xs text-gray-500">
                    {isArabic ? service.subtitle : service.subtitleEn}
                  </p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
