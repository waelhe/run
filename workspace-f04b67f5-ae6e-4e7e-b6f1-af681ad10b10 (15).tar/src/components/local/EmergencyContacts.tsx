'use client';

import React from 'react';
import { Phone, Ambulance, Flame, Shield, AlertTriangle, Car, Zap, Building } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface EmergencyContact {
  id: string;
  name: string;
  nameEn: string;
  number: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
  gradient: string;
}

const qudsayaCenterContacts: EmergencyContact[] = [
  {
    id: 'emergency',
    name: 'الطوارئ العامة',
    nameEn: 'General Emergency',
    number: '112',
    icon: AlertTriangle,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-300',
    gradient: 'from-red-500 to-red-600'
  },
  {
    id: 'ambulance',
    name: 'الإسعاف',
    nameEn: 'Ambulance',
    number: '110',
    icon: Ambulance,
    color: 'text-rose-600',
    bgColor: 'bg-rose-50',
    borderColor: 'border-rose-300',
    gradient: 'from-rose-500 to-rose-600'
  },
  {
    id: 'fire',
    name: 'الإطفاء',
    nameEn: 'Fire Department',
    number: '113',
    icon: Flame,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-300',
    gradient: 'from-orange-500 to-orange-600'
  },
  {
    id: 'police',
    name: 'شرطة قدسيا',
    nameEn: 'Qudsaya Police',
    number: '011-2234567',
    icon: Shield,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-300',
    gradient: 'from-blue-500 to-blue-600'
  },
  {
    id: 'electricity',
    name: 'طوارئ الكهرباء',
    nameEn: 'Electricity Emergency',
    number: '118',
    icon: Zap,
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50',
    borderColor: 'border-yellow-300',
    gradient: 'from-yellow-500 to-yellow-600'
  },
  {
    id: 'traffic',
    name: 'المرور',
    nameEn: 'Traffic Police',
    number: '115',
    icon: Car,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    borderColor: 'border-indigo-300',
    gradient: 'from-indigo-500 to-indigo-600'
  }
];

const qudsayaDahiaContacts: EmergencyContact[] = [
  {
    id: 'emergency',
    name: 'الطوارئ العامة',
    nameEn: 'General Emergency',
    number: '112',
    icon: AlertTriangle,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-300',
    gradient: 'from-red-500 to-red-600'
  },
  {
    id: 'ambulance',
    name: 'الإسعاف',
    nameEn: 'Ambulance',
    number: '110',
    icon: Ambulance,
    color: 'text-rose-600',
    bgColor: 'bg-rose-50',
    borderColor: 'border-rose-300',
    gradient: 'from-rose-500 to-rose-600'
  },
  {
    id: 'fire',
    name: 'الإطفاء',
    nameEn: 'Fire Department',
    number: '113',
    icon: Flame,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-300',
    gradient: 'from-orange-500 to-orange-600'
  },
  {
    id: 'police',
    name: 'شرطة الضاحية',
    nameEn: 'Dahia Police',
    number: '011-2345678',
    icon: Shield,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-300',
    gradient: 'from-blue-500 to-blue-600'
  },
  {
    id: 'electricity',
    name: 'طوارئ الكهرباء',
    nameEn: 'Electricity Emergency',
    number: '011-2356789',
    icon: Zap,
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50',
    borderColor: 'border-yellow-300',
    gradient: 'from-yellow-500 to-yellow-600'
  },
  {
    id: 'traffic',
    name: 'المرور',
    nameEn: 'Traffic Police',
    number: '115',
    icon: Car,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50',
    borderColor: 'border-indigo-300',
    gradient: 'from-indigo-500 to-indigo-600'
  }
];

const dataByRegion: Record<Region, EmergencyContact[]> = {
  'qudsaya-center': qudsayaCenterContacts,
  'qudsaya-dahia': qudsayaDahiaContacts
};

export default function EmergencyContacts() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const contacts = dataByRegion[region];

  return (
    <section className="py-5 bg-gradient-to-b from-red-50/50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-red-600 rounded-2xl shadow-lg shadow-red-200">
              <AlertTriangle className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'أرقام الطوارئ' : 'Emergency Numbers'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `اتصل مباشرة بخدمات الطوارئ - ${regionName}` : `Call emergency services directly - ${regionName}`}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-4 py-2 bg-red-100 text-red-700 text-base font-bold rounded-full flex items-center gap-1">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              24/7
            </span>
            <RegionSelector />
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {contacts.map((contact, index) => {
            const Icon = contact.icon;

            return (
              <motion.a
                key={contact.id}
                href={`tel:${contact.number}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`group relative bg-white rounded-2xl border-2 ${contact.borderColor} hover:shadow-xl transition-all overflow-hidden`}
              >
                {/* Gradient Top */}
                <div className={`h-1.5 bg-gradient-to-r ${contact.gradient}`} />
                
                <div className="p-5">
                  <div className="flex items-center gap-4">
                    {/* Icon */}
                    <div className={`p-4 rounded-2xl ${contact.bgColor} group-hover:scale-110 transition-transform`}>
                      <Icon className={`w-8 h-8 ${contact.color}`} />
                    </div>

                    {/* Info */}
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-900 mb-1">
                        {isArabic ? contact.name : contact.nameEn}
                      </h3>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-400" />
                        <span className="text-2xl font-black text-gray-800">
                          {contact.number}
                        </span>
                      </div>
                    </div>

                    {/* Call Button */}
                    <div className={`p-4 rounded-full bg-gradient-to-r ${contact.gradient} shadow-lg group-hover:scale-110 transition-transform`}>
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </div>
              </motion.a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
