'use client';

import React from 'react';
import { MapPin, Star, Clock, Camera, TreePine, Building2, Landmark } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRegion, Region } from '@/contexts/RegionContext';
import RegionSelector from './RegionSelector';

interface Place {
  id: string;
  name: string;
  nameEn: string;
  type: string;
  typeEn: string;
  rating: number;
  image: string;
  description: string;
  descriptionEn: string;
}

// بيانات ضاحية قدسيا
const qudsayaDahiaPlaces: Place[] = [
  {
    id: 'd1',
    name: 'حديقة ضاحية قدسيا',
    nameEn: 'Qudsaya Dahia Park',
    type: 'حدائق',
    typeEn: 'Parks',
    rating: 4.5,
    image: 'https://images.unsplash.com/photo-1519331379826-f10be5486c6f?auto=format&fit=crop&w=600&q=80',
    description: 'حديقة كبيرة مع ملاعب أطفال',
    descriptionEn: 'Large park with playgrounds'
  },
  {
    id: 'd2',
    name: 'نادي الضاحية الرياضية',
    nameEn: 'Dahia Sports Club',
    type: 'معالم',
    typeEn: 'Attractions',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?auto=format&fit=crop&w=600&q=80',
    description: 'نادي رياضي متكامل',
    descriptionEn: 'Complete sports club'
  },
  {
    id: 'd3',
    name: 'سوق الضاحية الشعبي',
    nameEn: 'Dahia Popular Market',
    type: 'أسواق',
    typeEn: 'Markets',
    rating: 4.4,
    image: 'https://images.unsplash.com/photo-1598892550437-0784ad7f36a6?auto=format&fit=crop&w=600&q=80',
    description: 'سوق شعبي متنوع',
    descriptionEn: 'Diverse popular market'
  },
  {
    id: 'd4',
    name: 'جامع الضاحية الكبير',
    nameEn: 'Grand Dahia Mosque',
    type: 'معالم دينية',
    typeEn: 'Religious Sites',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1542816417-0983c9c9ad53?auto=format&fit=crop&w=600&q=80',
    description: 'مسجد كبير وجامع',
    descriptionEn: 'Large and grand mosque'
  }
];

// بيانات قدسيا المركز
const qudsayaCenterPlaces: Place[] = [
  {
    id: 'c1',
    name: 'حديقة قدسيا المركزية',
    nameEn: 'Qudsaya Central Park',
    type: 'حدائق',
    typeEn: 'Parks',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1519331379826-f10be5486c6f?auto=format&fit=crop&w=600&q=80',
    description: 'حديقة خلابة مع إطلالة جبلية',
    descriptionEn: 'Beautiful park with mountain views'
  },
  {
    id: 'c2',
    name: 'قلعة قدسيا التاريخية',
    nameEn: 'Historic Qudsaya Castle',
    type: 'معالم سياحية',
    typeEn: 'Attractions',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1554907984-15263bfd63bd?auto=format&fit=crop&w=600&q=80',
    description: 'معلم تاريخي قديم',
    descriptionEn: 'Ancient historical landmark'
  },
  {
    id: 'c3',
    name: 'سوق قدسيا الشعبي',
    nameEn: 'Qudsaya Popular Market',
    type: 'أسواق',
    typeEn: 'Markets',
    rating: 4.5,
    image: 'https://images.unsplash.com/photo-1598892550437-0784ad7f36a6?auto=format&fit=crop&w=600&q=80',
    description: 'سوق تقليدي بمنتجات محلية',
    descriptionEn: 'Traditional market with local products'
  },
  {
    id: 'c4',
    name: 'جامع قدسيا الكبير',
    nameEn: 'Grand Qudsaya Mosque',
    type: 'معالم دينية',
    typeEn: 'Religious Sites',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1542816417-0983c9c9ad53?auto=format&fit=crop&w=600&q=80',
    description: 'مسجد تاريخي',
    descriptionEn: 'Historic mosque'
  }
];

const placesByRegion: Record<Region, Place[]> = {
  'qudsaya-center': qudsayaCenterPlaces,
  'qudsaya-dahia': qudsayaDahiaPlaces
};

const categories = [
  { icon: TreePine, name: 'حدائق', nameEn: 'Parks', color: 'bg-emerald-600' },
  { icon: Landmark, name: 'معالم', nameEn: 'Attractions', color: 'bg-amber-600' },
  { icon: Building2, name: 'أسواق', nameEn: 'Markets', color: 'bg-blue-600' },
  { icon: Camera, name: 'سياحة', nameEn: 'Tourism', color: 'bg-purple-600' }
];

export default function Places() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const places = placesByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-teal-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-teal-600 rounded-2xl shadow-lg">
              <MapPin className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'السياحة والأماكن' : 'Tourism & Places'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `أماكن سياحية في ${regionName}` : `Tourist places in ${regionName}`}
              </p>
            </div>
          </div>
          
          <RegionSelector />
        </div>

        {/* Categories */}
        <div className="flex gap-3 mb-5 overflow-x-auto pb-2">
          {categories.map((cat, index) => {
            const Icon = cat.icon;
            return (
              <motion.button
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-full whitespace-nowrap hover:shadow-md transition-shadow"
              >
                <div className={`p-1.5 ${cat.color} rounded-full`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {isArabic ? cat.name : cat.nameEn}
                </span>
              </motion.button>
            );
          })}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {places.map((place, index) => (
            <motion.div
              key={place.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-32 overflow-hidden">
                <img src={place.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <span className="absolute top-2 right-2 px-2 py-1 bg-white/90 text-gray-700 text-[10px] font-bold rounded-full">
                  {isArabic ? place.type : place.typeEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1">
                  {isArabic ? place.name : place.nameEn}
                </h3>
                <p className="text-xs text-gray-500 mb-2 line-clamp-1">
                  {isArabic ? place.description : place.descriptionEn}
                </p>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-sm font-bold text-gray-900">{place.rating}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
