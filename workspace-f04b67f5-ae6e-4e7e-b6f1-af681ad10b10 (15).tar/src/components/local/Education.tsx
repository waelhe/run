'use client';

import React from 'react';
import { GraduationCap, Users, BookOpen, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from './RegionSelector';
import { useRegion, Region } from '@/contexts/RegionContext';

interface School {
  id: string;
  name: string;
  nameEn: string;
  type: string;
  typeEn: string;
  level: string;
  levelEn: string;
  students: number;
  rating: number;
  image: string;
  isEnrolling: boolean;
}

const qudsayaCenterSchools: School[] = [
  {
    id: '1',
    name: 'مدرسة قدسيا النموذجية',
    nameEn: 'Qudsaya Model School',
    type: 'حكومية',
    typeEn: 'Public',
    level: 'ابتدائي - ثانوي',
    levelEn: 'Primary - Secondary',
    students: 900,
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=600&q=80',
    isEnrolling: true
  },
  {
    id: '2',
    name: 'روضة قدسيا',
    nameEn: 'Qudsaya Kindergarten',
    type: 'خاصة',
    typeEn: 'Private',
    level: 'رياض أطفال',
    levelEn: 'Kindergarten',
    students: 150,
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80',
    isEnrolling: true
  },
  {
    id: '3',
    name: 'معهد اللغات - قدسيا',
    nameEn: 'Languages Institute - Qudsaya',
    type: 'خاصة',
    typeEn: 'Private',
    level: 'دورات لغات',
    levelEn: 'Language Courses',
    students: 400,
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=600&q=80',
    isEnrolling: false
  },
  {
    id: '4',
    name: 'مركز التفوق - قدسيا',
    nameEn: 'Excellence Center - Qudsaya',
    type: 'خاصة',
    typeEn: 'Private',
    level: 'دروس خصوصية',
    levelEn: 'Private Tutoring',
    students: 250,
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=600&q=80',
    isEnrolling: true
  }
];

const qudsayaDahiaSchools: School[] = [
  {
    id: '1',
    name: 'مدرسة الضاحية النموذجية',
    nameEn: 'Dahia Model School',
    type: 'حكومية',
    typeEn: 'Public',
    level: 'ابتدائي - ثانوي',
    levelEn: 'Primary - Secondary',
    students: 850,
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=600&q=80',
    isEnrolling: true
  },
  {
    id: '2',
    name: 'روضة الأمل - الضاحية',
    nameEn: 'Al-Amal Kindergarten - Dahia',
    type: 'خاصة',
    typeEn: 'Private',
    level: 'رياض أطفال',
    levelEn: 'Kindergarten',
    students: 120,
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80',
    isEnrolling: true
  },
  {
    id: '3',
    name: 'معهد اللغات - الضاحية',
    nameEn: 'Languages Institute - Dahia',
    type: 'خاصة',
    typeEn: 'Private',
    level: 'دورات لغات',
    levelEn: 'Language Courses',
    students: 350,
    rating: 4.5,
    image: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=600&q=80',
    isEnrolling: false
  },
  {
    id: '4',
    name: 'مركز التفوق - الضاحية',
    nameEn: 'Excellence Center - Dahia',
    type: 'خاصة',
    typeEn: 'Private',
    level: 'دروس خصوصية',
    levelEn: 'Private Tutoring',
    students: 200,
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=600&q=80',
    isEnrolling: true
  }
];

const dataByRegion: Record<Region, School[]> = {
  'qudsaya-center': qudsayaCenterSchools,
  'qudsaya-dahia': qudsayaDahiaSchools
};

export default function Education() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const { region, regionName } = useRegion();
  const schools = dataByRegion[region];

  return (
    <section className="py-6 bg-gradient-to-b from-indigo-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-600 rounded-2xl shadow-lg">
              <GraduationCap className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900">
                {isArabic ? 'التعليم والمدارس' : 'Education & Schools'}
              </h2>
              <p className="text-sm text-gray-500">
                {isArabic ? `مدارس ومعاهد في ${regionName}` : `Schools and institutes in ${regionName}`}
              </p>
            </div>
          </div>
          <RegionSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {schools.map((school, index) => (
            <motion.div
              key={school.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-2xl border border-gray-200 hover:shadow-xl overflow-hidden cursor-pointer"
            >
              <div className="relative h-32 overflow-hidden">
                <img src={school.image} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                {school.isEnrolling && (
                  <span className="absolute top-2 right-2 px-2 py-1 bg-emerald-500 text-white text-[10px] font-bold rounded-full">
                    {isArabic ? 'تسجيل مفتوح' : 'Enrolling'}
                  </span>
                )}
                <span className={`absolute top-2 left-2 px-2 py-1 text-[10px] font-bold rounded-full ${
                  school.type === 'حكومية' ? 'bg-blue-500 text-white' : 'bg-white/90 text-gray-700'
                }`}>
                  {isArabic ? school.type : school.typeEn}
                </span>
              </div>
              <div className="p-3">
                <h3 className="text-sm font-bold text-gray-900 mb-1 line-clamp-1">
                  {isArabic ? school.name : school.nameEn}
                </h3>
                <p className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
                  {isArabic ? school.level : school.levelEn}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Users className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{school.students}+</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                    <span className="text-sm font-bold text-gray-900">{school.rating}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
