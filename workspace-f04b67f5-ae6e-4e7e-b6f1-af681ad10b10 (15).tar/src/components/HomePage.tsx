/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Home Page Component - Reorganized
 * نبض قدسيا - الصفحة الرئيسية
 */

'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AlertTriangle, Phone, Zap, Bell, Heart, ShoppingBag, Home, Bus, GraduationCap,
  ChevronDown, ChevronUp, MapPin
} from 'lucide-react';
import { Hero } from '@/components/ui';
import { useLanguage } from '@/contexts/LanguageContext';
import RegionSelector from '@/components/local/RegionSelector';
import { 
  ServicesStatus, PrayerTimes, WeatherWidget, EmergencyContacts, UrgentServices,
  MainSections, QuickServices, LocalNews, Events, Restaurants, Doctors, Education,
  Transport, Classifieds, GovernmentServices, Sports, RealEstate, UsedItems,
  Community, Jobs, Craftsmen, Places, Charity, Beauty, Markets, FeaturedOffers
} from '@/components/local';

interface Category {
  id: string;
  name: string;
  nameEn: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
  sections: React.ReactNode[];
}

export function HomePage() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['emergency']);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const categories: Category[] = [
    {
      id: 'emergency',
      name: 'طوارئ ومناوبات',
      nameEn: 'Emergency & On-Duty',
      icon: AlertTriangle,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200',
      sections: [<UrgentServices key="urgent" />, <EmergencyContacts key="emergency" />]
    },
    {
      id: 'services',
      name: 'حالة الخدمات والحكومة',
      nameEn: 'Services Status & Government',
      icon: Zap,
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-200',
      sections: [<ServicesStatus key="status" />, <GovernmentServices key="gov" />]
    },
    {
      id: 'daily',
      name: 'يوميات وأوقات',
      nameEn: 'Daily & Times',
      icon: Bell,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200',
      sections: [<PrayerTimes key="prayer" />, <WeatherWidget key="weather" />, <Events key="events" />, <LocalNews key="news" />]
    },
    {
      id: 'health',
      name: 'صحة وجمال',
      nameEn: 'Health & Beauty',
      icon: Heart,
      color: 'text-rose-600',
      bgColor: 'bg-rose-50',
      borderColor: 'border-rose-200',
      sections: [<Doctors key="doctors" />, <Beauty key="beauty" />]
    },
    {
      id: 'food',
      name: 'مطاعم وأسواق',
      nameEn: 'Food & Markets',
      icon: ShoppingBag,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200',
      sections: [<Restaurants key="restaurants" />, <Markets key="markets" />]
    },
    {
      id: 'realestate',
      name: 'عقارات ووظائف',
      nameEn: 'Real Estate & Jobs',
      icon: Home,
      color: 'text-teal-600',
      bgColor: 'bg-teal-50',
      borderColor: 'border-teal-200',
      sections: [<RealEstate key="realestate" />, <Jobs key="jobs" />, <UsedItems key="used" />, <Classifieds key="classifieds" />]
    },
    {
      id: 'transport',
      name: 'مواصلات وأماكن',
      nameEn: 'Transport & Places',
      icon: Bus,
      color: 'text-cyan-600',
      bgColor: 'bg-cyan-50',
      borderColor: 'border-cyan-200',
      sections: [<Transport key="transport" />, <Places key="places" />, <Sports key="sports" />]
    },
    {
      id: 'community',
      name: 'تعليم ومجتمع',
      nameEn: 'Education & Community',
      icon: GraduationCap,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      borderColor: 'border-indigo-200',
      sections: [<Education key="education" />, <Craftsmen key="craftsmen" />, <Community key="community" />, <Charity key="charity" />]
    }
  ];

  return (
    <main className="min-h-screen bg-gray-50">
      {/* 🌟 Hero Section */}
      <Hero />

      {/* 🎯 Quick Access Bar */}
      <section className="sticky top-0 z-50 bg-white shadow-md border-b">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-emerald-500" />
              <RegionSelector />
            </div>
            <div className="flex items-center gap-2">
              <a href="tel:112" className="flex items-center gap-1.5 px-3 py-2 bg-red-100 text-red-700 rounded-full text-sm font-bold hover:bg-red-200 transition-colors">
                <AlertTriangle className="w-4 h-4" />
                <span className="hidden sm:inline">{isArabic ? 'طوارئ' : 'Emergency'}</span>
              </a>
              <a href="tel:110" className="flex items-center gap-1.5 px-3 py-2 bg-rose-100 text-rose-700 rounded-full text-sm font-bold hover:bg-rose-200 transition-colors">
                <Phone className="w-4 h-4" />
                <span className="hidden sm:inline">{isArabic ? 'إسعاف' : 'Ambulance'}</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 🔥 Featured Offers - Prominent Position */}
      <FeaturedOffers />

      {/* 📱 Main Sections Grid */}
      <section className="max-w-7xl mx-auto px-4 py-4">
        <MainSections />
      </section>

      {/* 📑 Categories - Collapsible */}
      <div className="max-w-7xl mx-auto px-4 pb-8 space-y-4">
        {categories.map((category) => {
          const Icon = category.icon;
          const isExpanded = expandedCategories.includes(category.id);

          return (
            <motion.div
              key={category.id}
              className={`rounded-2xl border-2 ${category.borderColor} ${category.bgColor} overflow-hidden shadow-sm`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <button
                onClick={() => toggleCategory(category.id)}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-white/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-white shadow-sm">
                    <Icon className={`w-6 h-6 ${category.color}`} />
                  </div>
                  <div className="text-right">
                    <h2 className={`text-lg font-black ${category.color}`}>
                      {isArabic ? category.name : category.nameEn}
                    </h2>
                    <p className="text-xs text-gray-500">
                      {category.sections.length} {isArabic ? 'أقسام' : 'sections'}
                    </p>
                  </div>
                </div>
                <div className="p-2 rounded-full bg-white shadow-sm">
                  {isExpanded ? (
                    <ChevronUp className={`w-5 h-5 ${category.color}`} />
                  ) : (
                    <ChevronDown className={`w-5 h-5 ${category.color}`} />
                  )}
                </div>
              </button>

              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-white border-t border-gray-100">
                      {category.sections.map((section, index) => (
                        <div key={index} className="border-b border-gray-100 last:border-b-0">
                          {section}
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>

      {/* ⚡ Quick Services */}
      <QuickServices />
    </main>
  );
}
