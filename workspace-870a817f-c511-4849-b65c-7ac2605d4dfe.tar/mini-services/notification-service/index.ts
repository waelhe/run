/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Notification Service - خدمة الإشعارات الفورية
 * 
 * خدمة WebSocket للإشعارات الفورية والدردشة في منصة ضيف
 * 
 * @module mini-services/notification-service
 */

import { createServer } from 'http'
import { Server, Socket } from 'socket.io'

// ==================== Types ====================

/**
 * المستخدم المتصل
 */
interface ConnectedUser {
  id: string
  userId: string
  socketId: string
  role: 'user' | 'host' | 'company' | 'admin'
  rooms: string[]
  lastActivity: Date
}

/**
 * الإشعار
 */
interface Notification {
  id: string
  type: NotificationType
  title: string
  titleAr: string
  message: string
  messageAr: string
  data?: Record<string, unknown>
  createdAt: Date
  read: boolean
}

/**
 * أنواع الإشعارات
 */
type NotificationType = 
  | 'booking.new'
  | 'booking.confirmed'
  | 'booking.cancelled'
  | 'booking.completed'
  | 'payment.success'
  | 'payment.failed'
  | 'refund.processed'
  | 'review.new'
  | 'review.response'
  | 'message.new'
  | 'listing.approved'
  | 'listing.rejected'
  | 'escrow.released'
  | 'dispute.opened'
  | 'system.announcement'
  | 'system.maintenance'

/**
 * رسالة الدردشة
 */
interface ChatMessage {
  id: string
  conversationId: string
  senderId: string
  senderName: string
  content: string
  type: 'text' | 'image' | 'file' | 'system'
  createdAt: Date
  read: boolean
  readBy: string[]
}

/**
 * المحادثة
 */
interface Conversation {
  id: string
  participants: string[]
  type: 'booking' | 'support' | 'direct'
  bookingId?: string
  listingId?: string
  createdAt: Date
  updatedAt: Date
  lastMessage?: ChatMessage
  unreadCount: Record<string, number>
}

/**
 * حدث الكتابة
 */
interface TypingEvent {
  conversationId: string
  userId: string
  userName: string
  isTyping: boolean
}

// ==================== State ====================

const connectedUsers = new Map<string, ConnectedUser>()
const userSockets = new Map<string, Set<string>>() // userId -> Set<socketId>

// ==================== Helper Functions ====================

const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

const createNotification = (
  type: NotificationType,
  title: string,
  titleAr: string,
  message: string,
  messageAr: string,
  data?: Record<string, unknown>
): Notification => ({
  id: generateId(),
  type,
  title,
  titleAr,
  message,
  messageAr,
  data,
  createdAt: new Date(),
  read: false,
})

const createSystemMessage = (conversationId: string, content: string): ChatMessage => ({
  id: generateId(),
  conversationId,
  senderId: 'system',
  senderName: 'System',
  content,
  type: 'system',
  createdAt: new Date(),
  read: false,
  readBy: [],
})

// ==================== Socket.IO Server ====================

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// ==================== Authentication Middleware ====================

io.use((socket, next) => {
  const userId = socket.handshake.auth.userId
  const role = socket.handshake.auth.role || 'user'
  
  if (!userId) {
    return next(new Error('Authentication required'))
  }
  
  // Store user info in socket
  socket.data.userId = userId
  socket.data.role = role
  
  next()
})

// ==================== Connection Handler ====================

io.on('connection', (socket: Socket) => {
  const userId = socket.data.userId
  const role = socket.data.role
  
  console.log(`[NotificationService] User connected: ${userId} (${socket.id})`)

  // Register user
  const user: ConnectedUser = {
    id: generateId(),
    userId,
    socketId: socket.id,
    role,
    rooms: [],
    lastActivity: new Date(),
  }
  connectedUsers.set(socket.id, user)

  // Track user sockets (for multi-device support)
  if (!userSockets.has(userId)) {
    userSockets.set(userId, new Set())
  }
  userSockets.get(userId)!.add(socket.id)

  // Join user's personal room
  const userRoom = `user:${userId}`
  socket.join(userRoom)
  user.rooms.push(userRoom)

  // Emit connection success
  socket.emit('connected', {
    userId,
    socketId: socket.id,
    timestamp: new Date(),
  })

  // ==================== Notification Events ====================

  /**
   * إرسال إشعار لمستخدم
   */
  socket.on('notification:send', (data: {
    targetUserId: string
    type: NotificationType
    title: string
    titleAr: string
    message: string
    messageAr: string
    data?: Record<string, unknown>
  }) => {
    const notification = createNotification(
      data.type,
      data.title,
      data.titleAr,
      data.message,
      data.messageAr,
      data.data
    )
    
    io.to(`user:${data.targetUserId}`).emit('notification:new', notification)
    console.log(`[NotificationService] Notification sent to ${data.targetUserId}: ${data.type}`)
  })

  /**
   * إرسال إشعار لجميع المستخدمين
   */
  socket.on('notification:broadcast', (data: {
    type: NotificationType
    title: string
    titleAr: string
    message: string
    messageAr: string
    data?: Record<string, unknown>
  }) => {
    // Only admins can broadcast
    if (role !== 'admin') {
      socket.emit('error', { message: 'Unauthorized' })
      return
    }
    
    const notification = createNotification(
      data.type,
      data.title,
      data.titleAr,
      data.message,
      data.messageAr,
      data.data
    )
    
    io.emit('notification:new', notification)
    console.log(`[NotificationService] Broadcast notification: ${data.type}`)
  })

  /**
   * تحديث حالة قراءة الإشعار
   */
  socket.on('notification:mark-read', (data: { notificationId: string }) => {
    // This would typically update a database
    socket.emit('notification:read', { notificationId: data.notificationId })
  })

  // ==================== Chat Events ====================

  /**
   * الانضمام لمحادثة
   */
  socket.on('conversation:join', (data: { conversationId: string }) => {
    socket.join(`conversation:${data.conversationId}`)
    user.rooms.push(`conversation:${data.conversationId}`)
    socket.emit('conversation:joined', { conversationId: data.conversationId })
    console.log(`[NotificationService] User ${userId} joined conversation ${data.conversationId}`)
  })

  /**
   * مغادرة محادثة
   */
  socket.on('conversation:leave', (data: { conversationId: string }) => {
    socket.leave(`conversation:${data.conversationId}`)
    user.rooms = user.rooms.filter(r => r !== `conversation:${data.conversationId}`)
    socket.emit('conversation:left', { conversationId: data.conversationId })
  })

  /**
   * إرسال رسالة دردشة
   */
  socket.on('message:send', (data: {
    conversationId: string
    content: string
    type?: 'text' | 'image' | 'file'
    senderName: string
  }) => {
    const message: ChatMessage = {
      id: generateId(),
      conversationId: data.conversationId,
      senderId: userId,
      senderName: data.senderName,
      content: data.content,
      type: data.type || 'text',
      createdAt: new Date(),
      read: false,
      readBy: [],
    }

    // Broadcast to conversation
    io.to(`conversation:${data.conversationId}`).emit('message:new', message)
    
    // Notify offline participants (would need database lookup in real implementation)
    console.log(`[NotificationService] Message sent in ${data.conversationId} by ${userId}`)
  })

  /**
   * تحديث حالة قراءة الرسائل
   */
  socket.on('message:mark-read', (data: {
    conversationId: string
    messageIds: string[]
  }) => {
    socket.to(`conversation:${data.conversationId}`).emit('message:read', {
      conversationId: data.conversationId,
      messageIds: data.messageIds,
      readBy: userId,
      readAt: new Date(),
    })
  })

  /**
   * حدث الكتابة
   */
  socket.on('typing:start', (data: { conversationId: string; userName: string }) => {
    socket.to(`conversation:${data.conversationId}`).emit('typing:update', {
      conversationId: data.conversationId,
      userId,
      userName: data.userName,
      isTyping: true,
    } as TypingEvent)
  })

  socket.on('typing:stop', (data: { conversationId: string }) => {
    socket.to(`conversation:${data.conversationId}`).emit('typing:update', {
      conversationId: data.conversationId,
      userId,
      userName: '',
      isTyping: false,
    } as TypingEvent)
  })

  // ==================== Booking Events ====================

  /**
   * إشعار حجز جديد للمضيف
   */
  socket.on('booking:new', (data: {
    hostId: string
    bookingId: string
    listingId: string
    guestName: string
    checkIn: Date
    checkOut: Date
  }) => {
    const notification = createNotification(
      'booking.new',
      'New Booking',
      'حجز جديد',
      `You have a new booking from ${data.guestName}`,
      `لديك حجز جديد من ${data.guestName}`,
      { bookingId: data.bookingId, listingId: data.listingId }
    )
    
    io.to(`user:${data.hostId}`).emit('notification:new', notification)
    console.log(`[NotificationService] New booking notification to host ${data.hostId}`)
  })

  /**
   * إشعار تأكيد الحجز للضيف
   */
  socket.on('booking:confirmed', (data: {
    guestId: string
    bookingId: string
    listingTitle: string
  }) => {
    const notification = createNotification(
      'booking.confirmed',
      'Booking Confirmed',
      'تم تأكيد الحجز',
      `Your booking for ${data.listingTitle} has been confirmed`,
      `تم تأكيد حجزك لـ ${data.listingTitle}`,
      { bookingId: data.bookingId }
    )
    
    io.to(`user:${data.guestId}`).emit('notification:new', notification)
  })

  /**
   * إشعار إلغاء الحجز
   */
  socket.on('booking:cancelled', (data: {
    targetUserId: string
    bookingId: string
    listingTitle: string
    cancelledBy: string
    reason?: string
  }) => {
    const notification = createNotification(
      'booking.cancelled',
      'Booking Cancelled',
      'تم إلغاء الحجز',
      `Booking for ${data.listingTitle} has been cancelled`,
      `تم إلغاء حجز ${data.listingTitle}`,
      { bookingId: data.bookingId, reason: data.reason }
    )
    
    io.to(`user:${data.targetUserId}`).emit('notification:new', notification)
  })

  // ==================== Payment Events ====================

  /**
   * إشعار نجاح الدفع
   */
  socket.on('payment:success', (data: {
    userId: string
    paymentId: string
    bookingId: string
    amount: number
    currency: string
  }) => {
    const notification = createNotification(
      'payment.success',
      'Payment Successful',
      'تم الدفع بنجاح',
      `Payment of ${data.amount} ${data.currency} processed successfully`,
      `تم معالجة دفعة ${data.amount} ${data.currency} بنجاح`,
      { paymentId: data.paymentId, bookingId: data.bookingId }
    )
    
    io.to(`user:${data.userId}`).emit('notification:new', notification)
  })

  /**
   * إشعار فشل الدفع
   */
  socket.on('payment:failed', (data: {
    userId: string
    paymentId: string
    amount: number
    currency: string
    reason: string
  }) => {
    const notification = createNotification(
      'payment.failed',
      'Payment Failed',
      'فشل الدفع',
      `Payment of ${data.amount} ${data.currency} failed: ${data.reason}`,
      `فشلت دفعة ${data.amount} ${data.currency}: ${data.reason}`,
      { paymentId: data.paymentId }
    )
    
    io.to(`user:${data.userId}`).emit('notification:new', notification)
  })

  // ==================== Review Events ====================

  /**
   * إشعار تقييم جديد
   */
  socket.on('review:new', (data: {
    revieweeId: string
    reviewId: string
    listingId: string
    reviewerName: string
    rating: number
  }) => {
    const notification = createNotification(
      'review.new',
      'New Review',
      'تقييم جديد',
      `You received a ${data.rating}-star review from ${data.reviewerName}`,
      `حصلت على تقييم ${data.rating} نجوم من ${data.reviewerName}`,
      { reviewId: data.reviewId, listingId: data.listingId }
    )
    
    io.to(`user:${data.revieweeId}`).emit('notification:new', notification)
  })

  // ==================== Admin Events ====================

  /**
   * انضمام للغرفة الإدارية
   */
  if (role === 'admin') {
    socket.join('admin:room')
    
    socket.on('admin:announcement', (data: {
      title: string
      titleAr: string
      message: string
      messageAr: string
      targetRoles?: string[]
    }) => {
      const notification = createNotification(
        'system.announcement',
        data.title,
        data.titleAr,
        data.message,
        data.messageAr
      )
      
      if (data.targetRoles && data.targetRoles.length > 0) {
        // Send to specific roles
        data.targetRoles.forEach(targetRole => {
          io.emit('notification:new', { ...notification, targetRole })
        })
      } else {
        // Broadcast to all
        io.emit('notification:new', notification)
      }
    })
  }

  // ==================== Presence Events ====================

  /**
   * الحصول على المستخدمين المتصلين
   */
  socket.on('presence:get-online', (data: { userIds: string[] }) => {
    const onlineStatus: Record<string, boolean> = {}
    data.userIds.forEach(uid => {
      onlineStatus[uid] = userSockets.has(uid)
    })
    socket.emit('presence:online-status', onlineStatus)
  })

  /**
   * تحديث النشاط
   */
  socket.on('presence:activity', () => {
    if (connectedUsers.has(socket.id)) {
      connectedUsers.get(socket.id)!.lastActivity = new Date()
    }
  })

  // ==================== Disconnect Handler ====================

  socket.on('disconnect', (reason) => {
    console.log(`[NotificationService] User disconnected: ${userId} (${socket.id}) - ${reason}`)
    
    // Remove from connected users
    connectedUsers.delete(socket.id)
    
    // Remove from user sockets
    const sockets = userSockets.get(userId)
    if (sockets) {
      sockets.delete(socket.id)
      if (sockets.size === 0) {
        userSockets.delete(userId)
        
        // Notify contacts about offline status
        socket.broadcast.emit('presence:offline', { userId })
      }
    }
  })

  // ==================== Error Handler ====================

  socket.on('error', (error) => {
    console.error(`[NotificationService] Socket error (${socket.id}):`, error)
  })
})

// ==================== Heartbeat for inactive connections ====================

setInterval(() => {
  const now = new Date()
  const timeout = 5 * 60 * 1000 // 5 minutes

  connectedUsers.forEach((user, socketId) => {
    if (now.getTime() - user.lastActivity.getTime() > timeout) {
      const socket = io.sockets.sockets.get(socketId)
      if (socket) {
        socket.emit('error', { message: 'Connection timeout due to inactivity' })
        socket.disconnect(true)
      }
    }
  })
}, 60 * 1000) // Check every minute

// ==================== Server Start ====================

const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`[NotificationService] WebSocket server running on port ${PORT}`)
})

// ==================== Graceful Shutdown ====================

process.on('SIGTERM', () => {
  console.log('[NotificationService] Received SIGTERM signal, shutting down...')
  
  // Notify all connected clients
  io.emit('server:shutdown', {
    message: 'Server is shutting down for maintenance',
    reconnectIn: 5000,
  })
  
  // Close all connections
  io.close(() => {
    console.log('[NotificationService] All connections closed')
    httpServer.close(() => {
      console.log('[NotificationService] Server closed')
      process.exit(0)
    })
  })
})

process.on('SIGINT', () => {
  console.log('[NotificationService] Received SIGINT signal, shutting down...')
  
  io.emit('server:shutdown', {
    message: 'Server is shutting down for maintenance',
    reconnectIn: 5000,
  })
  
  io.close(() => {
    httpServer.close(() => {
      process.exit(0)
    })
  })
})

export { io, connectedUsers, userSockets }
