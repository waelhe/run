/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Logger Service
 * 
 * خدمة التسجيل المركزية - بديل آمن لـ console.log
 * 
 * الاستخدام:
 * ```typescript
 * import { logger } from '@/infrastructure/services/logger.service';
 * 
 * logger.info('تم إنشاء حجز جديد', { bookingId: '123' });
 * logger.error('فشل في الدفع', { error: err });
 * logger.warn('تحذير: محاولة وصول غير مصرح', { userId: '456' });
 * logger.debug('معلومات التشخيص', { data });
 * ```
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: string;
  context?: Record<string, unknown>;
  service?: string;
}

class LoggerService {
  private isDevelopment = process.env.NODE_ENV === 'development';
  private isProduction = process.env.NODE_ENV === 'production';
  
  // تخزين السجلات للمراجعة (في الذاكرة فقط)
  private logs: LogEntry[] = [];
  private maxLogs = 1000;

  /**
   * تنسيق السجل للعرض
   */
  private formatEntry(entry: LogEntry): string {
    const { level, message, timestamp, context } = entry;
    const levelEmoji = {
      debug: '🔍',
      info: 'ℹ️',
      warn: '⚠️',
      error: '❌',
    };
    
    const contextStr = context ? ` | ${JSON.stringify(context)}` : '';
    return `${levelEmoji[level]} [${timestamp}] ${message}${contextStr}`;
  }

  /**
   * إضافة سجل
   */
  private addLog(level: LogLevel, message: string, context?: Record<string, unknown>): void {
    const entry: LogEntry = {
      level,
      message,
      timestamp: new Date().toISOString(),
      context,
    };

    // في التطوير: اطبع في الـ console
    if (this.isDevelopment) {
      const formatted = this.formatEntry(entry);
      
      switch (level) {
        case 'error':
          console.error(formatted);
          break;
        case 'warn':
          console.warn(formatted);
          break;
        case 'debug':
          // debug فقط في التطوير
          console.log(formatted);
          break;
        default:
          console.log(formatted);
      }
    }

    // في الإنتاج: لا تطبع في console
    // لكن خزن للمراجعة
    this.logs.push(entry);
    
    // حافظ على حدود الذاكرة
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }
  }

  /**
   * تسجيل معلومات تشخيصية (فقط في التطوير)
   */
  debug(message: string, context?: Record<string, unknown>): void {
    if (this.isDevelopment) {
      this.addLog('debug', message, context);
    }
  }

  /**
   * تسجيل معلومات عامة
   */
  info(message: string, context?: Record<string, unknown>): void {
    this.addLog('info', message, context);
  }

  /**
   * تسجيل تحذير
   */
  warn(message: string, context?: Record<string, unknown>): void {
    this.addLog('warn', message, context);
  }

  /**
   * تسجيل خطأ
   */
  error(message: string, context?: Record<string, unknown>): void {
    this.addLog('error', message, context);
  }

  /**
   * الحصول على جميع السجلات
   */
  getLogs(level?: LogLevel): LogEntry[] {
    if (level) {
      return this.logs.filter(log => log.level === level);
    }
    return [...this.logs];
  }

  /**
   * مسح السجلات
   */
  clearLogs(): void {
    this.logs = [];
  }

  /**
   * تصدير السجلات بصيغة JSON
   */
  exportLogs(): string {
    return JSON.stringify(this.logs, null, 2);
  }

  /**
   * إنشاء logger خاص بخدمة معينة
   */
  forService(serviceName: string): ServiceLogger {
    return new ServiceLogger(this, serviceName);
  }
}

/**
 * Logger خاص بخدمة معينة
 */
class ServiceLogger {
  constructor(
    private logger: LoggerService,
    private serviceName: string
  ) {}

  private withContext(context?: Record<string, unknown>): Record<string, unknown> | undefined {
    return context ? { ...context, service: this.serviceName } : { service: this.serviceName };
  }

  debug(message: string, context?: Record<string, unknown>): void {
    this.logger.debug(`[${this.serviceName}] ${message}`, context);
  }

  info(message: string, context?: Record<string, unknown>): void {
    this.logger.info(`[${this.serviceName}] ${message}`, context);
  }

  warn(message: string, context?: Record<string, unknown>): void {
    this.logger.warn(`[${this.serviceName}] ${message}`, context);
  }

  error(message: string, context?: Record<string, unknown>): void {
    this.logger.error(`[${this.serviceName}] ${message}`, context);
  }
}

// إنشاء instance واحد (Singleton)
export const logger = new LoggerService();

// تصدير الأنواع
export type { LoggerService, ServiceLogger };
