/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Environment Variables Validation
 * 
 * التحقق من متغيرات البيئة عند بدء التطبيق
 * 
 * @module lib/env
 */

import { z } from 'zod';

// ==================== Schema ====================

const envSchema = z.object({
  // Required in production
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  
  // Database
  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),
  
  // Authentication
  JWT_SECRET: z.string()
    .optional()
    .refine(
      (val) => process.env.NODE_ENV !== 'production' || (val && val.length >= 32),
      'JWT_SECRET must be at least 32 characters in production'
    ),
  
  // CORS (optional, defaults will be used)
  ALLOWED_ORIGINS: z.string().optional(),
  
  // External Services (optional)
  OPENAI_API_KEY: z.string().optional(),
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.string().optional(),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  
  // Storage (optional)
  AWS_ACCESS_KEY_ID: z.string().optional(),
  AWS_SECRET_ACCESS_KEY: z.string().optional(),
  AWS_REGION: z.string().optional(),
  S3_BUCKET: z.string().optional(),
});

// ==================== Validation ====================

let validatedEnv: z.infer<typeof envSchema> | null = null;
let validationError: string | null = null;

/**
 * التحقق من متغيرات البيئة
 */
export function validateEnv(): { success: boolean; error?: string } {
  try {
    // Skip validation in test environment
    if (process.env.NODE_ENV === 'test') {
      validatedEnv = process.env as unknown as z.infer<typeof envSchema>;
      return { success: true };
    }

    const result = envSchema.safeParse(process.env);
    
    if (!result.success) {
      const errors = result.error.issues.map(
        (issue) => `  - ${issue.path.join('.')}: ${issue.message}`
      );
      validationError = `Environment validation failed:\n${errors.join('\n')}`;
      
      // In production, throw error
      if (process.env.NODE_ENV === 'production') {
        console.error('❌', validationError);
        throw new Error(validationError);
      }
      
      // In development, warn but continue
      console.warn('⚠️', validationError);
      return { success: false, error: validationError };
    }
    
    validatedEnv = result.data;
    return { success: true };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    validationError = message;
    return { success: false, error: message };
  }
}

/**
 * الحصول على متغيرات البيئة المحققة
 */
export function getEnv(): z.infer<typeof envSchema> {
  if (!validatedEnv) {
    validateEnv();
  }
  return validatedEnv!;
}

/**
 * التحقق من وجود مفتاح معين
 */
export function hasEnvVar(key: string): boolean {
  return !!process.env[key];
}

/**
 * الحصول على قيمة مفتاح مع الإعداد الافتراضي
 */
export function getEnvValue(key: string, defaultValue?: string): string | undefined {
  return process.env[key] || defaultValue;
}

// ==================== Check on Import ====================

// Validate environment on module import
// This ensures errors are caught early
if (typeof window === 'undefined') {
  const result = validateEnv();
  if (result.success) {
    console.log('✅ Environment variables validated successfully');
  }
}

// ==================== Export Types ====================

export type Env = z.infer<typeof envSchema>;
