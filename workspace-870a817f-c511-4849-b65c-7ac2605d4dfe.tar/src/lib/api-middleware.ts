/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * API Middleware
 *
 * برمجيات وسيطة لمسارات API
 *
 * @module lib/api-middleware
 */

import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from './auth';
import { logger } from '@/infrastructure/services/logger.service';

// ==================== Types ====================

export interface RequestContext {
  userId?: string;
  userRole?: string;
  ip?: string;
  userAgent?: string;
  requestId: string;
  startTime: number;
}

export interface MiddlewareResult {
  success: boolean;
  context?: RequestContext;
  error?: NextResponse;
}

export type MiddlewareFunction = (
  request: NextRequest,
  context: RequestContext
) => Promise<MiddlewareResult | NextResponse>;

// ==================== CSRF Protection ====================

/**
 * توليد رمز CSRF
 */
export function generateCsrfToken(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * التحقق من رمز CSRF
 */
export function validateCsrfToken(
  request: NextRequest,
  sessionToken?: string
): boolean {
  // GET, HEAD, OPTIONS لا تحتاج CSRF
  const safeMethods = ['GET', 'HEAD', 'OPTIONS'];
  if (safeMethods.includes(request.method)) {
    return true;
  }

  // الحصول على الرمز من Header أو Body
  const headerToken = request.headers.get('x-csrf-token');
  
  // التحقق من Origin
  const origin = request.headers.get('origin');
  const host = request.headers.get('host');
  
  // إذا كان الطلب من نفس الأصل
  if (origin && host) {
    const originHost = origin.replace(/^https?:\/\//, '');
    if (originHost !== host) {
      logger.warn('CSRF: Origin mismatch', { origin, host });
      return false;
    }
  }

  // التحقق من Referer كـ fallback
  const referer = request.headers.get('referer');
  if (!origin && !referer) {
    logger.warn('CSRF: Missing origin and referer');
    return false;
  }

  // إذا كان هناك session token، تحقق من CSRF token
  if (sessionToken && !headerToken) {
    logger.warn('CSRF: Missing token for authenticated request');
    return false;
  }

  return true;
}

/**
 * CSRF Protection Middleware
 */
export function withCsrfProtection(): MiddlewareFunction {
  return async (request: NextRequest, context: RequestContext) => {
    const user = await getCurrentUser();
    const sessionToken = user ? 'authenticated' : undefined;

    if (!validateCsrfToken(request, sessionToken)) {
      return NextResponse.json(
        {
          success: false,
          error: {
            code: 'CSRF_ERROR',
            message: 'طلب غير مصرح به',
          },
          meta: { timestamp: new Date().toISOString(), requestId: context.requestId },
        },
        { status: 403 }
      );
    }

    return { success: true, context };
  };
}

// ==================== Rate Limiter ====================

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

/**
 * تنظيف السجلات القديمة
 */
function cleanupRateLimitStore(): void {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore.entries()) {
    if (entry.resetTime < now) {
      rateLimitStore.delete(key);
    }
  }
}

// تنظيف كل 5 دقائق
setInterval(cleanupRateLimitStore, 5 * 60 * 1000);

/**
 * التحقق من Rate Limit
 */
export function checkRateLimit(
  key: string,
  maxRequests: number = 100,
  windowMs: number = 60 * 1000
): { allowed: boolean; remaining: number; resetTime: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(key);

  if (!entry || entry.resetTime < now) {
    rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
    return { allowed: true, remaining: maxRequests - 1, resetTime: now + windowMs };
  }

  if (entry.count >= maxRequests) {
    return { allowed: false, remaining: 0, resetTime: entry.resetTime };
  }

  entry.count++;
  return { allowed: true, remaining: maxRequests - entry.count, resetTime: entry.resetTime };
}

/**
 * Rate Limit Middleware
 */
export function withRateLimit(
  maxRequests: number = 100,
  windowMs: number = 60 * 1000
): MiddlewareFunction {
  return async (request: NextRequest, context: RequestContext) => {
    const ip = context.ip || 'unknown';
    const key = `${ip}:${request.nextUrl.pathname}`;

    const { allowed, remaining, resetTime } = checkRateLimit(key, maxRequests, windowMs);

    if (!allowed) {
      const response = NextResponse.json(
        {
          success: false,
          error: {
            code: 'TOO_MANY_REQUESTS',
            message: 'تم تجاوز الحد المسموح من الطلبات',
          },
          meta: { timestamp: new Date().toISOString() },
        },
        { status: 429 }
      );
      response.headers.set('X-RateLimit-Limit', String(maxRequests));
      response.headers.set('X-RateLimit-Remaining', '0');
      response.headers.set('X-RateLimit-Reset', String(Math.floor(resetTime / 1000)));
      response.headers.set('Retry-After', String(Math.ceil((resetTime - Date.now()) / 1000)));
      return response;
    }

    return {
      success: true,
      context: {
        ...context,
        remaining,
      },
    };
  };
}

// ==================== Authentication ====================

/**
 * Require Auth Middleware
 */
export function requireAuth(): MiddlewareFunction {
  return async (request: NextRequest, context: RequestContext) => {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'يجب تسجيل الدخول',
          },
          meta: { timestamp: new Date().toISOString() },
        },
        { status: 401 }
      );
    }

    return {
      success: true,
      context: {
        ...context,
        userId: user.id,
        userRole: user.role,
      },
    };
  };
}

/**
 * Require Role Middleware
 */
export function requireRole(...roles: string[]): MiddlewareFunction {
  return async (request: NextRequest, context: RequestContext) => {
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          error: {
            code: 'UNAUTHORIZED',
            message: 'يجب تسجيل الدخول',
          },
          meta: { timestamp: new Date().toISOString() },
        },
        { status: 401 }
      );
    }

    if (!roles.includes(user.role)) {
      return NextResponse.json(
        {
          success: false,
          error: {
            code: 'FORBIDDEN',
            message: 'ليس لديك صلاحية للوصول',
          },
          meta: { timestamp: new Date().toISOString() },
        },
        { status: 403 }
      );
    }

    return {
      success: true,
      context: {
        ...context,
        userId: user.id,
        userRole: user.role,
      },
    };
  };
}

// ==================== Request Logging ====================

/**
 * إنشاء معرف طلب فريد
 */
export function generateRequestId(): string {
  return `req_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}

/**
 * استخراج IP من الطلب
 */
export function getClientIp(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }

  const realIp = request.headers.get('x-real-ip');
  if (realIp) {
    return realIp;
  }

  return 'unknown';
}

/**
 * تسجيل الطلب
 */
export function logRequest(
  request: NextRequest,
  context: RequestContext,
  statusCode: number,
  duration: number
): void {
  const logData = {
    requestId: context.requestId,
    method: request.method,
    path: request.nextUrl.pathname,
    query: Object.fromEntries(request.nextUrl.searchParams),
    statusCode,
    duration: `${duration}ms`,
    userId: context.userId,
    ip: context.ip,
    userAgent: context.userAgent,
    timestamp: new Date().toISOString(),
  };

  // Log using logger service
  if (statusCode >= 400) {
    logger.error('API Error', logData);
  } else {
    logger.debug('API Request', logData);
  }
}

// ==================== Compose Middleware ====================

/**
 * تجميع عدة برمجيات وسيطة
 */
export function composeMiddleware(
  ...middlewares: MiddlewareFunction[]
): (request: NextRequest) => Promise<{ context: RequestContext; error?: NextResponse }> {
  return async (request: NextRequest) => {
    const context: RequestContext = {
      requestId: generateRequestId(),
      startTime: Date.now(),
      ip: getClientIp(request),
      userAgent: request.headers.get('user-agent') || undefined,
    };

    for (const middleware of middlewares) {
      const result = await middleware(request, context);

      // If it's a NextResponse, it's an error response
      if (result instanceof NextResponse) {
        return { context, error: result };
      }

      // Update context if middleware succeeded
      if (result.success && result.context) {
        Object.assign(context, result.context);
      }

      // If middleware failed, return error
      if (!result.success && result.error) {
        return { context, error: result.error };
      }
    }

    return { context };
  };
}

// ==================== Error Handler ====================

/**
 * معالج الأخطاء العام
 */
export function handleApiError(
  error: unknown,
  context: RequestContext
): NextResponse {
  const requestId = context.requestId;

  // Log the error
  logger.error('API Error', {
    requestId,
    error: error instanceof Error ? error.message : 'Unknown error',
    stack: error instanceof Error ? error.stack : undefined,
  });

  // Return appropriate error response
  if (error instanceof Error) {
    // Check for specific error types
    if (error.message.includes('not found') || error.message.includes('غير موجود')) {
      return NextResponse.json(
        {
          success: false,
          error: { code: 'NOT_FOUND', message: error.message },
          meta: { timestamp: new Date().toISOString(), requestId },
        },
        { status: 404 }
      );
    }

    if (error.message.includes('unauthorized') || error.message.includes('غير مصرح')) {
      return NextResponse.json(
        {
          success: false,
          error: { code: 'UNAUTHORIZED', message: error.message },
          meta: { timestamp: new Date().toISOString(), requestId },
        },
        { status: 401 }
      );
    }

    if (error.message.includes('forbidden') || error.message.includes('صلاحية')) {
      return NextResponse.json(
        {
          success: false,
          error: { code: 'FORBIDDEN', message: error.message },
          meta: { timestamp: new Date().toISOString(), requestId },
        },
        { status: 403 }
      );
    }

    if (error.message.includes('validation') || error.message.includes('خطأ في')) {
      return NextResponse.json(
        {
          success: false,
          error: { code: 'VALIDATION_ERROR', message: error.message },
          meta: { timestamp: new Date().toISOString(), requestId },
        },
        { status: 400 }
      );
    }

    // Generic error
    return NextResponse.json(
      {
        success: false,
        error: { code: 'INTERNAL_ERROR', message: 'حدث خطأ داخلي' },
        meta: { timestamp: new Date().toISOString(), requestId },
      },
      { status: 500 }
    );
  }

  // Unknown error
  return NextResponse.json(
    {
      success: false,
      error: { code: 'INTERNAL_ERROR', message: 'حدث خطأ غير متوقع' },
      meta: { timestamp: new Date().toISOString(), requestId },
    },
    { status: 500 }
  );
}

// ==================== CORS ====================

/**
 * الأصول المسموح بها - من متغيرات البيئة أو القيم الافتراضية
 */
const getAllowedOrigins = (): string[] => {
  const origins = process.env.ALLOWED_ORIGINS;
  if (origins) {
    return origins.split(',').map(o => o.trim()).filter(Boolean);
  }
  
  // في التطوير: السماح بالأصول المحلية
  if (process.env.NODE_ENV === 'development') {
    return [
      'http://localhost:3000',
      'http://127.0.0.1:3000',
      'http://localhost:3001',
    ];
  }
  
  // في الإنتاج: يجب تحديد الأ origins
  return [];
};

/**
 * التحقق من أن الأصل مسموح به
 */
function isAllowedOrigin(origin: string | null): boolean {
  if (!origin) return false;
  
  const allowedOrigins = getAllowedOrigins();
  
  // السماح بـ same-origin requests
  if (origin === 'null' || origin === '') return true;
  
  return allowedOrigins.includes(origin);
}

/**
 * إضافة CORS Headers مع حماية
 */
export function addCorsHeaders(response: NextResponse, request?: NextRequest): NextResponse {
  const origin = request?.headers.get('origin') || '*';
  
  // التحقق من الأصل المسموح
  if (origin !== '*' && isAllowedOrigin(origin)) {
    response.headers.set('Access-Control-Allow-Origin', origin);
    response.headers.set('Access-Control-Allow-Credentials', 'true');
  } else if (process.env.NODE_ENV === 'development') {
    // في التطوير فقط: السماح بـ * للأ origins غير المعروفة
    response.headers.set('Access-Control-Allow-Origin', origin || '*');
    response.headers.set('Access-Control-Allow-Credentials', 'true');
  }
  // في الإنتاج: لا نضيف CORS header إذا كان الأصل غير مسموح
  
  response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, X-CSRF-Token');
  response.headers.set('Access-Control-Max-Age', '86400');
  return response;
}

/**
 * CORS Preflight Handler
 */
export function handleCorsPreflightRequest(): NextResponse {
  const response = new NextResponse(null, { status: 204 });
  return addCorsHeaders(response);
}

// ==================== Request Helpers ====================

/**
 * استخراج معلمات الصفحات
 */
export function getPaginationParams(request: NextRequest): {
  page: number;
  limit: number;
  skip: number;
} {
  const { searchParams } = request.nextUrl;
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
  const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
  const skip = (page - 1) * limit;
  return { page, limit, skip };
}

/**
 * استخراج معلمات الفرز
 */
export function getSortParams(
  request: NextRequest,
  defaultField: string = 'createdAt',
  defaultOrder: 'asc' | 'desc' = 'desc'
): { sortBy: string; sortOrder: 'asc' | 'desc' } {
  const { searchParams } = request.nextUrl;
  return {
    sortBy: searchParams.get('sortBy') || defaultField,
    sortOrder: (searchParams.get('sortOrder') as 'asc' | 'desc') || defaultOrder,
  };
}

/**
 * التحقق من طلب JSON
 */
export async function parseJsonBody<T>(request: NextRequest): Promise<T | null> {
  try {
    return await request.json();
  } catch {
    return null;
  }
}
