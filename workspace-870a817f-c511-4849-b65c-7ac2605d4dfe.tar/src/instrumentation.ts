/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Instrumentation - يعمل عند بدء الخادم
 * 
 * يستخدم للتحقق من البيئة وإعداد الخدمات
 * 
 * @see https://nextjs.org/docs/app/building-your-application/optimizing/instrumentation
 */

export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    // التحقق من متغيرات البيئة
    const { validateEnv } = await import('@/lib/env');
    const result = validateEnv();
    
    if (!result.success) {
      console.error('❌ Environment validation failed:', result.error);
      if (process.env.NODE_ENV === 'production') {
        process.exit(1);
      }
    }
    
    console.log('🚀 Dayf platform starting...');
  }
}
