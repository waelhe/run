import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { LanguageProvider, AuthProvider, CartProvider } from "@/contexts";
import { Header, Footer, BottomNav } from "@/components/layout";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ضيف - منصة السياحة والخدمات في سوريا",
  description: "منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال في سوريا. اكتشف أفضل الإقامات والخدمات.",
  keywords: ["ضيف", "سياحة", "سوريا", "إقامة", "علاج", "دراسة", "أعمال"],
  authors: [{ name: "Dayf Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "ضيف - منصة السياحة والخدمات في سوريا",
    description: "منصة متكاملة للسياحة، العلاج، الدراسة، وفرص الأعمال في سوريا",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <LanguageProvider>
          <AuthProvider>
            <CartProvider>
              <div className="min-h-screen flex flex-col">
                <Header />
                <div className="flex-1 pt-16 pb-16 md:pb-0">
                  {children}
                </div>
                <Footer />
                <BottomNav />
              </div>
              <Toaster />
            </CartProvider>
          </AuthProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
