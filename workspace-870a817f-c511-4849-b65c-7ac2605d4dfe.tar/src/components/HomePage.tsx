/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Home Page Component
 * 
 * الصفحة الرئيسية
 */

'use client';

import { useLanguage } from '@/contexts/LanguageContext';
import { Hero, Categories, ServiceSection, WhyChooseUs } from '@/components/ui';

export function HomePage() {
  const { language } = useLanguage();

  return (
    <main className="min-h-screen bg-white">
      {/* Hero Section with slideshow */}
      <Hero />
      
      {/* Categories Bar */}
      <Categories />
      
      {/* Service Sections */}
      <div className="pb-12">
        {/* Featured Accommodations */}
        <ServiceSection 
          title={language === 'ar' ? 'أماكن إقامة مميزة' : 'Featured Accommodations'}
          categoryId="tourism"
          filterPopular={true}
          limit={8}
        />

        {/* Hotels & Resorts */}
        <ServiceSection 
          title={language === 'ar' ? 'فنادق ومنتجعات' : 'Hotels & Resorts'}
          subtitle={language === 'ar' ? 'مجموعة من الفنادق المستقلة والمختارة بعناية' : 'A curated collection of independent hotels'}
          categoryId="tourism"
          limit={8}
        />

        {/* Medical Services */}
        <ServiceSection 
          title={language === 'ar' ? 'خدمات طبية متميزة' : 'Top medical services'}
          subtitle={language === 'ar' ? 'أفضل المراكز الطبية والأطباء في سوريا' : 'The best medical centers and doctors in Syria'}
          categoryId="medical"
          limit={8}
        />

        {/* Education */}
        <ServiceSection 
          title={language === 'ar' ? 'تعليم وتدريب' : 'Education & Training'}
          subtitle={language === 'ar' ? 'طور مهاراتك مع أفضل الخبراء' : 'Develop your skills with the best experts'}
          categoryId="education"
          limit={8}
        />

        {/* Business Services */}
        <ServiceSection 
          title={language === 'ar' ? 'خدمات الأعمال' : 'Business Services'}
          subtitle={language === 'ar' ? 'حلول احترافية لنمو أعمالك' : 'Professional solutions for your business growth'}
          categoryId="business"
          limit={8}
        />

        {/* Why Choose Us */}
        <WhyChooseUs />
      </div>
    </main>
  );
}
