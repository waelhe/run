'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Search, MapPin, Calendar, Users, Briefcase, Stethoscope, GraduationCap, Plane, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const SYRIA_REGIONS = [
  { id: 'damascus', name: 'دمشق', description: 'أقدم عاصمة في التاريخ', image: '/cities/damascus.png' },
  { id: 'aleppo', name: 'حلب', description: 'قلعة حلب الشامخة', image: '/cities/aleppo.png' },
  { id: 'palmyra', name: 'تدمر', description: 'عروس البادية', image: '/cities/palmyra.png' },
  { id: 'latakia', name: 'اللاذقية', description: 'عروس الساحل', image: '/cities/latakia.png' },
  { id: 'hama', name: 'حماة', description: 'مدينة النواعير', image: '/cities/hama.png' },
  { id: 'maaloula', name: 'معلولا', description: 'مهد الآرامية', image: '/cities/maaloula.png' },
];

const TABS = [
  { id: 'tourism', icon: Plane },
  { id: 'medical', icon: Stethoscope },
  { id: 'education', icon: GraduationCap },
  { id: 'business', icon: Briefcase },
  { id: 'ai', icon: Sparkles },
];

export default function Hero() {
  const { t } = useLanguage();
  const router = useRouter();
  
  const [activeTab, setActiveTab] = useState('tourism');
  const [regionIndex, setRegionIndex] = useState(0);
  const [searchData, setSearchData] = useState({ location: '', date: '', guests: 1, aiQuery: '' });

  const currentRegion = useMemo(() => SYRIA_REGIONS[regionIndex], [regionIndex]);

  // Auto-rotate regions
  useEffect(() => {
    const interval = setInterval(() => {
      setRegionIndex((prev) => (prev + 1) % SYRIA_REGIONS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (searchData.location) params.set('search', searchData.location);
    if (searchData.date) params.set('date', searchData.date);
    if (searchData.guests > 1) params.set('guests', searchData.guests.toString());
    params.set('category', activeTab);
    router.push(`/?${params.toString()}`);
  };

  const handleAISearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchData.aiQuery.trim()) {
      router.push(`/?search=${encodeURIComponent(searchData.aiQuery)}&type=ai`);
    }
  };

  return (
    <section className="relative min-h-[500px] sm:min-h-[600px] lg:min-h-[700px] flex items-center overflow-hidden">
      {/* Background Images */}
      <div className="absolute inset-0">
        {SYRIA_REGIONS.map((region, idx) => (
          <div
            key={region.id}
            className="absolute inset-0 transition-opacity duration-1000 ease-in-out"
            style={{ opacity: idx === regionIndex ? 1 : 0 }}
          >
            <Image
              src={region.image}
              alt={region.name}
              fill
              className="object-cover"
              priority={idx === 0}
              sizes="100vw"
            />
          </div>
        ))}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/30 to-white" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        <div className="text-center mb-10">
          {/* Badge */}
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur border border-white/20 text-white text-sm mb-6">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            {t('hero.smart_travel')}
          </span>

          {/* Title */}
          <h1 className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-black text-white mb-3 sm:mb-4 drop-shadow-lg">
            {t('hero.title').split('ضيف')[0]}<span className="text-emerald-400">ضيف</span>
          </h1>
          
          <p className="text-base sm:text-lg md:text-2xl text-white/90 mb-4 sm:mb-6 max-w-2xl mx-auto px-2">
            {t('hero.subtitle')}
          </p>

          {/* Region Selector */}
          <div className="inline-flex items-center gap-2 sm:gap-3 bg-black/30 backdrop-blur rounded-full px-3 sm:px-4 py-1.5 sm:py-2 text-white">
            <button 
              onClick={() => setRegionIndex((prev) => (prev - 1 + SYRIA_REGIONS.length) % SYRIA_REGIONS.length)}
              className="p-2 hover:text-emerald-400 transition-colors touch-manipulation"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <div className="text-center min-w-[100px] sm:min-w-[140px]">
              <span className="block font-bold text-emerald-400 text-sm sm:text-base">{currentRegion.name}</span>
              <span className="block text-xs text-gray-300">{currentRegion.description}</span>
            </div>
            <button 
              onClick={() => setRegionIndex((prev) => (prev + 1) % SYRIA_REGIONS.length)}
              className="p-2 hover:text-emerald-400 transition-colors touch-manipulation"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search Box */}
        <div className="max-w-4xl mx-auto px-1 sm:px-0">
          <div className="bg-white/90 backdrop-blur-xl rounded-2xl lg:rounded-full shadow-2xl p-2 sm:p-3">
            {/* Tabs */}
            <div className="flex items-center justify-center gap-0.5 sm:gap-1 mb-2 lg:mb-0 lg:gap-2 overflow-x-auto hide-scrollbar">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2.5 rounded-full transition-all whitespace-nowrap touch-manipulation ${
                      isActive 
                        ? 'bg-emerald-600 text-white shadow-lg' 
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-xs sm:text-sm font-semibold">{t(`hero.tab.${tab.id}`)}</span>
                  </button>
                );
              })}
            </div>

            {/* Search Fields */}
            <div className="flex flex-col lg:flex-row items-center gap-2 lg:gap-0">
              {activeTab === 'ai' ? (
                <form onSubmit={handleAISearch} className="flex items-center w-full gap-2 px-4 py-2">
                  <Sparkles className="w-5 h-5 text-emerald-500" />
                  <input
                    type="text"
                    value={searchData.aiQuery}
                    onChange={(e) => setSearchData({ ...searchData, aiQuery: e.target.value })}
                    placeholder={t('hero.ai_placeholder')}
                    className="flex-1 bg-transparent outline-none text-gray-800"
                  />
                  <button
                    type="submit"
                    disabled={!searchData.aiQuery.trim()}
                    className="bg-emerald-600 text-white px-6 py-2.5 rounded-full hover:bg-emerald-700 transition-colors disabled:opacity-50"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                </form>
              ) : (
                <>
                  <div className="flex items-center gap-2 px-4 py-2 flex-1 w-full lg:w-auto">
                    <MapPin className="w-5 h-5 text-emerald-600" />
                    <input
                      type="text"
                      value={searchData.location}
                      onChange={(e) => setSearchData({ ...searchData, location: e.target.value })}
                      placeholder={t('hero.destination')}
                      className="flex-1 bg-transparent outline-none text-gray-800"
                    />
                  </div>
                  <div className="hidden md:flex items-center gap-2 px-4 py-2 flex-1 border-l border-gray-200">
                    <Calendar className="w-5 h-5 text-emerald-600" />
                    <input
                      type="date"
                      value={searchData.date}
                      onChange={(e) => setSearchData({ ...searchData, date: e.target.value })}
                      className="flex-1 bg-transparent outline-none text-gray-800"
                    />
                  </div>
                  <div className="hidden lg:flex items-center gap-2 px-4 py-2 flex-1 border-l border-gray-200">
                    <Users className="w-5 h-5 text-emerald-600" />
                    <select
                      value={searchData.guests}
                      onChange={(e) => setSearchData({ ...searchData, guests: Number(e.target.value) })}
                      className="flex-1 bg-transparent outline-none text-gray-800"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                        <option key={n} value={n}>{n} {n === 1 ? t('hero.guest_unit') : t('hero.guests_unit')}</option>
                      ))}
                    </select>
                  </div>
                  <button
                    onClick={handleSearch}
                    className="w-full lg:w-auto bg-emerald-600 text-white px-8 py-3 lg:py-2.5 rounded-xl lg:rounded-full hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Search className="w-5 h-5" />
                    <span className="font-semibold">{t('hero.search')}</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Region Dots */}
          <div className="flex items-center justify-center gap-2 mt-4 sm:mt-6">
            {SYRIA_REGIONS.map((region, idx) => (
              <button
                key={region.id}
                onClick={() => setRegionIndex(idx)}
                className={`h-2 rounded-full transition-all touch-manipulation ${
                  idx === regionIndex ? 'bg-emerald-400 w-6 h-2' : 'bg-white/50 hover:bg-white/80 w-2 h-2'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
