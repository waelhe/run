'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Star, MapPin, Heart, ChevronRight, ChevronLeft } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export interface Listing {
  id: string;
  title: string;
  slug: string;
  type: string;
  city?: string;
  country?: string;
  basePrice: number;
  currency: string;
  capacity: number;
  bedrooms?: number;
  bathrooms?: number;
  ratingAverage?: number;
  ratingCount: number;
  featured?: boolean;
  images: Array<{ id: string; url: string; isPrimary: boolean }>;
  amenities: Array<{ name: string }>;
  host?: {
    firstName: string;
    lastName: string;
    avatar?: string;
  };
}

interface ServiceCardProps {
  listing: Listing;
  className?: string;
}

export default function ServiceCard({ 
  listing, 
  className = "w-[280px] md:w-[300px]"
}: ServiceCardProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [imageError, setImageError] = useState(false);
  const { language } = useLanguage();

  const images = listing.images || [];
  const hasImages = images.length > 0 && !imageError;
  const currentImage = hasImages ? images[currentImageIndex]?.url : null;
  const location = [listing.city, listing.country].filter(Boolean).join('، ');

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (hasImages) {
      setCurrentImageIndex((prev) => (prev + 1) % images.length);
    }
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (hasImages) {
      setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
    }
  };

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  const formatPrice = (price: number, currency: string) => {
    return new Intl.NumberFormat(language === 'ar' ? 'ar-SY' : 'en-US', {
      style: 'currency',
      currency: currency || 'SYP',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div
      className={`group flex flex-col shrink-0 cursor-pointer ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container */}
      <div className="relative aspect-[4/3] rounded-2xl overflow-hidden mb-3 bg-gray-100">
        {/* Image */}
        {currentImage ? (
          <img 
            src={currentImage} 
            alt={listing.title || 'Listing'} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
            <MapPin className="w-10 h-10 text-gray-300" />
          </div>
        )}

        {/* Gradient Overlay on Hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Carousel Controls */}
        {isHovered && hasImages && images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute top-1/2 right-2 -translate-y-1/2 p-2 bg-white/95 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-lg"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button 
              onClick={nextImage}
              className="absolute top-1/2 left-2 -translate-y-1/2 p-2 bg-white/95 backdrop-blur-sm rounded-full text-gray-700 hover:bg-white hover:scale-110 transition-all z-10 shadow-lg"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </>
        )}

        {/* Image Dots */}
        {hasImages && images.length > 1 && (
          <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-10">
            {images.slice(0, 5).map((_, idx) => (
              <div 
                key={idx} 
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  idx === currentImageIndex 
                    ? 'bg-white w-4' 
                    : 'bg-white/60 w-1.5 hover:bg-white/80'
                }`}
              />
            ))}
          </div>
        )}

        {/* Featured Badge */}
        {listing.featured && (
          <div className="absolute top-3 right-3 z-10">
            <span className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-lg">
              {language === 'ar' ? 'مميز' : 'Featured'}
            </span>
          </div>
        )}

        {/* Favorite Button */}
        <button 
          onClick={toggleFavorite}
          className="absolute top-3 left-3 z-10 p-2 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white hover:scale-110 transition-all shadow-md"
        >
          <Heart 
            className={`w-5 h-5 transition-all ${
              isFavorite 
                ? 'fill-red-500 text-red-500' 
                : 'text-gray-600 hover:text-red-500'
            }`} 
          />
        </button>
      </div>
      
      {/* Content */}
      <div className="flex flex-col gap-1.5 px-1">
        {/* Title & Rating */}
        <div className="flex justify-between items-start gap-2">
          <h3 className="text-base font-bold text-gray-900 truncate flex-1">
            {listing.title}
          </h3>
          {listing.ratingAverage && (
            <div className="flex items-center gap-1 shrink-0 bg-gray-50 px-2 py-0.5 rounded-full">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="text-sm font-semibold text-gray-800">{listing.ratingAverage.toFixed(1)}</span>
            </div>
          )}
        </div>
        
        {/* Location */}
        {location && (
          <p className="text-sm text-gray-500 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-gray-400" />
            <span className="truncate">{location}</span>
          </p>
        )}
        
        {/* Price */}
        <div className="flex items-baseline gap-1.5 pt-1">
          <span className="text-lg font-bold text-gray-900">{formatPrice(listing.basePrice, listing.currency)}</span>
          <span className="text-sm text-gray-500">
            {language === 'ar' ? '/لليلة' : '/night'}
          </span>
        </div>
      </div>
    </div>
  );
}
