'use client';

import React from 'react';
import Link from 'next/link';
import { Plane, Stethoscope, GraduationCap, Briefcase, Home, Sparkles, Utensils, Camera, ShoppingBag, Car } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const CATEGORIES = [
  { id: 'tourism', icon: Plane, color: 'from-blue-500 to-cyan-500', lightBg: 'bg-blue-50' },
  { id: 'medical', icon: Stethoscope, color: 'from-rose-500 to-pink-500', lightBg: 'bg-rose-50' },
  { id: 'realestate', icon: Home, color: 'from-emerald-500 to-teal-500', lightBg: 'bg-emerald-50' },
  { id: 'education', icon: GraduationCap, color: 'from-amber-500 to-yellow-500', lightBg: 'bg-amber-50' },
  { id: 'business', icon: Briefcase, color: 'from-violet-500 to-purple-500', lightBg: 'bg-violet-50' },
  { id: 'experiences', icon: Sparkles, color: 'from-fuchsia-500 to-pink-500', lightBg: 'bg-fuchsia-50' },
  { id: 'dining', icon: Utensils, color: 'from-orange-500 to-red-500', lightBg: 'bg-orange-50' },
  { id: 'photography', icon: Camera, color: 'from-pink-500 to-rose-500', lightBg: 'bg-pink-50' },
  { id: 'shopping', icon: ShoppingBag, color: 'from-cyan-500 to-blue-500', lightBg: 'bg-cyan-50' },
  { id: 'transport', icon: Car, color: 'from-slate-500 to-gray-500', lightBg: 'bg-slate-50' },
];

const LABELS: Record<string, { ar: string; en: string }> = {
  tourism: { ar: 'سياحة وإقامة', en: 'Tourism' },
  medical: { ar: 'خدمات طبية', en: 'Medical' },
  realestate: { ar: 'عقارات', en: 'Real Estate' },
  education: { ar: 'تعليم وتدريب', en: 'Education' },
  business: { ar: 'خدمات أعمال', en: 'Business' },
  experiences: { ar: 'تجارب فريدة', en: 'Experiences' },
  dining: { ar: 'مطاعم', en: 'Dining' },
  photography: { ar: 'تصوير', en: 'Arts' },
  shopping: { ar: 'تسوق', en: 'Shopping' },
  transport: { ar: 'مواصلات', en: 'Transport' },
};

export default function Categories() {
  const { language } = useLanguage();

  return (
    <section className="py-6 bg-gradient-to-b from-white to-gray-50/50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 sm:gap-6 overflow-x-auto hide-scrollbar pb-2 -mx-4 px-4 sm:mx-0 sm:px-0">
          {CATEGORIES.map((category, index) => {
            const Icon = category.icon;
            const label = LABELS[category.id];
            return (
              <Link
                key={category.id}
                href={`/?category=${category.id}`}
                className="group flex flex-col items-center gap-2 min-w-[72px] sm:min-w-[80px]"
                style={{ animationDelay: `${index * 30}ms` }}
              >
                {/* Icon Container */}
                <div className="relative">
                  {/* Glow Effect */}
                  <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300`} />
                  
                  {/* Icon Box */}
                  <div className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl ${category.lightBg} flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:shadow-lg group-active:scale-95`}>
                    <Icon className={`w-6 h-6 sm:w-7 sm:h-7 text-gray-700 transition-all duration-300 group-hover:scale-110`} />
                  </div>
                  
                  {/* Bottom Indicator */}
                  <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 h-1 rounded-full bg-gradient-to-r ${category.color} transition-all duration-300 w-0 group-hover:w-8`} />
                </div>
                
                {/* Label */}
                <span className="text-xs sm:text-sm font-semibold text-gray-600 group-hover:text-gray-900 transition-colors whitespace-nowrap">
                  {language === 'ar' ? label.ar : label.en}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
