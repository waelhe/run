'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { ChevronLeft, ChevronRight, ArrowLeft, ArrowRight, Sparkles } from 'lucide-react';
import ServiceCard, { Listing } from './ServiceCard';
import { useLanguage } from '@/contexts/LanguageContext';
import { Skeleton } from '@/components/ui/skeleton';

interface ServiceSectionProps {
  title: string;
  subtitle?: string;
  categoryId?: string;
  filterPopular?: boolean;
  limit?: number;
}

export default function ServiceSection({ 
  title, 
  subtitle, 
  categoryId, 
  filterPopular = false, 
  limit = 8,
}: ServiceSectionProps) {
  const { language } = useLanguage();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchListings = async () => {
      try {
        setLoading(true);
        
        const params = new URLSearchParams();
        params.append('limit', limit.toString());
        params.append('status', 'active');
        
        if (categoryId) {
          params.append('category', categoryId);
        }
        
        const response = await fetch(`/api/listings?${params.toString()}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch listings');
        }
        
        const data = await response.json();
        let fetchedListings = data.data || [];
        
        if (filterPopular) {
          fetchedListings = fetchedListings.sort((a: Listing, b: Listing) => {
            const ratingA = a.ratingAverage || 0;
            const ratingB = b.ratingAverage || 0;
            return ratingB - ratingA;
          });
        }
        
        setListings(fetchedListings);
      } catch (error) {
        console.error('Error fetching listings:', error);
        setListings([]);
      } finally {
        setLoading(false);
      }
    };

    fetchListings();
  }, [categoryId, filterPopular, limit]);

  const checkScrollPosition = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setShowLeftArrow(scrollLeft > 0);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    const scrollElement = scrollRef.current;
    if (scrollElement) {
      scrollElement.addEventListener('scroll', checkScrollPosition);
      checkScrollPosition();
      return () => scrollElement.removeEventListener('scroll', checkScrollPosition);
    }
  }, [loading]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth * 0.85 
        : scrollLeft + clientWidth * 0.85;
      
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (!loading && listings.length === 0) return null;

  return (
    <section className="py-6 sm:py-8 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex justify-between items-end mb-5">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              {filterPopular && (
                <Sparkles className="w-5 h-5 text-emerald-500" />
              )}
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
                {title}
              </h2>
            </div>
            {subtitle && (
              <p className="text-sm text-gray-500 max-w-xl">
                {subtitle}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {categoryId && (
              <Link 
                href={`/?category=${categoryId}`} 
                className="hidden sm:flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-full transition-all"
              >
                <span>{language === 'ar' ? 'عرض الكل' : 'View All'}</span>
                {language === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </Link>
            )}
            
            {/* Scroll Arrows */}
            <div className="flex items-center gap-1.5">
              <button 
                onClick={() => scroll('right')}
                disabled={!showRightArrow}
                className={`p-2.5 rounded-full border transition-all shadow-sm ${
                  showRightArrow 
                    ? 'border-gray-200 bg-white hover:bg-gray-50 hover:shadow-md hover:scale-105' 
                    : 'border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed'
                }`}
              >
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </button>
              <button 
                onClick={() => scroll('left')}
                disabled={!showLeftArrow}
                className={`p-2.5 rounded-full border transition-all shadow-sm ${
                  showLeftArrow 
                    ? 'border-gray-200 bg-white hover:bg-gray-50 hover:shadow-md hover:scale-105' 
                    : 'border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed'
                }`}
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex gap-4 md:gap-6 overflow-hidden pb-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="min-w-[280px] md:min-w-[300px] flex flex-col gap-3">
                <Skeleton className="aspect-[4/3] rounded-2xl" />
                <div className="space-y-2 px-1">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-5 w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div 
            ref={scrollRef}
            className="flex gap-4 md:gap-6 overflow-x-auto pb-2 scroll-smooth hide-scrollbar"
          >
            {listings.map((listing) => (
              <div key={listing.id} className="snap-start">
                <ServiceCard listing={listing} />
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
