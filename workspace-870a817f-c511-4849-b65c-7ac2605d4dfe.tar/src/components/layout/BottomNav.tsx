'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Search, LayoutGrid, Heart, User } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function BottomNav() {
  const pathname = usePathname();
  const { language } = useLanguage();

  const navItems = [
    { 
      name: language === 'ar' ? 'الرئيسية' : 'Home', 
      path: '/', 
      icon: Home 
    },
    { 
      name: language === 'ar' ? 'استكشاف' : 'Explore', 
      path: '/?category=tourism', 
      icon: Search 
    },
    { 
      name: language === 'ar' ? 'الخدمات' : 'Services', 
      path: '/?category=all', 
      icon: LayoutGrid 
    },
    { 
      name: language === 'ar' ? 'المفضلة' : 'Wishlist', 
      path: '/wishlist', 
      icon: Heart 
    },
    { 
      name: language === 'ar' ? 'حسابي' : 'Profile', 
      path: '/profile', 
      icon: User 
    },
  ];

  const isActive = (path: string) => {
    if (path === '/') return pathname === '/';
    return pathname.startsWith(path.split('?')[0]);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-gray-100 z-50 md:hidden safe-area-bottom">
      <div className="flex justify-around items-center h-16 px-1 max-w-lg mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`flex flex-col items-center justify-center w-full h-full gap-0.5 transition-all duration-200 group touch-manipulation ${
                active 
                  ? 'text-emerald-600' 
                  : 'text-gray-400 group-hover:text-gray-600 group-active:scale-95'
              }`}
            >
              <div className={`flex items-center justify-center w-10 h-6 rounded-full transition-all duration-200 ${
                active ? 'bg-emerald-50' : ''
              }`}>
                <Icon className={`w-5 h-5 transition-all duration-200 ${
                  active ? 'stroke-[2.5] scale-110' : 'stroke-[1.5]'
                }`} />
              </div>
              <span className={`text-[10px] transition-all duration-200 ${
                active ? 'font-bold' : 'font-medium'
              }`}>
                {item.name}
              </span>
              
              {/* Active Indicator */}
              {active && (
                <div className="absolute top-0 w-12 h-0.5 bg-emerald-500 rounded-full" />
              )}
            </Link>
          );
        })}
      </div>
      
      {/* Safe area for iOS */}
      <div className="h-safe-area-inset-bottom bg-white" />
    </nav>
  );
}
