/**
 * Header Component
 * 
 * شريط التنقل العلوي
 */

'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { Search, Globe, User, Menu, LogIn, LogOut, ShoppingCart, X, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';

export default function Header() {
  const { language, setLanguage, t } = useLanguage();
  const { user, signOut } = useAuth();
  const { cartCount, setIsOpen: setIsCartOpen } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 h-16 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-lg border-b border-gray-100 shadow-sm' 
          : 'bg-white border-b border-gray-100'
      }`}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-full flex items-center justify-between gap-2">
        {/* Logo */}
        <Link 
          href="/" 
          className="flex items-center gap-2 group shrink-0"
        >
          <div className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/25 group-hover:scale-105 group-active:scale-95 transition-transform">
            <span className="text-white font-black text-lg">ض</span>
          </div>
          <span className="text-lg font-black text-gray-900 hidden sm:block">
            {language === 'ar' ? 'ضيف' : 'Dayf'}
          </span>
        </Link>
        
        {/* Search Bar - Desktop */}
        <div className="hidden md:flex items-center bg-white border border-gray-200 rounded-full shadow-sm hover:shadow-md hover:border-gray-300 transition-all duration-300 overflow-hidden flex-1 max-w-xl mx-4">
          <button className="px-5 font-semibold hover:bg-gray-50 transition-all py-2.5 text-sm text-gray-900">
            {t('header.anywhere')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className="px-5 font-semibold hover:bg-gray-50 transition-all py-2.5 text-sm text-gray-900">
            {t('header.any_week')}
          </button>
          <div className="h-6 w-[1px] bg-gray-200" />
          <button className="px-5 font-medium text-gray-500 hover:bg-gray-50 transition-all flex items-center gap-2 py-2.5 text-sm">
            {t('header.add_guests')}
            <div className="bg-emerald-500 text-white rounded-full p-1.5 w-7 h-7 flex items-center justify-center">
              <Search className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Cart */}
          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-600 hover:text-gray-900 touch-manipulation"
            title={language === 'ar' ? 'السلة' : 'Cart'}
          >
            <ShoppingCart className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-emerald-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {cartCount > 9 ? '9+' : cartCount}
              </span>
            )}
          </button>

          {/* Language Toggle */}
          <button 
            onClick={toggleLanguage}
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-full hover:bg-gray-100 transition-colors text-gray-600 hover:text-gray-900 text-sm font-medium"
            title={language === 'ar' ? 'English' : 'العربية'}
          >
            <Globe className="w-4 h-4" />
            <span>{language === 'ar' ? 'EN' : 'عربي'}</span>
          </button>

          {/* Mobile Language Toggle */}
          <button 
            onClick={toggleLanguage}
            className="sm:hidden p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-600 touch-manipulation"
          >
            <Globe className="w-5 h-5" />
          </button>

          {/* User Menu */}
          <div className="relative" ref={menuRef}>
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`flex items-center gap-1.5 border rounded-full py-1 px-1.5 sm:py-1.5 sm:px-2 transition-all bg-white hover:shadow-md ${
                isMenuOpen ? 'border-gray-300 shadow-md' : 'border-gray-200'
              }`}
            >
              <Menu className={`w-4 h-4 text-gray-600 transition-transform ${isMenuOpen ? 'rotate-90' : ''}`} />
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center overflow-hidden">
                {user?.avatar ? (
                  <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-4 h-4 text-white" />
                )}
              </div>
            </button>

            {/* Dropdown Menu */}
            {isMenuOpen && (
              <>
                {/* Backdrop */}
                <div 
                  className="fixed inset-0 z-40 md:hidden" 
                  onClick={() => setIsMenuOpen(false)}
                />
                
                <div className={`absolute mt-2 w-72 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-50 overflow-hidden ${
                  language === 'ar' ? 'right-0' : 'left-0'
                }`}>
                  {!user ? (
                    <>
                      <Link 
                        href="/auth/login"
                        onClick={() => setIsMenuOpen(false)}
                        className="w-full px-4 py-3 text-sm font-bold hover:bg-gray-50 flex items-center justify-between text-gray-900"
                      >
                        <span>{language === 'ar' ? 'تسجيل الدخول' : 'Login'}</span>
                        <ChevronRight className="w-4 h-4 text-gray-400" />
                      </Link>
                      <div className="h-[1px] bg-gray-100 my-1" />
                    </>
                  ) : (
                    <>
                      <div className="px-4 py-3 bg-gray-50">
                        <p className="text-sm font-bold text-gray-900 truncate">
                          {user.displayName || `${user.firstName} ${user.lastName}`}
                        </p>
                        <p className="text-xs text-gray-500 truncate">{user.email}</p>
                      </div>
                      <div className="h-[1px] bg-gray-100" />
                    </>
                  )}
                  
                  <Link 
                    href="/profile" 
                    onClick={() => setIsMenuOpen(false)} 
                    className="block px-4 py-2.5 text-sm hover:bg-gray-50 text-gray-700"
                  >
                    {language === 'ar' ? 'الملف الشخصي' : 'Profile'}
                  </Link>
                  <Link 
                    href="/my-bookings" 
                    onClick={() => setIsMenuOpen(false)} 
                    className="block px-4 py-2.5 text-sm hover:bg-gray-50 text-gray-700"
                  >
                    {language === 'ar' ? 'حجوزاتي' : 'My Bookings'}
                  </Link>
                  <Link 
                    href="/wishlist" 
                    onClick={() => setIsMenuOpen(false)} 
                    className="block px-4 py-2.5 text-sm hover:bg-gray-50 text-gray-700"
                  >
                    {language === 'ar' ? 'المفضلة' : 'Wishlist'}
                  </Link>
                  
                  <div className="h-[1px] bg-gray-100 my-1" />
                  
                  <Link 
                    href="/provider-dashboard" 
                    onClick={() => setIsMenuOpen(false)} 
                    className="block px-4 py-2.5 text-sm hover:bg-emerald-50 text-emerald-600 font-semibold"
                  >
                    {language === 'ar' ? 'أصبح مزود خدمة' : 'Become a Host'}
                  </Link>
                  
                  <Link 
                    href="/help" 
                    onClick={() => setIsMenuOpen(false)} 
                    className="block px-4 py-2.5 text-sm hover:bg-gray-50 text-gray-700"
                  >
                    {language === 'ar' ? 'المساعدة' : 'Help'}
                  </Link>
                  
                  {user && (
                    <>
                      <div className="h-[1px] bg-gray-100 my-1" />
                      <button 
                        onClick={() => { signOut(); setIsMenuOpen(false); }}
                        className="w-full px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 flex items-center gap-2 font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        {language === 'ar' ? 'تسجيل الخروج' : 'Logout'}
                      </button>
                    </>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
