/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Footer Component
 * 
 * شريط التنقل السفلي
 */

'use client';

import React from 'react';
import Link from 'next/link';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Footer() {
  const { language } = useLanguage();

  const content = {
    ar: {
      about: 'دليل سوريا هو منصتك الشاملة لاستكشاف أفضل الخدمات، المعالم، والمنتجات الحرفية في سوريا. نهدف لربط الزوار بأفضل ما تقدمه بلادنا.',
      quickLinks: 'روابط سريعة',
      contact: 'تواصل معنا',
      followUs: 'تابعنا',
      rights: 'جميع الحقوق محفوظة. دليل سوريا',
      links: [
        { name: 'الرئيسية', path: '/' },
        { name: 'السوق المحلي', path: '/marketplace' },
        { name: 'المجتمع', path: '/community' },
        { name: 'الملف الشخصي', path: '/profile' },
      ],
      categories: [
        { name: 'سياحة وإقامة', path: '/category/tourism' },
        { name: 'خدمات طبية', path: '/category/medical' },
        { name: 'عقارات', path: '/category/realestate' },
        { name: 'تجارب فريدة', path: '/category/experiences' },
      ],
      privacy: 'سياسة الخصوصية',
      terms: 'شروط الاستخدام',
    },
    en: {
      about: 'Syria Guide is your comprehensive platform to explore the best services, landmarks, and artisanal products in Syria.',
      quickLinks: 'Quick Links',
      contact: 'Contact Us',
      followUs: 'Follow Us',
      rights: 'All rights reserved. Syria Guide',
      links: [
        { name: 'Home', path: '/' },
        { name: 'Marketplace', path: '/marketplace' },
        { name: 'Community', path: '/community' },
        { name: 'Profile', path: '/profile' },
      ],
      categories: [
        { name: 'Tourism & Stay', path: '/category/tourism' },
        { name: 'Medical Services', path: '/category/medical' },
        { name: 'Real Estate', path: '/category/realestate' },
        { name: 'Unique Experiences', path: '/category/experiences' },
      ],
      privacy: 'Privacy Policy',
      terms: 'Terms of Service',
    }
  };

  const t = language === 'ar' ? content.ar : content.en;

  return (
    <footer className="bg-gray-900 text-gray-300 pt-16 pb-8 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Section */}
          <div className="space-y-6">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-900/20">
                <span className="text-white font-black text-xl">S</span>
              </div>
              <span className="text-2xl font-black text-white tracking-tight">
                SYRIA<span className="text-emerald-500">GUIDE</span>
              </span>
            </Link>
            <p className="text-gray-400 leading-relaxed text-sm">
              {t.about}
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-all">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-all">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">{t.quickLinks}</h3>
            <ul className="space-y-4">
              {t.links.map((link) => (
                <li key={link.path}>
                  <Link href={link.path} className="hover:text-emerald-500 transition-colors flex items-center gap-2 group">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500/50 group-hover:bg-emerald-500 transition-all" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">{language === 'ar' ? 'الأقسام' : 'Categories'}</h3>
            <ul className="space-y-4">
              {t.categories.map((cat) => (
                <li key={cat.path}>
                  <Link href={cat.path} className="hover:text-emerald-500 transition-colors flex items-center gap-2 group">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500/50 group-hover:bg-emerald-500 transition-all" />
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">{t.contact}</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="text-sm">دمشق، سوريا - حي الشعلان</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="text-sm" dir="ltr">+963 11 123 4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="text-sm">info@syriaguide.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
          <p dir="ltr">&copy; {new Date().getFullYear()} {t.rights}</p>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-white transition-colors">{t.privacy}</a>
            <a href="#" className="hover:text-white transition-colors">{t.terms}</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
