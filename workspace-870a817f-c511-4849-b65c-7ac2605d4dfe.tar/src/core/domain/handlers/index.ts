/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Domain Event Handlers - معالجات أحداث النطاق
 * 
 * @module core/domain/handlers
 */

import type { DomainEvent, DomainEventHandler } from '../events/typed-events';
import { logger } from '@/infrastructure/services/logger.service';

// ==================== Booking Event Handlers ====================

/**
 * حدث تأكيد الحجز
 */
export interface BookingConfirmedEvent extends DomainEvent {
  type: 'booking.confirmed';
  payload: {
    bookingId: string;
    listingId: string;
    guestId: string;
    hostId: string;
    checkIn: Date;
    checkOut: Date;
    totalPrice: number;
    currency: string;
  };
}

/**
 * حدث إلغاء الحجز
 */
export interface BookingCancelledEvent extends DomainEvent {
  type: 'booking.cancelled';
  payload: {
    bookingId: string;
    listingId: string;
    guestId: string;
    hostId: string;
    cancelledBy: string;
    reason?: string;
    refundAmount?: number;
    refundPercentage?: number;
  };
}

/**
 * حدث اكتمال الحجز
 */
export interface BookingCompletedEvent extends DomainEvent {
  type: 'booking.completed';
  payload: {
    bookingId: string;
    listingId: string;
    guestId: string;
    hostId: string;
    actualCheckIn?: Date;
    actualCheckOut?: Date;
    totalPrice: number;
  };
}

/**
 * معالج حدث تأكيد الحجز
 */
export class BookingConfirmedEventHandler implements DomainEventHandler<BookingConfirmedEvent> {
  async handle(event: BookingConfirmedEvent): Promise<void> {
    const { bookingId, listingId, guestId, hostId, totalPrice, currency } = event.payload;

    // 1. إنشاء سجل Escrow
    logger.info('Creating escrow for booking', { bookingId, handler: 'BookingConfirmedHandler' });
    
    // 2. إرسال إشعارات
    logger.info('Sending notifications', { guestId, hostId, handler: 'BookingConfirmedHandler' });
    
    // 3. تحديث إحصائيات
    logger.info('Updating booking stats', { listingId, handler: 'BookingConfirmedHandler' });
    
    // 4. حجز التواريخ
    logger.info('Blocking dates', { listingId, handler: 'BookingConfirmedHandler' });
  }
}

/**
 * معالج حدث إلغاء الحجز
 */
export class BookingCancelledEventHandler implements DomainEventHandler<BookingCancelledEvent> {
  async handle(event: BookingCancelledEvent): Promise<void> {
    const { bookingId, listingId, guestId, hostId, cancelledBy, refundAmount } = event.payload;

    // 1. تحديث حالة Escrow
    logger.info('Updating escrow status', { bookingId, handler: 'BookingCancelledHandler' });
    
    // 2. معالجة الاسترداد
    if (refundAmount && refundAmount > 0) {
      logger.info('Processing refund', { refundAmount, handler: 'BookingCancelledHandler' });
    }
    
    // 3. تحرير التواريخ
    logger.info('Releasing dates', { listingId, handler: 'BookingCancelledHandler' });
    
    // 4. إرسال إشعارات
    logger.info('Sending cancellation notifications', { handler: 'BookingCancelledHandler' });
  }
}

/**
 * معالج حدث اكتمال الحجز
 */
export class BookingCompletedEventHandler implements DomainEventHandler<BookingCompletedEvent> {
  async handle(event: BookingCompletedEvent): Promise<void> {
    const { bookingId, listingId, guestId, hostId, totalPrice } = event.payload;

    // 1. إصدار Escrow للمضيف
    logger.info('Releasing escrow to host', { hostId, handler: 'BookingCompletedHandler' });
    
    // 2. تحديث إحصائيات المضيف
    logger.info('Updating host stats', { handler: 'BookingCompletedHandler' });
    
    // 3. تحديث إحصائيات الضيف
    logger.info('Updating guest stats', { handler: 'BookingCompletedHandler' });
    
    // 4. إرسال طلب التقييم
    logger.info('Sending review request to guest', { guestId, handler: 'BookingCompletedHandler' });
  }
}

// ==================== Payment Event Handlers ====================

/**
 * حدث نجاح الدفع
 */
export interface PaymentSuccessEvent extends DomainEvent {
  type: 'payment.success';
  payload: {
    paymentId: string;
    bookingId: string;
    userId: string;
    amount: number;
    currency: string;
    transactionId: string;
    paymentMethod: string;
  };
}

/**
 * حدث فشل الدفع
 */
export interface PaymentFailedEvent extends DomainEvent {
  type: 'payment.failed';
  payload: {
    paymentId: string;
    bookingId: string;
    userId: string;
    amount: number;
    currency: string;
    reason: string;
    retryCount: number;
  };
}

/**
 * حدث معالجة الاسترداد
 */
export interface RefundProcessedEvent extends DomainEvent {
  type: 'refund.processed';
  payload: {
    refundId: string;
    paymentId: string;
    bookingId: string;
    userId: string;
    amount: number;
    currency: string;
    reason?: string;
  };
}

/**
 * معالج حدث نجاح الدفع
 */
export class PaymentSuccessEventHandler implements DomainEventHandler<PaymentSuccessEvent> {
  async handle(event: PaymentSuccessEvent): Promise<void> {
    const { paymentId, bookingId, userId, amount, currency } = event.payload;

    // 1. تحديث حالة الحجز
    logger.info('Updating booking payment status', { bookingId, handler: 'PaymentSuccessHandler' });
    
    // 2. إنشاء Escrow
    logger.info('Creating escrow for payment', { paymentId, handler: 'PaymentSuccessHandler' });
    
    // 3. إرسال إشعار للمستخدم
    logger.info('Sending payment confirmation', { userId, handler: 'PaymentSuccessHandler' });
    
    // 4. إرسال إشعار للمضيف
    logger.info('Notifying host about payment', { handler: 'PaymentSuccessHandler' });
  }
}

/**
 * معالج حدث فشل الدفع
 */
export class PaymentFailedEventHandler implements DomainEventHandler<PaymentFailedEvent> {
  async handle(event: PaymentFailedEvent): Promise<void> {
    const { paymentId, bookingId, userId, reason, retryCount } = event.payload;

    // 1. تحديث حالة الدفع
    logger.warn('Marking payment as failed', { paymentId, handler: 'PaymentFailedHandler' });
    
    // 2. إرسال إشعار للمستخدم
    logger.info('Notifying user about failed payment', { userId, handler: 'PaymentFailedHandler' });
    
    // 3. إذا تجاوز عدد المحاولات الحد، إلغاء الحجز
    if (retryCount >= 3) {
      logger.warn('Max retries reached, cancelling booking', { bookingId, handler: 'PaymentFailedHandler' });
    }
  }
}

/**
 * معالج حدث الاسترداد
 */
export class RefundProcessedEventHandler implements DomainEventHandler<RefundProcessedEvent> {
  async handle(event: RefundProcessedEvent): Promise<void> {
    const { refundId, paymentId, bookingId, userId, amount, currency } = event.payload;

    // 1. تحديث حالة الدفع
    logger.info('Updating payment refund status', { paymentId, handler: 'RefundProcessedHandler' });
    
    // 2. تحديث حالة Escrow
    logger.info('Updating escrow', { bookingId, handler: 'RefundProcessedHandler' });
    
    // 3. إرسال إشعار للمستخدم
    logger.info('Sending refund confirmation', { userId, amount, handler: 'RefundProcessedHandler' });
  }
}

// ==================== Review Event Handlers ====================

/**
 * حدث إنشاء التقييم
 */
export interface ReviewCreatedEvent extends DomainEvent {
  type: 'review.created';
  payload: {
    reviewId: string;
    bookingId: string;
    listingId: string;
    reviewerId: string;
    revieweeId: string;
    ratingOverall: number;
    hasComment: boolean;
  };
}

/**
 * حدث الرد على التقييم
 */
export interface ReviewRespondedEvent extends DomainEvent {
  type: 'review.responded';
  payload: {
    reviewId: string;
    listingId: string;
    responderId: string;
    revieweeId: string;
    responseLength: number;
  };
}

/**
 * معالج حدث إنشاء التقييم
 */
export class ReviewCreatedEventHandler implements DomainEventHandler<ReviewCreatedEvent> {
  async handle(event: ReviewCreatedEvent): Promise<void> {
    const { reviewId, listingId, reviewerId, revieweeId, ratingOverall } = event.payload;

    // 1. تحديث متوسط تقييم الإعلان
    logger.info('Updating listing rating average', { listingId, handler: 'ReviewCreatedHandler' });
    
    // 2. تحديث متوسط تقييم المضيف
    logger.info('Updating host rating average', { revieweeId, handler: 'ReviewCreatedHandler' });
    
    // 3. إرسال إشعار للمقيم
    logger.info('Notifying about new review', { revieweeId, handler: 'ReviewCreatedHandler' });
    
    // 4. إذا كان التقييم منخفض، تنبيه المضيف
    if (ratingOverall < 3) {
      logger.warn('Low rating alert', { listingId, rating: ratingOverall, handler: 'ReviewCreatedHandler' });
    }
  }
}

/**
 * معالج حدث الرد على التقييم
 */
export class ReviewRespondedEventHandler implements DomainEventHandler<ReviewRespondedEvent> {
  async handle(event: ReviewRespondedEvent): Promise<void> {
    const { reviewId, listingId, responderId, revieweeId } = event.payload;

    // 1. إرسال إشعار للمقيم الأصلي
    logger.info('Notifying reviewer about response', { handler: 'ReviewRespondedHandler' });
    
    // 2. تحديث حالة التقييم
    logger.info('Updating review response status', { reviewId, handler: 'ReviewRespondedHandler' });
  }
}

// ==================== User Event Handlers ====================

/**
 * حدث تسجيل مستخدم جديد
 */
export interface UserRegisteredEvent extends DomainEvent {
  type: 'user.registered';
  payload: {
    userId: string;
    email?: string;
    phone?: string;
    firstName: string;
    lastName: string;
    role: string;
    referralCode?: string;
  };
}

/**
 * حدث تحقق المستخدم
 */
export interface UserVerifiedEvent extends DomainEvent {
  type: 'user.verified';
  payload: {
    userId: string;
    verificationType: 'email' | 'phone';
    verifiedAt: Date;
  };
}

/**
 * حدث ترقية المستخدم لمضيف
 */
export interface UserBecameHostEvent extends DomainEvent {
  type: 'user.became_host';
  payload: {
    userId: string;
    previousRole: string;
    becameHostAt: Date;
  };
}

/**
 * معالج حدث تسجيل مستخدم جديد
 */
export class UserRegisteredEventHandler implements DomainEventHandler<UserRegisteredEvent> {
  async handle(event: UserRegisteredEvent): Promise<void> {
    const { userId, email, phone, firstName, lastName, referralCode } = event.payload;

    // 1. إرسال بريد ترحيب
    if (email) {
      logger.info('Sending welcome email', { email, handler: 'UserRegisteredHandler' });
    }
    
    // 2. إرسال رسالة تحقق
    if (phone) {
      logger.info('Sending verification SMS', { phone, handler: 'UserRegisteredHandler' });
    }
    
    // 3. معالجة كود الإحالة
    if (referralCode) {
      logger.info('Processing referral code', { referralCode, handler: 'UserRegisteredHandler' });
    }
    
    // 4. تسجيل النشاط
    logger.info('Logging user registration', { userId, handler: 'UserRegisteredHandler' });
  }
}

/**
 * معالج حدث تحقق المستخدم
 */
export class UserVerifiedEventHandler implements DomainEventHandler<UserVerifiedEvent> {
  async handle(event: UserVerifiedEvent): Promise<void> {
    const { userId, verificationType } = event.payload;

    // 1. تحديث حالة المستخدم
    logger.info('Updating user verification status', { userId, verificationType, handler: 'UserVerifiedHandler' });
    
    // 2. إضافة نقاط ولاء
    logger.info('Adding loyalty points for verification', { handler: 'UserVerifiedHandler' });
    
    // 3. إرسال إشعار
    logger.info('Sending verification confirmation', { handler: 'UserVerifiedHandler' });
  }
}

/**
 * معالج حدث ترقية المستخدم لمضيف
 */
export class UserBecameHostEventHandler implements DomainEventHandler<UserBecameHostEvent> {
  async handle(event: UserBecameHostEvent): Promise<void> {
    const { userId, previousRole } = event.payload;

    // 1. إرسال دليل المضيف
    logger.info('Sending host guide', { userId, handler: 'UserBecameHostHandler' });
    
    // 2. إعداد الإحصائيات
    logger.info('Initializing host stats', { userId, handler: 'UserBecameHostHandler' });
    
    // 3. إشعار فريق الدعم
    logger.info('Notifying support team about new host', { handler: 'UserBecameHostHandler' });
  }
}

// ==================== Listing Event Handlers ====================

/**
 * حدث نشر الإعلان
 */
export interface ListingPublishedEvent extends DomainEvent {
  type: 'listing.published';
  payload: {
    listingId: string;
    hostId: string;
    title: string;
    city: string;
    country: string;
    price: number;
    currency: string;
  };
}

/**
 * حدث تعليق الإعلان
 */
export interface ListingArchivedEvent extends DomainEvent {
  type: 'listing.archived';
  payload: {
    listingId: string;
    hostId: string;
    reason?: string;
    activeBookingsCount: number;
  };
}

/**
 * معالج حدث نشر الإعلان
 */
export class ListingPublishedEventHandler implements DomainEventHandler<ListingPublishedEvent> {
  async handle(event: ListingPublishedEvent): Promise<void> {
    const { listingId, hostId, title, city, country } = event.payload;

    // 1. إضافة للفهرس البحثي
    logger.info('Indexing listing for search', { listingId, handler: 'ListingPublishedHandler' });
    
    // 2. إرسال إشعار للمضيف
    logger.info('Sending confirmation to host', { hostId, handler: 'ListingPublishedHandler' });
    
    // 3. الترويج (إذا كان جديداً)
    logger.info('Promoting new listing', { city, country, handler: 'ListingPublishedHandler' });
    
    // 4. تحديث إحصائيات المضيف
    logger.info('Updating host listing count', { handler: 'ListingPublishedHandler' });
  }
}

/**
 * معالج حدث تعليق الإعلان
 */
export class ListingArchivedEventHandler implements DomainEventHandler<ListingArchivedEvent> {
  async handle(event: ListingArchivedEvent): Promise<void> {
    const { listingId, hostId, activeBookingsCount } = event.payload;

    // 1. إزالة من الفهرس البحثي
    logger.info('Removing listing from search index', { listingId, handler: 'ListingArchivedHandler' });
    
    // 2. التعامل مع الحجوزات النشطة
    if (activeBookingsCount > 0) {
      logger.warn('Handling active bookings for archived listing', { activeBookingsCount, handler: 'ListingArchivedHandler' });
    }
    
    // 3. إرسال إشعار للمضيف
    logger.info('Notifying host about archival', { hostId, handler: 'ListingArchivedHandler' });
  }
}

// ==================== Escrow Event Handlers ====================

/**
 * حدث إصدار الضمان
 */
export interface EscrowReleasedEvent extends DomainEvent {
  type: 'escrow.released';
  payload: {
    escrowId: string;
    bookingId: string;
    hostId: string;
    amount: number;
    currency: string;
    releasedTo: 'host' | 'guest' | 'split';
  };
}

/**
 * حدث فتح نزاع
 */
export interface DisputeOpenedEvent extends DomainEvent {
  type: 'dispute.opened';
  payload: {
    disputeId: string;
    escrowId: string;
    bookingId: string;
    openedBy: string;
    reason: string;
    amount: number;
    currency: string;
  };
}

/**
 * معالج حدث إصدار الضمان
 */
export class EscrowReleasedEventHandler implements DomainEventHandler<EscrowReleasedEvent> {
  async handle(event: EscrowReleasedEvent): Promise<void> {
    const { escrowId, bookingId, hostId, amount, currency, releasedTo } = event.payload;

    // 1. إنشاء معاملة payout
    logger.info('Creating payout', { releasedTo, handler: 'EscrowReleasedHandler' });
    
    // 2. إرسال إشعار
    logger.info('Sending payout notification', { amount, currency, handler: 'EscrowReleasedHandler' });
    
    // 3. تحديث الإحصائيات المالية
    logger.info('Updating financial stats', { bookingId, handler: 'EscrowReleasedHandler' });
  }
}

/**
 * معالج حدث فتح نزاع
 */
export class DisputeOpenedEventHandler implements DomainEventHandler<DisputeOpenedEvent> {
  async handle(event: DisputeOpenedEvent): Promise<void> {
    const { disputeId, escrowId, bookingId, openedBy, reason } = event.payload;

    // 1. إشعار فريق الدعم
    logger.warn('Alerting support team about dispute', { disputeId, handler: 'DisputeOpenedHandler' });
    
    // 2. تجميد الضمان
    logger.info('Freezing escrow', { escrowId, handler: 'DisputeOpenedHandler' });
    
    // 3. إشعار الطرفين
    logger.info('Notifying both parties about dispute', { handler: 'DisputeOpenedHandler' });
    
    // 4. إنشاء تذكرة دعم
    logger.info('Creating support ticket for dispute', { disputeId, handler: 'DisputeOpenedHandler' });
  }
}

// ==================== Notification Event Handlers ====================

/**
 * حدث إرسال إشعار
 */
export interface NotificationSentEvent extends DomainEvent {
  type: 'notification.sent';
  payload: {
    notificationId: string;
    userId: string;
    type: string;
    channel: 'email' | 'sms' | 'push' | 'whatsapp' | 'in_app';
    success: boolean;
    error?: string;
  };
}

/**
 * معالج حدث إرسال إشعار
 */
export class NotificationSentEventHandler implements DomainEventHandler<NotificationSentEvent> {
  async handle(event: NotificationSentEvent): Promise<void> {
    const { notificationId, userId, channel, success, error } = event.payload;

    // 1. تحديث حالة الإشعار
    logger.info('Updating notification status', { notificationId, handler: 'NotificationSentHandler' });
    
    // 2. إذا فشل، إعادة المحاولة أو تسجيل الخطأ
    if (!success) {
      logger.error('Notification failed', { channel, error, handler: 'NotificationSentHandler' });
    }
    
    // 3. تحديث إحصائيات القناة
    logger.debug('Updating channel stats', { channel, handler: 'NotificationSentHandler' });
  }
}

// ==================== Event Handler Registry ====================

/**
 * سجل معالجات الأحداث
 */
export class EventHandlerRegistry {
  private handlers: Map<string, DomainEventHandler<DomainEvent>[]> = new Map();

  /**
   * تسجيل معالج
   */
  register<T extends DomainEvent>(
    eventType: string,
    handler: DomainEventHandler<T>
  ): void {
    const existing = this.handlers.get(eventType) || [];
    existing.push(handler as DomainEventHandler<DomainEvent>);
    this.handlers.set(eventType, existing);
  }

  /**
   * الحصول على المعالجات
   */
  getHandlers(eventType: string): DomainEventHandler<DomainEvent>[] {
    return this.handlers.get(eventType) || [];
  }

  /**
   * تنفيذ المعالجات
   */
  async dispatch<T extends DomainEvent>(event: T): Promise<void> {
    const handlers = this.getHandlers(event.type);
    await Promise.all(handlers.map(handler => handler.handle(event)));
  }
}

// ==================== Initialize Registry ====================

/**
 * السجل الافتراضي
 */
export const eventHandlerRegistry = new EventHandlerRegistry();

// تسجيل جميع المعالجات
eventHandlerRegistry.register('booking.confirmed', new BookingConfirmedEventHandler());
eventHandlerRegistry.register('booking.cancelled', new BookingCancelledEventHandler());
eventHandlerRegistry.register('booking.completed', new BookingCompletedEventHandler());
eventHandlerRegistry.register('payment.success', new PaymentSuccessEventHandler());
eventHandlerRegistry.register('payment.failed', new PaymentFailedEventHandler());
eventHandlerRegistry.register('refund.processed', new RefundProcessedEventHandler());
eventHandlerRegistry.register('review.created', new ReviewCreatedEventHandler());
eventHandlerRegistry.register('review.responded', new ReviewRespondedEventHandler());
eventHandlerRegistry.register('user.registered', new UserRegisteredEventHandler());
eventHandlerRegistry.register('user.verified', new UserVerifiedEventHandler());
eventHandlerRegistry.register('user.became_host', new UserBecameHostEventHandler());
eventHandlerRegistry.register('listing.published', new ListingPublishedEventHandler());
eventHandlerRegistry.register('listing.archived', new ListingArchivedEventHandler());
eventHandlerRegistry.register('escrow.released', new EscrowReleasedEventHandler());
eventHandlerRegistry.register('dispute.opened', new DisputeOpenedEventHandler());
eventHandlerRegistry.register('notification.sent', new NotificationSentEventHandler());

// ==================== Export All ====================

export const EventHandlers = {
  // Booking
  BookingConfirmedEventHandler,
  BookingCancelledEventHandler,
  BookingCompletedEventHandler,
  
  // Payment
  PaymentSuccessEventHandler,
  PaymentFailedEventHandler,
  RefundProcessedEventHandler,
  
  // Review
  ReviewCreatedEventHandler,
  ReviewRespondedEventHandler,
  
  // User
  UserRegisteredEventHandler,
  UserVerifiedEventHandler,
  UserBecameHostEventHandler,
  
  // Listing
  ListingPublishedEventHandler,
  ListingArchivedEventHandler,
  
  // Escrow
  EscrowReleasedEventHandler,
  DisputeOpenedEventHandler,
  
  // Notification
  NotificationSentEventHandler,
};
