#!/bin/bash

# 🛡️ Architecture Guardian - حارس البنية المعمارية
# فحص تلقائي لقواعد RULES.md
# الاستخدام: bash .context/architecture-guardian.sh

set -e

echo "═══════════════════════════════════════════════════════════════"
echo "              🛡️ Architecture Guardian - حارس البنية"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# متغيرات الإحصائيات
TOTAL_CHECKS=0
PASSED=0
FAILED=0
WARNINGS=0
ISSUES=""

# ألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# دوال المساعدة
check_pass() {
    echo "  ${GREEN}✅${NC} $1"
    PASSED=$((PASSED + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
}

check_fail() {
    echo "  ${RED}❌${NC} $1"
    echo "     💡 $2"
    FAILED=$((FAILED + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    ISSUES="$ISSUES\n  ❌ $1 - $2"
}

check_warn() {
    echo "  ${YELLOW}⚠️${NC} $1"
    echo "     💡 $2"
    WARNINGS=$((WARNINGS + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
}

# ═══════════════════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   🏗️ 1. قواعد TypeScript"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# فحص `any`
echo ""
echo "📌 فحص استخدام \`any\`..."
ANY_COUNT=$(grep -r ": any" src --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v "node_modules" | grep -v ".d.ts" | wc -l | tr -d ' ')
if [ "$ANY_COUNT" -eq 0 ]; then
    check_pass "لا يوجد استخدام لـ \`any\`"
else
    check_fail "استخدام \`any\`" "يوجد $ANY_COUNT حالة - استخدم \`unknown\` + type guard"
fi

# فحص `@ts-ignore`
echo ""
echo "📌 فحص \`@ts-ignore\`..."
TS_IGNORE=$(grep -r "@ts-ignore" src --include="*.ts" --include="*.tsx" 2>/dev/null | wc -l | tr -d ' ')
if [ "$TS_IGNORE" -eq 0 ]; then
    check_pass "لا يوجد \`@ts-ignore\`"
else
    check_warn "استخدام \`@ts-ignore\`" "يوجد $TS_IGNORE حالة - حل المشكلة بدلاً من تجاهلها"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   🖨️ 2. قواعد الطباعة"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# فحص console.log
echo ""
echo "📌 فحص \`console.log\`..."
CONSOLE_LOG=$(grep -r "console\.log" src --include="*.ts" --include="*.tsx" 2>/dev/null | wc -l | tr -d ' ')
if [ "$CONSOLE_LOG" -eq 0 ]; then
    check_pass "لا يوجد \`console.log\`"
else
    check_warn "\`console.log\` موجود" "يوجد $CONSOLE_LOG حالة - استبدل بـ logger service"
fi

# فحص console.error في production code
echo ""
echo "📌 فحص \`console.error\`..."
CONSOLE_ERROR=$(grep -r "console\.error" src --include="*.ts" --include="*.tsx" 2>/dev/null | wc -l | tr -d ' ')
if [ "$CONSOLE_ERROR" -eq 0 ]; then
    check_pass "لا يوجد \`console.error\`"
else
    check_warn "\`console.error\` موجود" "يوجد $CONSOLE_ERROR حالة - استبدل بـ logger.error()"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   🔐 3. قواعد الأمان"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# فحص dangerouslySetInnerHTML
echo ""
echo "📌 فحص \`dangerouslySetInnerHTML\`..."
DANGEROUS=$(grep -r "dangerouslySetInnerHTML" src --include="*.tsx" 2>/dev/null | grep -v "node_modules" | wc -l | tr -d ' ')
if [ "$DANGEROUS" -eq 0 ]; then
    check_pass "لا يوجد \`dangerouslySetInnerHTML\`"
else
    check_warn "\`dangerouslySetInnerHTML\` موجود" "يوجد $DANGEROUS حالة - تأكد من sanitization أو استخدم بديل"
fi

# فحص localStorage مع tokens
echo ""
echo "📌 فحص تخزين token في localStorage..."
TOKEN_LS=$(grep -r "localStorage.*token\|token.*localStorage" src --include="*.ts" --include="*.tsx" 2>/dev/null | wc -l | tr -d ' ')
if [ "$TOKEN_LS" -eq 0 ]; then
    check_pass "لا يوجد تخزين token في localStorage"
else
    check_fail "token في localStorage" "يوجد $TOKEN_LS حالة - استخدم httpOnly Cookie"
fi

# فحص SQL خام
echo ""
echo "📌 فحص SQL خام..."
RAW_SQL=$(grep -r "\$\{.*\}" src --include="*.ts" | grep -i "SELECT\|INSERT\|UPDATE\|DELETE" 2>/dev/null | wc -l | tr -d ' ')
if [ "$RAW_SQL" -eq 0 ]; then
    check_pass "لا يوجد SQL خام"
else
    check_fail "SQL خام" "يوجد $RAW_SQL حالة - استخدم Prisma queries"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   📁 4. قواعد الملفات"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# فحص حجم الملفات
echo ""
echo "📌 فحص حجم الملفات (أقصى 500 سطر للملفات المنطقية)..."
LARGE_FILES=$(find src -name "*.ts" -o -name "*.tsx" 2>/dev/null | xargs wc -l 2>/dev/null | awk '$1 > 500 && $2 !~ /index\.ts$/ {print $2}' | wc -l | tr -d ' ')
if [ "$LARGE_FILES" -eq 0 ]; then
    check_pass "جميع الملفات بحجم مناسب"
else
    check_warn "ملفات كبيرة" "يوجد $LARGE_FILES ملف أكبر من 500 سطر - قسمها لسهولة الصيانة"
fi

# فحص المجلدات بدون index.ts
echo ""
echo "📌 فحص المجلدات بدون index.ts..."
MISSING_INDEX=$(find src -type d ! -path "*/node_modules/*" -exec sh -c '[ ! -f "$1/index.ts" ] && [ ! -f "$1/index.tsx" ] && [ "$(ls -A "$1" 2>/dev/null | grep -E "\.(ts|tsx)$" | wc -l)" -gt 0 ] && echo "$1"' _ {} \; 2>/dev/null | wc -l | tr -d ' ')
if [ "$MISSING_INDEX" -eq 0 ]; then
    check_pass "جميع المجلدات لها index.ts"
else
    check_warn "مجلدات بدون index.ts" "يوجد $MISSING_INDEX مجلد - أضف index.ts للتصدير النظيف"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   🏗️ 5. قواعد البنية المعمارية"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# فحص الهيكل الأساسي
echo ""
echo "📌 فحص هيكل DDD..."
[ -d "src/core/domain" ] && check_pass "src/core/domain موجود" || check_fail "DDD Structure" "مجلد domain مفقود"
[ -d "src/application" ] && check_pass "src/application موجود" || check_warn "Application Layer" "مجلد application مفقود"
[ -d "src/infrastructure" ] && check_pass "src/infrastructure موجود" || check_warn "Infrastructure Layer" "مجلد infrastructure مفقود"

# فحص التواصل بين الوحدات
echo ""
echo "📌 فحص الاستيراد المباشر بين الوحدات..."
# هذه فحص تقريبي - يبحث عن استيراد من مجلدات أقران
CROSS_IMPORT=$(grep -r "from '\.\./\.\./\.\./\.\./" src --include="*.ts" --include="*.tsx" 2>/dev/null | wc -l | tr -d ' ')
if [ "$CROSS_IMPORT" -eq 0 ]; then
    check_pass "لا يوجد استيراد عميق مفرط"
else
    check_warn "استيراد عميق" "يوجد $CROSS_IMPORT حالة - راجع بنية الاستيرادات"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   🌐 6. قواعد RTL"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# فحص RTL في layout
echo ""
echo "📌 فحص RTL في التخطيط..."
if grep -q "dir=\"rtl\"" src/app/layout.tsx 2>/dev/null; then
    check_pass "RTL موجود في layout.tsx"
else
    check_warn "RTL" "أضف dir=\"rtl\" للدعم العربي"
fi

# ═══════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "                   🔌 7. قواعد API"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━════════"

# فحص وجود validation
echo ""
echo "📌 فحص Zod validation في APIs..."
ZOD_USAGE=$(grep -r "\.parse\|\.safeParse" src/app/api --include="*.ts" 2>/dev/null | wc -l | tr -d ' ')
API_FILES=$(find src/app/api -name "route.ts" 2>/dev/null | wc -l | tr -d ' ')
if [ "$ZOD_USAGE" -gt 0 ]; then
    check_pass "Zod validation مستخدم ($ZOD_USAGE حالة في $API_FILES API)"
else
    check_warn "Zod validation" "أضف Zod validation لكل API"
fi

# ═══════════════════════════════════════════════════════════════
# النتائج النهائية
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "                        📊 النتائج النهائية"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  إجمالي الفحوصات: $TOTAL_CHECKS"
echo "  ${GREEN}✅ ناجحة: $PASSED${NC}"
echo "  ${RED}❌ فاشلة: $FAILED${NC}"
echo "  ${YELLOW}⚠️  تحذيرات: $WARNINGS${NC}"
echo ""

if [ $FAILED -gt 0 ]; then
    echo "───────────────────────────────────────────────────────────────"
    echo "                   🔴 المشاكل المكتشفة:"
    echo "───────────────────────────────────────────────────────────────"
    echo -e "$ISSUES"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════"

# حساب نسبة الالتزام
COMPLIANCE=$(( (PASSED * 100) / TOTAL_CHECKS ))
echo ""
echo "  📈 نسبة الالتزام بالقواعد: ${COMPLIANCE}%"
echo ""

if [ $FAILED -gt 0 ]; then
    echo "  ${RED}🔴 يوجد مشاكل يجب إصلاحها${NC}"
    exit 1
elif [ $WARNINGS -gt 0 ]; then
    echo "  ${YELLOW}🟡 يوجد تحذيرات - راجعها قبل الإنتاج${NC}"
    exit 0
else
    echo "  ${GREEN}🟢 ممتاز! المشروع ملتزم بالقواعد${NC}"
    exit 0
fi
